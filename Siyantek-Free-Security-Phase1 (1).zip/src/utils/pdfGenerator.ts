import { jsPDF } from 'jspdf';
import { MaintenanceRecord, Vehicle, Language } from '../context/SiyantekContext';

export function generateVehicleReportPDF({
  vehicle,
  records,
  language,
  userTier,
  currency = 'DT',
}: {
  vehicle: Vehicle;
  records: MaintenanceRecord[];
  language: Language;
  userTier: string;
  currency?: string;
}) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const isFrench = language === 'fr';
  const isArabic = language === 'ar';

  // Colors
  const navy = [16, 42, 53]; // #102A35
  const teal = [22, 166, 160]; // #16A6A0
  const gray = [102, 128, 135]; // #668087
  const lightBg = [244, 247, 245];

  // Header Banner
  doc.setFillColor(navy[0], navy[1], navy[2]);
  doc.rect(0, 0, 210, 38, 'F');

  // Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('SIYANTEK', 15, 18);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(
    isFrench
      ? "Carnet de Sante Automobile & Historique d'Entretien"
      : isArabic
      ? "Siyantek - Rapport d'Entretien Automobile (صيانتك)"
      : "Automobile Health & Maintenance History Report",
    15,
    26
  );

  // Badge / Generation Date
  doc.setFontSize(9);
  doc.setTextColor(220, 240, 235);
  const dateStr = new Date().toLocaleDateString(isFrench ? 'fr-FR' : 'en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  doc.text(`Date: ${dateStr}`, 150, 18);
  doc.text(`Tier: ${userTier.toUpperCase()}`, 150, 25);

  // Vehicle Info Box
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.roundedRect(15, 46, 180, 32, 3, 3, 'F');

  doc.setTextColor(teal[0], teal[1], teal[2]);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(
    isFrench ? 'VEHICULE SOUS SUIVI' : 'VEHICLE INFORMATION',
    20,
    54
  );

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFontSize(14);
  doc.text(`${vehicle.brand} ${vehicle.model} (${vehicle.year || 'N/A'})`, 20, 63);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(gray[0], gray[1], gray[2]);
  doc.text(`Immatriculation: ${vehicle.plate || 'Non renseignee'}`, 20, 71);
  doc.text(`Compteur actuel: ${vehicle.mileage.toLocaleString()} km`, 110, 71);

  // Summary Metrics
  const totalCost = records.reduce((sum, r) => sum + (r.cost || 0), 0);
  const totalEntries = records.length;
  const latestService = records[0];

  // Collect all spare parts
  const allParts = records.flatMap((r) => r.parts || []);
  const totalPartsCost = allParts.reduce((sum, p) => sum + p.quantity * p.unitCost, 0);

  let currentY = 88;
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(220, 231, 227);
  doc.roundedRect(15, currentY, 42, 20, 2, 2, 'FD');
  doc.roundedRect(61, currentY, 42, 20, 2, 2, 'FD');
  doc.roundedRect(107, currentY, 42, 20, 2, 2, 'FD');
  doc.roundedRect(153, currentY, 42, 20, 2, 2, 'FD');

  doc.setFontSize(7.5);
  doc.setTextColor(gray[0], gray[1], gray[2]);
  doc.text('INTERVENTIONS', 18, currentY + 6);
  doc.text('DEPENSES TOTALES', 64, currentY + 6);
  doc.text('PIECES DE RECHANGE', 110, currentY + 6);
  doc.text('PROCHAIN SERVICE', 156, currentY + 6);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.text(`${totalEntries} act.`, 18, currentY + 14);
  doc.text(`${totalCost.toLocaleString()} ${currency}`, 64, currentY + 14);
  doc.text(`${allParts.length} pcs (${totalPartsCost.toLocaleString()} ${currency})`, 110, currentY + 14);

  const nextTarget = latestService?.nextMileage || (vehicle.mileage + 5000);
  doc.setTextColor(teal[0], teal[1], teal[2]);
  doc.text(`${nextTarget.toLocaleString()} km`, 156, currentY + 14);

  // Records Table Header
  currentY = 118;
  doc.setFillColor(navy[0], navy[1], navy[2]);
  doc.rect(15, currentY, 180, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.text('Date', 18, currentY + 5.5);
  doc.text('Type & Gravite', 42, currentY + 5.5);
  doc.text('Kilometrage', 78, currentY + 5.5);
  doc.text(`Cout (${currency})`, 110, currentY + 5.5);
  doc.text('Statut & Pieces', 140, currentY + 5.5);

  currentY += 8;

  // Table Rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);

  const rows = records.slice(0, 16);
  rows.forEach((rec, idx) => {
    if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 249);
      doc.rect(15, currentY, 180, 8, 'F');
    }

    doc.setTextColor(navy[0], navy[1], navy[2]);
    doc.text(rec.date, 18, currentY + 5);

    const typeNames: Record<string, string> = {
      oil: 'Vidange & Filtres',
      brakes: 'Freins & Plaquettes',
      tires: 'Pneumatiques',
      inspection: 'Controle technique',
      battery: 'Batterie & Elec',
      other: 'Autre entretien',
    };
    const severityTag = rec.severity && rec.severity !== 'routine' ? ` [${rec.severity.toUpperCase()}]` : '';
    doc.text((typeNames[rec.type] || rec.type) + severityTag, 42, currentY + 5);
    doc.text(`${rec.mileage.toLocaleString()} km`, 78, currentY + 5);
    doc.text(rec.cost > 0 ? `${rec.cost} ${currency}` : '—', 110, currentY + 5);

    const statusLabel = rec.status === 'scheduled' ? 'Planifie' : rec.status === 'in_progress' ? 'En cours' : 'Termine';
    const partsCount = rec.parts && rec.parts.length > 0 ? ` (${rec.parts.length} pieces)` : '';
    const summaryText = `${statusLabel}${partsCount}` + (rec.workshop ? ` - ${rec.workshop}` : '');
    const truncated = summaryText.length > 32 ? summaryText.slice(0, 30) + '...' : summaryText;
    doc.text(truncated, 140, currentY + 5);

    currentY += 8;
  });

  if (rows.length === 0) {
    doc.setTextColor(gray[0], gray[1], gray[2]);
    doc.text('Aucun entretien enregistre pour ce vehicule.', 20, currentY + 8);
    currentY += 12;
  }

  // Spare Parts Section (if any parts exist)
  if (allParts.length > 0 && currentY < 235) {
    currentY += 4;
    doc.setFillColor(teal[0], teal[1], teal[2]);
    doc.rect(15, currentY, 180, 6, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('CATALOGUE DES PIECES DE RECHANGE INSTALLEES', 18, currentY + 4.2);
    currentY += 6;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    allParts.slice(0, 5).forEach((p, pIdx) => {
      doc.setTextColor(navy[0], navy[1], navy[2]);
      const partLine = `• ${p.name} (Ref: ${p.reference || 'OEM'}) - Qte: ${p.quantity} x ${p.unitCost} ${currency}`;
      doc.text(partLine, 18, currentY + 4.5);
      currentY += 5;
    });
  }

  // Footer Disclaimer
  doc.setDrawColor(220, 231, 227);
  doc.line(15, 275, 195, 275);
  doc.setFontSize(7.5);
  doc.setTextColor(gray[0], gray[1], gray[2]);
  doc.text(
    "Rapport officiel genere par Siyantek Web Commercial Edition (https://siyantek.app).",
    15,
    281
  );
  doc.text(
    "Avertissement : Ce rapport resume les declarations de maintenance et l'analyse AI Mécanicien indicative. Conservez vos factures physiques d'origine.",
    15,
    286
  );

  doc.save(`Siyantek_${vehicle.brand}_${vehicle.model}_${new Date().toISOString().slice(0, 10)}.pdf`);
}
