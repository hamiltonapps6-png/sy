import React, { useMemo, useState, useRef, useEffect } from 'react';

// Native Android builds must point to the deployed Siyantek API server.
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const apiUrl = (path: string) => `${API_BASE_URL}${path}`;

import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Battery,
  Calendar,
  Car,
  Check,
  CheckCircle2,
  ChevronRight,
  Circle,
  Clock,
  Compass,
  CreditCard,
  Disc,
  Download,
  Droplet,
  Fuel,
  Edit2,
  FileSpreadsheet,
  FileText,
  Filter,
  Gauge,
  HelpCircle,
  Info,
  Layers,
  Lock,
  LogOut,
  Package,
  Plus,
  RefreshCw,
  Search,
  Settings,
  Shield,
  ShieldAlert,
  Tag,
  Trash2,
  TrendingUp,
  Upload,
  User,
  Users,
  Wallet,
  PieChart,
  Wrench,
  X,
  Copy,
  Eye,
} from 'lucide-react';
import {
  Language,
  Currency,
  MaintenanceRecord,
  MaintenanceType,
  MaintenanceStatus,
  MaintenanceSeverity,
  SparePart,
  Reminder,
  SubscriptionTier,
  Vehicle,
  formatLocalizedNumber,
  useSiyantek,
  SiyantekProvider,
} from './context/SiyantekContext';
import { generateVehicleReportPDF } from './utils/pdfGenerator';

const TYPES: { key: MaintenanceType; icon: React.ComponentType<{ size?: number; color?: string; className?: string }> }[] = [
  { key: 'oil', icon: Droplet },
  { key: 'brakes', icon: Disc },
  { key: 'tires', icon: Circle },
  { key: 'inspection', icon: Compass },
  { key: 'battery', icon: Battery },
  { key: 'other', icon: Wrench },
];

const dateLabel = (value: string, language: Language) => {
  try {
    const date = new Date(`${value}T12:00:00`);
    return new Intl.DateTimeFormat(
      language === 'ar' ? 'ar-TN' : language === 'fr' ? 'fr-FR' : 'en-US',
      { day: 'numeric', month: 'short', year: 'numeric' }
    ).format(date);
  } catch {
    return value;
  }
};

const daysSince = (value: string) =>
  Math.max(0, Math.round((Date.now() - new Date(`${value}T12:00:00`).getTime()) / 86400000));

const daysUntil = (value?: string) => {
  if (!value) return null;
  const target = new Date(`${value}T12:00:00`).getTime();
  const diff = Math.round((target - Date.now()) / 86400000);
  return diff;
};

function LogoMark() {
  return (
    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[#08B7AD] shadow-md shadow-[#08B7AD]/30">
      <Activity size={24} color="#ffffff" strokeWidth={2.8} />
    </div>
  );
}

function Golf7Graphic({ className = '' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 540 270"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="golfGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#42D9D0" stopOpacity="0.08" />
          <stop offset="50%" stopColor="#08B7AD" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#42D9D0" stopOpacity="0.85" />
        </linearGradient>
      </defs>
      {/* Outer body line */}
      <path
        d="M 50 160 C 85 95, 150 60, 235 52 L 345 52 C 420 52, 470 82, 508 122 C 522 140, 528 165, 524 190 L 508 202 C 455 212, 255 216, 50 202 Z"
        stroke="url(#golfGrad)"
        strokeWidth="2.5"
      />
      {/* Windshield & A-pillar */}
      <path
        d="M 180 62 L 330 62 C 390 62, 428 88, 458 118 L 265 118 Z"
        stroke="#42D9D0"
        strokeWidth="2"
        strokeOpacity="0.5"
      />
      {/* Golf 7 Angular LED Headlights */}
      <path
        d="M 432 132 Q 476 132 502 140 Q 486 158 444 158 Z"
        stroke="#42D9D0"
        strokeWidth="2.5"
        strokeOpacity="0.8"
      />
      <circle cx="466" cy="144" r="8" stroke="#42D9D0" strokeWidth="2" strokeOpacity="0.85" />
      {/* Twin-slat Chrome Grille */}
      <path
        d="M 388 144 L 438 144 M 392 152 L 442 152"
        stroke="#42D9D0"
        strokeWidth="2"
        strokeOpacity="0.55"
      />
      {/* VW Center Roundel */}
      <circle cx="416" cy="164" r="14" stroke="#42D9D0" strokeWidth="2.2" strokeOpacity="0.75" />
      <path d="M 409 158 L 416 169 L 423 158 M 411 161 L 416 170 L 421 161" stroke="#42D9D0" strokeWidth="1.8" strokeOpacity="0.75" />
      {/* Lower bumper honeycomb intake and lip spoiler */}
      <path
        d="M 368 178 L 496 178 C 506 188, 500 198, 474 204 L 356 204"
        stroke="#08B7AD"
        strokeWidth="2.2"
        strokeOpacity="0.5"
      />
      <path d="M 466 185 L 492 185" stroke="#42D9D0" strokeWidth="2" strokeOpacity="0.7" />
      {/* Hood crease contours */}
      <path d="M 235 62 Q 335 88 434 132" stroke="#42D9D0" strokeWidth="1.5" strokeOpacity="0.4" />
      <path d="M 285 62 Q 370 92 458 136" stroke="#42D9D0" strokeWidth="1.5" strokeOpacity="0.4" />
      {/* Front wheel arch contour */}
      <path
        d="M 315 206 C 315 168, 372 168, 372 206"
        stroke="#08B7AD"
        strokeWidth="2.8"
        strokeOpacity="0.55"
      />
      <circle cx="343" cy="206" r="17" stroke="#42D9D0" strokeWidth="1.6" strokeOpacity="0.4" />
    </svg>
  );
}

function CurrencyPicker() {
  const { currency, setCurrency } = useSiyantek();
  const currencies: { key: Currency; label: string }[] = [
    { key: 'TND', label: 'TND' },
    { key: 'EUR', label: 'EUR' },
    { key: 'USD', label: 'USD' },
  ];

  return (
    <div className="flex items-center rounded-xl bg-white/10 p-0.5 border border-white/15 backdrop-blur-xs text-xs font-semibold">
      {currencies.map((c) => (
        <button
          key={c.key}
          onClick={() => setCurrency(c.key)}
          className={`px-2 py-1 rounded-lg transition-all cursor-pointer ${
            currency === c.key
              ? 'bg-[#08B7AD] text-white shadow-xs'
              : 'text-white/70 hover:text-white'
          }`}
        >
          {c.label}
        </button>
      ))}
    </div>
  );
}

function LanguagePicker() {
  const { language, setLanguage } = useSiyantek();
  const languages: { key: Language; label: string }[] = [
    { key: 'fr', label: 'FR' },
    { key: 'ar', label: 'عربي' },
  ];

  return (
    <div className="flex items-center rounded-xl bg-white/10 p-0.5 border border-white/15 backdrop-blur-xs text-xs font-semibold">
      {languages.map((l) => (
        <button
          key={l.key}
          onClick={() => setLanguage(l.key)}
          className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
            language === l.key
              ? 'bg-[#08B7AD] text-white shadow-xs font-bold'
              : 'text-white/70 hover:text-white'
          }`}
        >
          {l.label}
        </button>
      ))}
    </div>
  );
}

function SiyantekDashboard() {
  const {
    language,
    setLanguage,
    currency,
    setCurrency,
    isRTL,
    t,
    formatMoney,
    user,
    isLoggedIn,
    tierLimits,
    vehicles,
    activeVehicle,
    activeVehicleId,
    setActiveVehicleId,
    addVehicle,
    updateVehicle,
    deleteVehicle,
    records,
    addRecord,
    updateRecord,
    deleteRecord,
    reminders,
    addReminder,
    toggleReminder,
    deleteReminder,
    upgradeSubscription,
    logout,
    resetAllData,
    exportData,
    exportDataAsCSV,
    isAdmin,
    myPayments,
    fetchMyPayments,
    createManualOrder,
    uploadReceipt,
  } = useSiyantek();

  // Navigation tabs (6 simplified core sections for private car owners)
  const [activeTab, setActiveTab] = useState<
    'overview' | 'vehicles' | 'history' | 'reminders' | 'expenses' | 'reports' | 'settings'
  >('overview');

  // Dedicated Expense Tracker states
  const [expenseVehicleFilter, setExpenseVehicleFilter] = useState<string>('all');
  const [expenseYearFilter, setExpenseYearFilter] = useState<number>(new Date().getFullYear());

  // Modals
  const [addRecordModalOpen, setAddRecordModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<MaintenanceRecord | null>(null);
  const [vehicleModalOpen, setVehicleModalOpen] = useState(false);
  const [vehicleToEdit, setVehicleToEdit] = useState<Vehicle | null>(null);
  const [reminderModalOpen, setReminderModalOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [privacyModalOpen, setPrivacyModalOpen] = useState(false);
  const [legalTab, setLegalTab] = useState<'privacy' | 'terms'>('privacy');
  const [supportModalOpen, setSupportModalOpen] = useState(false);
  const [manualPaymentModalOpen, setManualPaymentModalOpen] = useState(false);
  const [selectedTierForOrder, setSelectedTierForOrder] = useState<'plus' | 'pro'>('plus');
  const [adminModalOpen, setAdminModalOpen] = useState(false);

  // Subscription plan feedback state
  const [planFeedback, setPlanFeedback] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [isUpgradingPlan, setIsUpgradingPlan] = useState(false);

  const handleUpgradePlan = async (tier: 'free' | 'plus' | 'pro') => {
    setPlanFeedback(null);
    if (tier === 'free') {
      setIsUpgradingPlan(true);
      const res = await upgradeSubscription(tier);
      setIsUpgradingPlan(false);
      if (!res.success) {
        setPlanFeedback({ message: res.error || (language === 'ar' ? 'فشل التبديل إلى المجانية' : 'Échec du changement de formule'), type: 'error' });
      } else {
        setPlanFeedback({ message: res.message || (language === 'ar' ? 'تم اختيار الباقة المجانية بنجاح' : 'Formule Free activée'), type: 'success' });
      }
      return;
    }

    if (!isLoggedIn) {
      setAuthModalOpen(true);
      return;
    }

    // Open Tunisian manual payment flow for Plus & Pro
    setSelectedTierForOrder(tier);
    setManualPaymentModalOpen(true);
    fetchMyPayments();
  };

  // Odometer quick update
  const [mileageDraft, setMileageDraft] = useState('');
  const [mileageError, setMileageError] = useState('');
  const [mileageSuccess, setMileageSuccess] = useState('');
  const [isUpdatingMileage, setIsUpdatingMileage] = useState(false);

  // History Search & Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterDateRange, setFilterDateRange] = useState<string>('all');

  // Reminder filter: pending vs completed
  const [reminderTab, setReminderTab] = useState<'pending' | 'completed'>('pending');

  // Calculations
  const sortedRecords = useMemo(
    () => [...records].sort((a, b) => b.date.localeCompare(a.date)),
    [records]
  );
  const activeVehicleRecords = useMemo(
    () => sortedRecords.filter((r) => !r.vehicleId || r.vehicleId === activeVehicle?.id),
    [sortedRecords, activeVehicle]
  );
  const latestVehicleRecord = activeVehicleRecords[0] || sortedRecords[0];
  const currentMileage = activeVehicle?.mileage || 0;

  // Next service target calculation based on latest record and active reminders
  const scheduledTarget = useMemo(() => {
    const fromRecord = latestVehicleRecord?.nextMileage;
    const vehicleReminders = reminders.filter(
      (r) => !r.completed && (!r.vehicleId || r.vehicleId === activeVehicle?.id) && r.dueMileage && r.dueMileage > 0
    );
    const fromReminder = vehicleReminders.length > 0
      ? Math.min(...vehicleReminders.map((r) => r.dueMileage!))
      : undefined;

    if (fromRecord && fromReminder) {
      return Math.min(fromRecord, fromReminder);
    }
    return fromRecord || fromReminder || null;
  }, [latestVehicleRecord, reminders, activeVehicle]);

  const hasScheduledMaintenance = Boolean(scheduledTarget);
  const targetMaintenanceMileage = scheduledTarget || (currentMileage + 5000);

  // Last known maintenance mileage (base of current cycle)
  const lastMaintenanceMileage = useMemo(() => {
    if (latestVehicleRecord?.mileage && latestVehicleRecord.mileage <= currentMileage) {
      return latestVehicleRecord.mileage;
    }
    return Math.max(0, targetMaintenanceMileage - 10000);
  }, [latestVehicleRecord, currentMileage, targetMaintenanceMileage]);

  // Total interval between last service and target
  const totalMaintenanceInterval = Math.max(1000, targetMaintenanceMileage - lastMaintenanceMileage);

  // Raw remaining distance (negative if overdue)
  const rawDistanceRemaining = targetMaintenanceMileage - currentMileage;
  const isOverdue = hasScheduledMaintenance && rawDistanceRemaining <= 0;
  const overdueKm = Math.abs(rawDistanceRemaining);
  const isUpcoming = hasScheduledMaintenance && !isOverdue && rawDistanceRemaining <= 1500;
  const isOnTrack = hasScheduledMaintenance && !isOverdue && rawDistanceRemaining > 1500;

  // Progress percentage (0 to 100)
  const progressPct = useMemo(() => {
    if (!hasScheduledMaintenance) return 0;
    if (isOverdue) return 100;
    const elapsed = Math.max(0, currentMileage - lastMaintenanceMileage);
    return Math.min(100, Math.max(0, Math.round((elapsed / totalMaintenanceInterval) * 100)));
  }, [hasScheduledMaintenance, isOverdue, currentMileage, lastMaintenanceMileage, totalMaintenanceInterval]);

  const distanceToNext = Math.max(0, rawDistanceRemaining);
  const nextMileage = targetMaintenanceMileage;
  const serviceProgress = progressPct / 100;
  const totalCost = useMemo(() => records.reduce((sum, r) => sum + (r.cost || 0), 0), [records]);

  // Spare parts metrics
  const totalPartsCount = useMemo(() => {
    return records.reduce((acc, r) => acc + (r.parts ? r.parts.reduce((pAcc, p) => pAcc + p.quantity, 0) : 0), 0);
  }, [records]);

  // Reminders metrics
  const pendingReminders = useMemo(() => reminders.filter((r) => !r.completed), [reminders]);
  const completedReminders = useMemo(() => reminders.filter((r) => r.completed), [reminders]);
  
  const overdueCount = useMemo(() => {
    return pendingReminders.filter((r) => {
      if (r.dueDate && daysUntil(r.dueDate)! < 0) return true;
      if (r.dueMileage && currentMileage >= r.dueMileage) return true;
      return false;
    }).length;
  }, [pendingReminders, currentMileage]);

  // Filtered records for History tab
  const filteredRecords = useMemo(() => {
    return sortedRecords.filter((rec) => {
      // Search term
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchesWorkshop = (rec.workshop || '').toLowerCase().includes(q);
        const matchesNotes = (rec.notes || '').toLowerCase().includes(q);
        const matchesType = rec.type.toLowerCase().includes(q);
        const matchesParts = (rec.parts || []).some(
          (p) => p.name.toLowerCase().includes(q) || (p.reference || '').toLowerCase().includes(q)
        );
        if (!matchesWorkshop && !matchesNotes && !matchesType && !matchesParts) {
          return false;
        }
      }
      // Category filter
      if (filterType !== 'all' && rec.type !== filterType) {
        return false;
      }
      // Status filter
      if (filterStatus !== 'all' && (rec.status || 'completed') !== filterStatus) {
        return false;
      }
      // Date filter
      if (filterDateRange !== 'all') {
        const days = daysSince(rec.date);
        if (filterDateRange === 'last30' && days > 30) return false;
        if (filterDateRange === 'last90' && days > 90) return false;
        if (filterDateRange === 'thisYear') {
          const recYear = new Date(rec.date).getFullYear();
          if (recYear !== new Date().getFullYear()) return false;
        }
      }
      return true;
    });
  }, [sortedRecords, searchTerm, filterType, filterStatus, filterDateRange]);

  const filteredCost = useMemo(() => {
    return filteredRecords.reduce((sum, r) => sum + (r.cost || 0), 0);
  }, [filteredRecords]);

  // Dedicated Expense Tracker calculations
  const currentCalendarYear = new Date().getFullYear();
  const currentCalendarMonthStr = new Date().toISOString().slice(0, 7);

  const filteredExpenseRecords = useMemo(() => {
    return records.filter((r) => {
      if (expenseVehicleFilter !== 'all' && r.vehicleId !== expenseVehicleFilter) {
        return false;
      }
      return true;
    });
  }, [records, expenseVehicleFilter]);

  const yearExpenseRecords = useMemo(() => {
    return filteredExpenseRecords.filter((r) => r.date.startsWith(String(expenseYearFilter)));
  }, [filteredExpenseRecords, expenseYearFilter]);

  const monthExpenseRecords = useMemo(() => {
    return filteredExpenseRecords.filter((r) => r.date.startsWith(currentCalendarMonthStr));
  }, [filteredExpenseRecords, currentCalendarMonthStr]);

  const totalExpenseAllTime = useMemo(
    () => filteredExpenseRecords.reduce((sum, r) => sum + (r.cost || 0), 0),
    [filteredExpenseRecords]
  );

  const totalExpenseYear = useMemo(
    () => yearExpenseRecords.reduce((sum, r) => sum + (r.cost || 0), 0),
    [yearExpenseRecords]
  );

  const totalExpenseMonth = useMemo(
    () => monthExpenseRecords.reduce((sum, r) => sum + (r.cost || 0), 0),
    [monthExpenseRecords]
  );

  const currentMonthIndex = new Date().getMonth();
  const monthlyAverageExpense = useMemo(() => {
    const divisor = expenseYearFilter === currentCalendarYear ? currentMonthIndex + 1 : 12;
    return divisor > 0 ? Math.round(totalExpenseYear / divisor) : 0;
  }, [totalExpenseYear, expenseYearFilter, currentCalendarYear, currentMonthIndex]);

  // Breakdown by maintenance type for expenses view
  const expensesByType = useMemo(() => {
    const base = TYPES.map((tp) => {
      const typeRecords = yearExpenseRecords.filter((r) => r.type === tp.key);
      const cost = typeRecords.reduce((sum, r) => sum + (r.cost || 0), 0);
      return {
        key: tp.key,
        icon: tp.icon,
        cost,
        count: typeRecords.length,
        pct: totalExpenseYear > 0 ? Math.round((cost / totalExpenseYear) * 100) : 0,
      };
    });
    return base.sort((a, b) => b.cost - a.cost);
  }, [yearExpenseRecords, totalExpenseYear]);

  // Monthly distribution for the selected year
  const monthlyDistribution = useMemo(() => {
    const monthNamesFr = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
    const monthNamesAr = ['جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان', 'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const list = Array.from({ length: 12 }, (_, i) => {
      const monthNum = String(i + 1).padStart(2, '0');
      const prefix = `${expenseYearFilter}-${monthNum}`;
      const recs = filteredExpenseRecords.filter((r) => r.date.startsWith(prefix));
      const amount = recs.reduce((sum, r) => sum + (r.cost || 0), 0);
      return {
        month: i,
        label: language === 'ar' ? monthNamesAr[i] : monthNamesFr[i],
        amount,
        count: recs.length,
      };
    });
    const maxAmount = Math.max(1, ...list.map((m) => m.amount));
    return list.map((m) => ({ ...m, maxAmount }));
  }, [filteredExpenseRecords, expenseYearFilter, language]);

  // Handle quick odometer save with integer validation, decreasing mileage check and server persistence
  const handleSaveMileage = async () => {
    if (!activeVehicle) return;
    const cleanStr = mileageDraft.trim();
    if (!cleanStr) {
      setMileageError(
        language === 'ar'
          ? 'يرجى إدخال قراءة العداد بالكيلومتر.'
          : 'Veuillez saisir une valeur de kilométrage.'
      );
      return;
    }

    const val = Number(cleanStr);
    // Validate positive integer
    if (!Number.isFinite(val) || val <= 0 || !Number.isInteger(val)) {
      setMileageError(
        language === 'ar'
          ? 'يرجى إدخال عدد صحيح موجب للمسافة بالكيلومتر.'
          : 'Veuillez saisir un nombre entier positif valide.'
      );
      return;
    }

    // Coherence check: same value
    if (val === activeVehicle.mileage) {
      setMileageError(
        language === 'ar'
          ? 'القيمة المدخلة مطابقة للمسافة المسجلة حالياً.'
          : 'Le kilométrage saisi est identique au relevé actuel.'
      );
      return;
    }

    // Coherence check: decreasing value
    if (val < activeVehicle.mileage) {
      setMileageError(
        language === 'ar'
          ? `لا يمكن أن يكون العداد أقل من المسافة الحالية (${formatLocalizedNumber(activeVehicle.mileage, language)} كم).`
          : `Le kilométrage ne peut pas être inférieur au relevé actuel (${formatLocalizedNumber(activeVehicle.mileage, language)} km).`
      );
      return;
    }

    // Coherence check: unrealistic jump
    if (val > activeVehicle.mileage + 150000) {
      setMileageError(
        language === 'ar'
          ? 'الزيادة المدخلة تبدو كبيرة جداً وغير منطقية. يرجى التثبت.'
          : 'L\'augmentation saisie semble anormalement élevée. Veuillez vérifier.'
      );
      return;
    }

    setIsUpdatingMileage(true);
    setMileageError('');
    setMileageSuccess('');

    try {
      const res = await updateVehicle({ ...activeVehicle, mileage: val });
      if (res && !res.success) {
        setMileageError(res.error || (language === 'ar' ? 'فشل حفظ الكيلومترات' : 'Échec de la mise à jour'));
      } else {
        setMileageDraft('');
        setMileageSuccess(
          language === 'ar'
            ? `تم تحديث العداد إلى ${formatLocalizedNumber(val, language)} كم بنجاح`
            : `Kilométrage mis à jour à ${formatLocalizedNumber(val, language)} km avec succès`
        );
        setTimeout(() => {
          setMileageSuccess('');
        }, 4000);
      }
    } catch (err: any) {
      setMileageError(err?.message || (language === 'ar' ? 'حدث خطأ أثناء التحديث' : 'Erreur lors de la mise à jour'));
    } finally {
      setIsUpdatingMileage(false);
    }
  };

  // Generate PDF report handler
  const handleGeneratePDF = () => {
    if (!activeVehicle) return;
    generateVehicleReportPDF({
      vehicle: activeVehicle,
      records,
      language,
      userTier: user?.tier || 'free',
      currency: currency === 'TND' ? 'DT' : currency === 'EUR' ? '€' : '$',
    });
  };

  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className="min-h-screen bg-[#F2F8FA] text-[#123441] font-sans flex flex-col antialiased selection:bg-[#08B7AD]/20 pb-20 md:pb-6"
    >
      {/* ============================================================== */}
      {/* 1. TOP HEADER / APP BAR (Reference Theme)                      */}
      {/* ============================================================== */}
      <header className="sticky top-0 z-30 bg-gradient-to-r from-[#062B36] via-[#073642] to-[#0A4250] text-white border-b border-white/10 px-4 py-3 shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <LogoMark />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-xl tracking-tight text-white">
                  {t('appName')}
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#08B7AD]/20 text-[#42D9D0] border border-[#08B7AD]/30">
                  {t('commercialBadge')}
                </span>
              </div>
              <p className="text-xs text-[#93B5BD] font-medium hidden sm:block">{t('tagline')}</p>
            </div>
          </div>

          {/* Right Controls: Currency, Language & Profile Avatar Button */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="hidden lg:block">
              <CurrencyPicker />
            </div>
            <div>
              <LanguagePicker />
            </div>

            {/* Direct Support Button */}
            <button
              onClick={() => setSupportModalOpen(true)}
              className="h-10 w-10 rounded-full bg-[#0E3E4B] hover:bg-[#124d5d] border border-white/15 text-white flex items-center justify-center shadow-sm transition-all cursor-pointer"
              title={t('contactSupport')}
            >
              <HelpCircle size={18} className="text-[#42D9D0]" />
            </button>

            {/* Admin Back-Office Button */}
            {isAdmin && (
              <button
                onClick={() => setAdminModalOpen(true)}
                className="h-10 px-3 rounded-full bg-[#16A6A0] hover:bg-[#138e89] border border-white/20 text-white flex items-center gap-1.5 shadow-sm transition-all cursor-pointer text-xs font-bold"
                title={t('adminDashboard')}
              >
                <Shield size={16} className="text-white" />
                <span className="hidden sm:inline">Admin</span>
              </button>
            )}

            {/* User Profile Avatar Button */}
            <button
              onClick={() => setAuthModalOpen(true)}
              className="h-10 w-10 rounded-full bg-[#0E3E4B] hover:bg-[#124d5d] border border-white/15 text-white flex items-center justify-center shadow-sm transition-all cursor-pointer relative"
              title={isLoggedIn ? user?.email : t('login')}
            >
              {isLoggedIn ? (
                <div className="h-full w-full rounded-full bg-[#08B7AD] text-white flex items-center justify-center text-sm font-bold">
                  {user?.name?.slice(0, 1).toUpperCase() || 'U'}
                </div>
              ) : (
                <User size={18} className="text-white/90" />
              )}
              {isLoggedIn && (
                <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-[#34D399] ring-2 ring-[#062B36]" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* ============================================================== */}
      {/* 2. DESKTOP NAVIGATION TABS (AI Mechanic Completely Removed)     */}
      {/* ============================================================== */}
      <div className="hidden md:block bg-white border-b border-[#DCE7E3]">
        <div className="max-w-7xl mx-auto px-4 flex items-center space-x-1 rtl:space-x-reverse overflow-x-auto py-1">
          {[
            { id: 'overview', label: t('overview'), icon: Gauge },
            { id: 'vehicles', label: t('vehicles'), icon: Car, count: vehicles.length },
            { id: 'history', label: t('history'), icon: Wrench, count: records.length },
            { id: 'reminders', label: t('reminders'), icon: Clock, count: pendingReminders.length, alert: overdueCount > 0 },
            { id: 'expenses', label: t('expenses'), icon: Wallet },
            { id: 'reports', label: t('reports'), icon: FileText },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#16A6A0]/10 text-[#16A6A0] border-b-2 border-[#16A6A0]'
                    : 'text-[#668087] hover:text-[#102A35] hover:bg-[#F4F7F5]'
                }`}
              >
                <Icon size={16} className={isActive ? 'text-[#16A6A0]' : 'text-[#668087]'} />
                <span>{item.label}</span>
                {item.count !== undefined && item.count > 0 && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      item.alert
                        ? 'bg-[#C94E4E] text-white animate-pulse'
                        : isActive
                        ? 'bg-[#16A6A0] text-white'
                        : 'bg-[#EDF2F0] text-[#668087]'
                    }`}
                  >
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ============================================================== */}
      {/* 3. MAIN WORKSPACE / CONTENT VIEWS                              */}
      {/* ============================================================== */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-6">


            {/* Hero Vehicle Card (Matching Reference Image) */}
            {activeVehicle ? (
              <div className="bg-[#062B36] text-white rounded-3xl p-5 sm:p-7 shadow-xl border border-white/10 relative overflow-hidden transition-all">
                {/* Background Golf 7 vector graphic illustration */}
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-80 sm:w-[420px] pointer-events-none select-none opacity-25 rtl:right-auto rtl:left-0 rtl:scale-x-[-1] overflow-hidden">
                  <Golf7Graphic className="w-full h-auto" />
                </div>

                <div className="relative z-10">
                  {/* Top informative badges */}
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    {Boolean(activeVehicle.year) && (
                      <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0B3945]/85 text-white/95 text-xs font-semibold border border-white/10 shadow-xs">
                        <Calendar size={13} className="text-[#42D9D0] shrink-0" />
                        <span>{activeVehicle.year}</span>
                      </div>
                    )}
                    {Boolean(activeVehicle.motorization || activeVehicle.fuelType) && (
                      <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0B3945]/85 text-white/95 text-xs font-semibold border border-white/10 shadow-xs">
                        <Fuel size={13} className="text-[#42D9D0] shrink-0" />
                        <span>
                          {activeVehicle.motorization ? `${activeVehicle.motorization} • ` : ''}
                          {activeVehicle.fuelType === 'essence'
                            ? (language === 'ar' ? 'بنزين' : 'Essence')
                            : activeVehicle.fuelType === 'diesel'
                            ? (language === 'ar' ? 'ديزل' : 'Diesel')
                            : activeVehicle.fuelType === 'hybride'
                            ? (language === 'ar' ? 'هجين' : 'Hybride')
                            : activeVehicle.fuelType === 'electrique'
                            ? (language === 'ar' ? 'كهربائي' : 'Électrique')
                            : activeVehicle.fuelType}
                        </span>
                      </div>
                    )}
                    {Boolean(activeVehicle.plate) && (
                      <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0B3945]/85 text-white/95 text-xs font-mono font-bold tracking-wider border border-white/10 shadow-xs">
                        <CreditCard size={13} className="text-[#42D9D0] shrink-0" />
                        <span>{language === 'ar' ? `اللوحة : ${activeVehicle.plate}` : `Immat. : ${activeVehicle.plate}`}</span>
                      </div>
                    )}
                  </div>

                  {/* Vehicle Model Name */}
                  <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
                    {activeVehicle.brand} {activeVehicle.model}
                  </h2>

                  {/* Current mileage gauge & value */}
                  <div className="flex items-center gap-3.5 mb-5">
                    <Gauge size={38} className="text-[#08B7AD] shrink-0" strokeWidth={2.2} />
                    <div>
                      <span className="text-xs sm:text-sm font-medium text-white/70 block mb-0.5">
                        {t('currentMileage')}
                      </span>
                      <span className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                        {formatLocalizedNumber(activeVehicle.mileage, language)} km
                      </span>
                    </div>
                  </div>

                  {/* Odometer quick update box */}
                  <div className="bg-[#083542]/75 backdrop-blur-md p-4 sm:p-5 rounded-2xl border border-white/10 shadow-inner mb-6">
                    <label className="block text-xs font-semibold text-white/90 mb-2">
                      {t('currentMileage')}
                    </label>
                    <div className="flex flex-col sm:flex-row gap-2.5">
                      <input
                        type="number"
                        min="1"
                        step="1"
                        inputMode="numeric"
                        placeholder={`${activeVehicle.mileage}`}
                        value={mileageDraft}
                        onChange={(e) => {
                          setMileageDraft(e.target.value);
                          setMileageError('');
                          setMileageSuccess('');
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            handleSaveMileage();
                          }
                        }}
                        disabled={isUpdatingMileage}
                        className="w-full h-11 bg-[#05232C] hover:bg-[#041d24] border border-white/15 focus:border-[#08B7AD] text-white placeholder-white/40 rounded-xl px-4 text-base font-semibold focus:outline-none focus:ring-2 focus:ring-[#08B7AD]/40 transition-all"
                      />
                      <button
                        onClick={handleSaveMileage}
                        disabled={isUpdatingMileage || !mileageDraft || Number(mileageDraft) === activeVehicle.mileage}
                        className={`h-11 px-5 rounded-xl text-sm font-bold transition-all shadow-sm flex items-center justify-center gap-2 shrink-0 ${
                          isUpdatingMileage || !mileageDraft || Number(mileageDraft) === activeVehicle.mileage
                            ? 'bg-white/15 text-white/40 cursor-not-allowed'
                            : 'bg-[#08B7AD] hover:bg-[#079f96] active:scale-[0.98] text-white cursor-pointer hover:shadow-md'
                        }`}
                      >
                        <RefreshCw size={16} className={isUpdatingMileage ? 'animate-spin' : ''} />
                        <span>{isUpdatingMileage ? t('updatingMileage') : (language === 'ar' ? 'تحديث' : 'Mettre à jour')}</span>
                      </button>
                    </div>

                    {mileageError && (
                      <div className="mt-2.5 p-2.5 rounded-xl bg-[#E24B4B]/20 border border-[#E24B4B]/40 flex items-start gap-2 text-[12px] text-[#FFA5A5] font-medium leading-tight">
                        <AlertCircle size={15} className="shrink-0 mt-0.5 text-[#FF7676]" />
                        <span>{mileageError}</span>
                      </div>
                    )}
                    {mileageSuccess && (
                      <div className="mt-2.5 p-2.5 rounded-xl bg-[#2B9A70]/20 border border-[#2B9A70]/40 flex items-start gap-2 text-[12px] text-[#A7F3D0] font-medium leading-tight">
                        <CheckCircle2 size={15} className="shrink-0 mt-0.5 text-[#34D399]" />
                        <span>{mileageSuccess}</span>
                      </div>
                    )}
                  </div>

                  {/* Prochaine révision / Next maintenance section */}
                  <div className="pt-1">
                    {hasScheduledMaintenance ? (
                      <div>
                        <div className="flex items-start gap-3.5 mb-3">
                          <div className="w-12 h-12 rounded-2xl bg-[#0E4754] flex items-center justify-center text-[#42D9D0] shrink-0 shadow-xs">
                            <Wrench size={22} strokeWidth={2.3} />
                          </div>
                          <div className="flex-1">
                            <span className="text-xs sm:text-sm font-medium text-white/80 block mb-1">
                              {t('nextRevision')}
                            </span>
                            <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#08B7AD] text-white text-xs sm:text-sm font-bold shadow-xs">
                              <Compass size={14} className="text-white" />
                              <span>
                                {isOverdue
                                  ? `${t('overdueBy')} ${formatLocalizedNumber(overdueKm, language)} km`
                                  : `${t('dueInDistance')} ${formatLocalizedNumber(rawDistanceRemaining, language)} km`}
                              </span>
                            </div>
                            <p className="text-xs text-white/80 font-semibold mt-1.5">
                              {t('target')} : <strong className="text-white font-bold">{formatLocalizedNumber(targetMaintenanceMileage, language)} km</strong>
                            </p>
                          </div>
                        </div>

                        {/* Progress bar and percentage */}
                        <div className="mt-4 flex items-center gap-3">
                          <div className="flex-1 h-2.5 bg-[#0E4754] rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all duration-700 ease-out ${
                                isOverdue
                                  ? 'bg-[#E24B4B]'
                                  : isUpcoming
                                  ? 'bg-[#F2B45C]'
                                  : 'bg-[#08B7AD]'
                              }`}
                              style={{ width: `${progressPct}%` }}
                            />
                          </div>
                          <span className="text-xs sm:text-sm font-bold text-white/90 shrink-0">
                            {progressPct} %
                          </span>
                        </div>

                        {/* Status note */}
                        <div className="mt-3 flex items-center gap-2 text-xs text-[#42D9D0] font-medium">
                          <Clock size={14} className="text-[#42D9D0]" />
                          <span>
                            {isOverdue
                              ? t('serviceNeededNow')
                              : t('serviceUpcomingAlert')}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white/5 rounded-2xl p-3.5 border border-white/10">
                        <div className="flex items-center gap-2.5">
                          <Info size={18} className="text-[#08B7AD] shrink-0" />
                          <div>
                            <p className="text-xs font-semibold text-white/90">
                              {t('noMaintenanceScheduled')}
                            </p>
                            <p className="text-[11px] text-white/60">
                              {language === 'ar'
                                ? 'سجّل موعد الصيانة القادم أو أضف تذكيراً لمتابعة استهلاك الكيلومترات.'
                                : 'Enregistrez votre prochaine vidange ou ajoutez un rappel pour suivre l\'échéance.'}
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setEditingRecord(null);
                            setAddRecordModalOpen(true);
                          }}
                          className="self-start sm:self-auto px-3.5 py-1.5 rounded-xl bg-[#08B7AD] hover:bg-[#079f96] text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          <Plus size={14} />
                          <span>{t('planMaintenance')}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-8 text-center border border-[#DCE7E3]">
                <Car size={48} className="mx-auto text-[#668087] mb-3" />
                <h3 className="font-bold text-lg">{t('noRecords')}</h3>
                <p className="text-sm text-[#668087] mb-4">{t('noRecordsHint')}</p>
                <button
                  onClick={() => setVehicleModalOpen(true)}
                  className="px-4 py-2 bg-[#08B7AD] text-white rounded-lg text-sm font-bold cursor-pointer"
                >
                  {t('addVehicle')}
                </button>
              </div>
            )}

            {/* Last Performed Maintenance Card (Dernier entretien) */}
            {latestVehicleRecord && (
              <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#E0EBEF] shadow-xs hover:border-[#16A6A0]/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start sm:items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-[#E7EFEC] text-[#16A6A0] flex items-center justify-center shrink-0 shadow-xs">
                    {(() => {
                      const TypeIcon = TYPES.find((tp) => tp.key === latestVehicleRecord.type)?.icon || Wrench;
                      return <TypeIcon size={22} strokeWidth={2.2} />;
                    })()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-[#16A6A0]">
                        {t('lastService')}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EDF2F0] text-[#668087] font-semibold">
                        {dateLabel(latestVehicleRecord.date, language)}
                      </span>
                    </div>
                    <h3 className="font-extrabold text-base text-[#102A35]">
                      {t(latestVehicleRecord.type)}
                      {latestVehicleRecord.workshop ? ` • ${latestVehicleRecord.workshop}` : ''}
                    </h3>
                    <p className="text-xs text-[#668087] mt-0.5">
                      {formatLocalizedNumber(latestVehicleRecord.mileage, language)} km
                      {latestVehicleRecord.cost > 0 ? ` • ${formatMoney(latestVehicleRecord.cost)}` : ''}
                      {latestVehicleRecord.parts && latestVehicleRecord.parts.length > 0
                        ? ` • ${latestVehicleRecord.parts.length} ${language === 'ar' ? 'قطع مستبدلة' : 'pièces'}`
                        : ''}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('history')}
                  className="self-end sm:self-auto text-xs font-bold text-[#16A6A0] hover:text-[#138e89] flex items-center gap-1 cursor-pointer"
                >
                  <span>{t('viewHistoryDetails')}</span>
                  <ChevronRight size={16} className="rtl:rotate-180" />
                </button>
              </div>
            )}

            {/* Prominent Primary Call-To-Action: + إضافة صيانة جديدة */}
            <div className="space-y-2.5">
              <button
                onClick={() => {
                  setEditingRecord(null);
                  setAddRecordModalOpen(true);
                }}
                className="w-full min-h-[50px] p-3.5 bg-gradient-to-r from-[#16A6A0] to-[#08B7AD] hover:from-[#138e89] hover:to-[#079f96] text-white rounded-2xl text-sm font-extrabold shadow-md hover:shadow-lg flex items-center justify-center gap-2.5 transition-all transform active:scale-[0.99] cursor-pointer"
              >
                <Plus size={20} strokeWidth={2.5} />
                <span>{language === 'ar' ? '+ إضافة صيانة جديدة' : '+ Nouvel entretien'}</span>
              </button>

              {/* Quick Companion Buttons */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={() => setReminderModalOpen(true)}
                  className="min-h-[44px] flex items-center justify-center gap-2 p-2.5 bg-white hover:bg-[#F4F7F5] text-[#102A35] border border-[#DCE7E3] rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
                >
                  <Clock size={16} className="text-[#16A6A0]" />
                  <span>{t('addReminder')}</span>
                </button>

                <button
                  onClick={handleGeneratePDF}
                  className="min-h-[44px] flex items-center justify-center gap-2 p-2.5 bg-white hover:bg-[#F4F7F5] text-[#102A35] border border-[#DCE7E3] rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
                >
                  <FileText size={16} className="text-[#16A6A0]" />
                  <span>{t('downloadPdf')}</span>
                </button>
              </div>
            </div>

            {/* Upcoming Reminders Section */}
            {pendingReminders.length > 0 && (
              <div className="bg-white rounded-2xl p-5 border border-[#DCE7E3] shadow-xs">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Clock size={18} className="text-[#16A6A0]" />
                    <h3 className="font-bold text-base text-[#102A35]">{t('reminders')}</h3>
                  </div>
                  <button
                    onClick={() => setActiveTab('reminders')}
                    className="text-xs text-[#16A6A0] font-bold hover:underline cursor-pointer"
                  >
                    {t('viewAll')}
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {pendingReminders.slice(0, 3).map((rem) => {
                    const days = daysUntil(rem.dueDate);
                    const isOverdue = (days !== null && days < 0) || (rem.dueMileage && currentMileage >= rem.dueMileage);
                    const isSoon = days !== null && days >= 0 && days <= 30;
                    return (
                      <div
                        key={rem.id}
                        className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between ${
                          isOverdue
                            ? 'bg-[#FDF2F2] border-[#F2C2C2]'
                            : isSoon
                            ? 'bg-[#FFF9EE] border-[#F5E2B8]'
                            : 'bg-[#F8FAF9] border-[#EDF2F0]'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <span className="font-bold text-xs text-[#102A35] truncate">{rem.title}</span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${
                                isOverdue
                                  ? 'bg-[#C94E4E] text-white'
                                  : isSoon
                                  ? 'bg-[#F2B45C] text-[#5C3B00]'
                                  : 'bg-[#E7EFEC] text-[#16A6A0]'
                              }`}
                            >
                              {isOverdue ? t('overdue') : isSoon ? t('upcoming') : t('valid')}
                            </span>
                          </div>
                          <div className="text-[11px] text-[#668087] space-y-1">
                            {rem.dueDate && (
                              <p className="flex items-center gap-1">
                                <Calendar size={12} />
                                <span>{dateLabel(rem.dueDate, language)}</span>
                                {days !== null && (
                                  <strong className={isOverdue ? 'text-[#C94E4E]' : 'text-[#102A35]'}>
                                    ({days < 0 ? (language === 'ar' ? `متأخر بـ ${Math.abs(days)} يوم` : `${Math.abs(days)} j de retard`) : (language === 'ar' ? `بعد ${days} يوم` : `dans ${days} j`)})
                                  </strong>
                                )}
                              </p>
                            )}
                            {rem.dueMileage && (
                              <p className="flex items-center gap-1">
                                <Gauge size={12} />
                                <span>{formatLocalizedNumber(rem.dueMileage, language)} km</span>
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="mt-3 pt-2.5 border-t border-black/5 flex items-center justify-end">
                          <button
                            onClick={() => toggleReminder(rem.id)}
                            className="text-xs font-semibold px-2.5 py-1 rounded-md bg-white hover:bg-[#EDF2F0] text-[#102A35] transition-colors border border-[#DCE7E3] cursor-pointer"
                          >
                            {t('markDone')}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Recent Maintenance Log Preview */}
            <div className="bg-white rounded-2xl p-5 border border-[#DCE7E3] shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Wrench size={18} className="text-[#16A6A0]" />
                  <h3 className="font-bold text-base text-[#102A35]">{t('recentActivity')}</h3>
                </div>
                <button
                  onClick={() => setActiveTab('history')}
                  className="text-xs text-[#16A6A0] font-bold hover:underline cursor-pointer"
                >
                  {t('viewAll')}
                </button>
              </div>

              {sortedRecords.length === 0 ? (
                <div className="text-center py-6 text-xs text-[#668087]">
                  <p>{t('noRecords')}</p>
                </div>
              ) : (
                <div className="divide-y divide-[#EDF2F0]">
                  {sortedRecords.slice(0, 4).map((rec) => {
                    const TypeIcon = TYPES.find((t) => t.key === rec.type)?.icon || Wrench;
                    return (
                      <div key={rec.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                        <div className="flex items-center gap-3">
                          <div className="h-9 w-9 rounded-xl bg-[#E7EFEC] text-[#16A6A0] flex items-center justify-center shrink-0">
                            <TypeIcon size={18} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-[#102A35]">{t(rec.type)}</span>
                              {rec.workshop && (
                                <span className="text-[#668087] hidden sm:inline">• {rec.workshop}</span>
                              )}
                            </div>
                            <p className="text-[11px] text-[#668087] mt-0.5">
                              {dateLabel(rec.date, language)} • {formatLocalizedNumber(rec.mileage, language)} km
                            </p>
                          </div>
                        </div>
                        <div className="text-end">
                          <strong className="text-sm font-black text-[#102A35]">
                            {formatMoney(rec.cost)}
                          </strong>
                          {rec.parts && rec.parts.length > 0 && (
                            <p className="text-[10px] text-[#8A5B16] font-medium">
                              {rec.parts.length} {language === 'ar' ? 'قطع غيار' : 'pièces'}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VEHICLES TAB                                                   */}
        {/* ============================================================== */}
        {activeTab === 'vehicles' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-[#102A35]">{t('vehicles')}</h2>
                <p className="text-xs text-[#668087]">
                  {vehicles.length} / {tierLimits.maxVehicles} {language === 'ar' ? 'سيارات مسجلة' : 'véhicules enregistrés'}
                </p>
              </div>
              <button
                onClick={() => {
                  setVehicleToEdit(null);
                  setVehicleModalOpen(true);
                }}
                disabled={vehicles.length >= tierLimits.maxVehicles}
                className="px-3.5 py-2 bg-[#16A6A0] disabled:bg-gray-300 hover:bg-[#138e89] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
              >
                <Plus size={16} />
                <span>{t('addVehicle')}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {vehicles.map((v) => {
                const isSelected = v.id === activeVehicleId;
                const vRecords = records.filter((r) => r.vehicleId === v.id);
                const vCost = vRecords.reduce((sum, r) => sum + (r.cost || 0), 0);
                return (
                  <div
                    key={v.id}
                    className={`bg-white rounded-2xl p-5 border transition-all relative flex flex-col justify-between ${
                      isSelected ? 'border-[#16A6A0] shadow-sm ring-1 ring-[#16A6A0]' : 'border-[#DCE7E3] hover:border-[#16A6A0]/50'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-bold text-[#16A6A0] bg-[#E7EFEC] px-2.5 py-0.5 rounded-full">
                          {v.year || 'N/A'}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setVehicleToEdit(v);
                              setVehicleModalOpen(true);
                            }}
                            className="p-1.5 text-[#668087] hover:text-[#16A6A0] rounded-md transition-colors cursor-pointer"
                            title={t('editVehicle')}
                          >
                            <Edit2 size={15} />
                          </button>
                          {vehicles.length > 1 && (
                            <button
                              onClick={() => {
                                if (confirm(t('confirmDeleteVehicle'))) {
                                  deleteVehicle(v.id);
                                }
                              }}
                              className="p-1.5 text-[#668087] hover:text-[#C94E4E] rounded-md transition-colors cursor-pointer"
                              title={t('deleteVehicle')}
                            >
                              <Trash2 size={15} />
                            </button>
                          )}
                        </div>
                      </div>

                      <h3 className="text-lg font-black text-[#102A35]">
                        {v.brand} {v.model}
                      </h3>
                      <p className="text-xs text-[#668087] mt-0.5 font-mono">
                        {v.plate || 'TN-REG'}
                      </p>

                      <div className="mt-4 pt-3 border-t border-[#EDF2F0] space-y-1.5 text-xs">
                        <div className="flex justify-between">
                          <span className="text-[#668087]">{t('currentMileage')}:</span>
                          <strong className="text-[#102A35]">
                            {formatLocalizedNumber(v.mileage, language)} km
                          </strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#668087]">{t('totalSpent')}:</span>
                          <strong className="text-[#102A35]">{formatMoney(vCost)}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#668087]">{t('recordCount')}:</span>
                          <strong className="text-[#102A35]">{vRecords.length}</strong>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#EDF2F0]">
                      <button
                        onClick={() => setActiveVehicleId(v.id)}
                        className={`w-full py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#16A6A0] text-white shadow-xs'
                            : 'bg-[#F4F7F5] hover:bg-[#EDF2F0] text-[#102A35]'
                        }`}
                      >
                        {isSelected ? t('yourCar') : t('selectVehicle')}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* HISTORY & EXPENSES TAB                                         */}
        {/* ============================================================== */}
        {activeTab === 'history' && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-[#102A35]">{t('history')}</h2>
                <p className="text-xs text-[#668087]">
                  {filteredRecords.length} {t('recordsMatching')} • {formatMoney(filteredCost)}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={exportDataAsCSV}
                  className="px-3 py-1.5 bg-white hover:bg-[#EDF2F0] text-[#102A35] border border-[#DCE7E3] rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <FileSpreadsheet size={15} className="text-[#2B9A70]" />
                  <span>{t('exportCSV')}</span>
                </button>
                <button
                  onClick={() => {
                    setEditingRecord(null);
                    setAddRecordModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Plus size={16} />
                  <span>{t('addMaintenance')}</span>
                </button>
              </div>
            </div>

            {/* Search and Filters Bar */}
            <div className="bg-white p-4 rounded-2xl border border-[#DCE7E3] shadow-xs space-y-3">
              <div className="flex flex-col sm:flex-row gap-3">
                {/* Search */}
                <div className="relative flex-1">
                  <Search size={16} className="absolute start-3 top-3 text-[#668087]" />
                  <input
                    type="text"
                    placeholder={t('searchPlaceholder')}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-xl ps-9 pe-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-[#16A6A0]"
                  />
                </div>

                {/* Filter Category */}
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="bg-[#F4F7F5] border border-[#DCE7E3] rounded-xl px-3 py-2 text-xs font-medium text-[#102A35] cursor-pointer"
                >
                  <option value="all">{t('filterCategory')}</option>
                  {TYPES.map((tp) => (
                    <option key={tp.key} value={tp.key}>
                      {t(tp.key)}
                    </option>
                  ))}
                </select>

                {/* Filter Status */}
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="bg-[#F4F7F5] border border-[#DCE7E3] rounded-xl px-3 py-2 text-xs font-medium text-[#102A35] cursor-pointer"
                >
                  <option value="all">{t('filterStatus')}</option>
                  <option value="completed">{t('statusCompleted')}</option>
                  <option value="in_progress">{t('statusInProgress')}</option>
                  <option value="scheduled">{t('statusScheduled')}</option>
                </select>

                {/* Filter Date */}
                <select
                  value={filterDateRange}
                  onChange={(e) => setFilterDateRange(e.target.value)}
                  className="bg-[#F4F7F5] border border-[#DCE7E3] rounded-xl px-3 py-2 text-xs font-medium text-[#102A35] cursor-pointer"
                >
                  <option value="all">{t('filterDate')}</option>
                  <option value="last30">{t('dateLast30')}</option>
                  <option value="last90">{t('dateLast90')}</option>
                  <option value="thisYear">{t('dateThisYear')}</option>
                </select>
              </div>

              {(searchTerm || filterType !== 'all' || filterStatus !== 'all' || filterDateRange !== 'all') && (
                <div className="flex justify-end">
                  <button
                    onClick={() => {
                      setSearchTerm('');
                      setFilterType('all');
                      setFilterStatus('all');
                      setFilterDateRange('all');
                    }}
                    className="text-xs text-[#16A6A0] hover:underline font-semibold cursor-pointer"
                  >
                    {t('clearFilters')}
                  </button>
                </div>
              )}
            </div>

            {/* Records List */}
            {filteredRecords.length === 0 ? (
              <div className="bg-white rounded-2xl p-10 text-center border border-[#DCE7E3]">
                <Wrench size={40} className="mx-auto text-[#668087] mb-2" />
                <h4 className="font-bold text-sm text-[#102A35]">{t('noRecords')}</h4>
                <p className="text-xs text-[#668087] mt-1">{t('noRecordsHint')}</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredRecords.map((rec) => {
                  const TypeIcon = TYPES.find((tp) => tp.key === rec.type)?.icon || Wrench;
                  return (
                    <div
                      key={rec.id}
                      className="bg-white rounded-2xl p-4 sm:p-5 border border-[#DCE7E3] shadow-xs hover:border-[#16A6A0]/40 transition-all space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#EDF2F0] pb-3">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-xl bg-[#E7EFEC] text-[#16A6A0] flex items-center justify-center shrink-0">
                            <TypeIcon size={20} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-sm text-[#102A35]">{t(rec.type)}</h4>
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  rec.status === 'scheduled'
                                    ? 'bg-[#FFF9EE] text-[#8A5B16]'
                                    : rec.status === 'in_progress'
                                    ? 'bg-[#EBF2FE] text-[#2B6CB0]'
                                    : 'bg-[#E7EFEC] text-[#2B9A70]'
                                }`}
                              >
                                {rec.status ? t(`status${rec.status.charAt(0).toUpperCase() + rec.status.slice(1)}` as any) : t('statusCompleted')}
                              </span>
                              {rec.severity && rec.severity !== 'routine' && (
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    rec.severity === 'critical'
                                      ? 'bg-[#C94E4E] text-white'
                                      : rec.severity === 'major'
                                      ? 'bg-[#FFF1D8] text-[#8A5B16]'
                                      : 'bg-[#EDF2F0] text-[#668087]'
                                  }`}
                                >
                                  {t(`severity${rec.severity.charAt(0).toUpperCase() + rec.severity.slice(1)}` as any)}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-[#668087] mt-0.5 flex items-center gap-2">
                              <span>{dateLabel(rec.date, language)}</span>
                              <span>•</span>
                              <span>{formatLocalizedNumber(rec.mileage, language)} km</span>
                              {rec.workshop && (
                                <>
                                  <span>•</span>
                                  <span className="font-medium text-[#102A35]">{rec.workshop}</span>
                                </>
                              )}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between sm:justify-end gap-3">
                          <div className="text-end">
                            <span className="text-base sm:text-lg font-black text-[#102A35]">
                              {formatMoney(rec.cost)}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                setEditingRecord(rec);
                                setAddRecordModalOpen(true);
                              }}
                              className="p-1.5 text-[#668087] hover:text-[#16A6A0] rounded-md transition-colors cursor-pointer"
                              title={t('editRecord')}
                            >
                              <Edit2 size={15} />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(t('confirmDeleteRecord'))) {
                                  deleteRecord(rec.id);
                                }
                              }}
                              className="p-1.5 text-[#668087] hover:text-[#C94E4E] rounded-md transition-colors cursor-pointer"
                              title={t('deleteRecord')}
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Notes & details */}
                      {rec.notes && (
                        <p className="text-xs text-[#668087] bg-[#F8FAF9] p-2.5 rounded-xl border border-[#EDF2F0]">
                          {rec.notes}
                        </p>
                      )}

                      {/* Spare parts catalogue listing */}
                      {rec.parts && rec.parts.length > 0 && (
                        <div className="pt-1">
                          <span className="text-[11px] font-bold text-[#102A35] block mb-1.5">
                            {t('spareParts')} ({rec.parts.length}):
                          </span>
                          <div className="flex flex-wrap gap-2">
                            {rec.parts.map((part, pIdx) => (
                              <span
                                key={pIdx}
                                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] bg-[#F4F7F5] border border-[#DCE7E3] text-[#102A35]"
                              >
                                <Package size={12} className="text-[#8A5B16]" />
                                <strong>{part.name}</strong>
                                {part.reference && <span className="text-[#668087]">({part.reference})</span>}
                                <span className="text-[#16A6A0] font-bold">x{part.quantity}</span>
                                {part.unitCost > 0 && (
                                  <span className="text-[#668087]">({formatMoney(part.unitCost * part.quantity)})</span>
                                )}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ============================================================== */}
        {/* REMINDERS & SCHEDULE TAB                                       */}
        {/* ============================================================== */}
        {activeTab === 'reminders' && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-[#102A35]">{t('reminders')}</h2>
                <p className="text-xs text-[#668087]">
                  {pendingReminders.length} {language === 'ar' ? 'تنبيهات نشطة' : 'rappels actifs'} • {overdueCount} {t('overdue')}
                </p>
              </div>

              <button
                onClick={() => setReminderModalOpen(true)}
                className="px-3.5 py-2 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer self-start sm:self-auto"
              >
                <Plus size={16} />
                <span>{t('addReminder')}</span>
              </button>
            </div>

            {/* Filter Tabs: Pending vs Completed */}
            <div className="flex items-center gap-2 border-b border-[#DCE7E3] pb-2">
              <button
                onClick={() => setReminderTab('pending')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  reminderTab === 'pending'
                    ? 'bg-[#102A35] text-white shadow-xs'
                    : 'bg-white text-[#668087] hover:bg-[#EDF2F0]'
                }`}
              >
                <span>{language === 'ar' ? 'المواعيد والتنبيهات القادمة' : 'Échéances en cours'}</span>
                <span className="ms-1.5 px-1.5 py-0.2 rounded-full text-[10px] bg-white/20">
                  {pendingReminders.length}
                </span>
              </button>
              <button
                onClick={() => setReminderTab('completed')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  reminderTab === 'completed'
                    ? 'bg-[#102A35] text-white shadow-xs'
                    : 'bg-white text-[#668087] hover:bg-[#EDF2F0]'
                }`}
              >
                <span>{language === 'ar' ? 'المكتملة' : 'Terminés'}</span>
                <span className="ms-1.5 px-1.5 py-0.2 rounded-full text-[10px] bg-white/20">
                  {completedReminders.length}
                </span>
              </button>
            </div>

            {/* Reminders Grid */}
            {((reminderTab === 'pending' ? pendingReminders : completedReminders).length === 0) ? (
              <div className="bg-white rounded-2xl p-10 text-center border border-[#DCE7E3]">
                <Clock size={40} className="mx-auto text-[#668087] mb-2" />
                <h4 className="font-bold text-sm text-[#102A35]">{t('noReminders')}</h4>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {(reminderTab === 'pending' ? pendingReminders : completedReminders).map((rem) => {
                  const days = daysUntil(rem.dueDate);
                  const isOverdue = !rem.completed && ((days !== null && days < 0) || (rem.dueMileage && currentMileage >= rem.dueMileage));
                  const isSoon = !rem.completed && days !== null && days >= 0 && days <= 30;

                  return (
                    <div
                      key={rem.id}
                      className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                        rem.completed
                          ? 'bg-[#F8FAF9] border-[#EDF2F0] opacity-80'
                          : isOverdue
                          ? 'bg-[#FDF2F2] border-[#F2C2C2] shadow-xs'
                          : isSoon
                          ? 'bg-[#FFF9EE] border-[#F5E2B8]'
                          : 'bg-white border-[#DCE7E3]'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                              rem.type === 'oil'
                                ? 'bg-[#E7EFEC] text-[#16A6A0]'
                                : rem.type === 'insurance'
                                ? 'bg-[#EBF2FE] text-[#2B6CB0]'
                                : rem.type === 'inspection'
                                ? 'bg-[#FFF1D8] text-[#8A5B16]'
                                : 'bg-[#F4F7F5] text-[#102A35]'
                            }`}
                          >
                            {t(`type${rem.type.charAt(0).toUpperCase() + rem.type.slice(1)}` as any)}
                          </span>

                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              rem.completed
                                ? 'bg-[#E7EFEC] text-[#2B9A70]'
                                : isOverdue
                                ? 'bg-[#C94E4E] text-white'
                                : isSoon
                                ? 'bg-[#F2B45C] text-[#5C3B00]'
                                : 'bg-[#E7EFEC] text-[#16A6A0]'
                            }`}
                          >
                            {rem.completed ? t('statusCompleted') : isOverdue ? t('overdue') : isSoon ? t('upcoming') : t('valid')}
                          </span>
                        </div>

                        <h4 className="font-bold text-sm text-[#102A35]">{rem.title}</h4>

                        <div className="text-xs text-[#668087] space-y-1 mt-2">
                          {rem.dueDate && (
                            <p className="flex items-center gap-1.5">
                              <Calendar size={13} />
                              <span>{t('dueDate')}: {dateLabel(rem.dueDate, language)}</span>
                              {!rem.completed && days !== null && (
                                <strong className={isOverdue ? 'text-[#C94E4E]' : 'text-[#102A35]'}>
                                  ({days < 0 ? (language === 'ar' ? `متأخر بـ ${Math.abs(days)} يوم` : `${Math.abs(days)} j de retard`) : (language === 'ar' ? `بعد ${days} يوم` : `dans ${days} j`)})
                                </strong>
                              )}
                            </p>
                          )}
                          {rem.dueMileage && (
                            <p className="flex items-center gap-1.5">
                              <Gauge size={13} />
                              <span>{t('dueMileage')}: {formatLocalizedNumber(rem.dueMileage, language)} km</span>
                            </p>
                          )}
                          {rem.notes && <p className="text-[11px] text-[#668087] italic mt-1">{rem.notes}</p>}
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-black/5 flex items-center justify-between">
                        <button
                          onClick={() => toggleReminder(rem.id)}
                          className={`text-xs font-semibold px-3 py-1 rounded-lg border transition-colors cursor-pointer ${
                            rem.completed
                              ? 'bg-white hover:bg-[#EDF2F0] text-[#102A35] border-[#DCE7E3]'
                              : 'bg-[#16A6A0] hover:bg-[#138e89] text-white border-transparent'
                          }`}
                        >
                          {rem.completed ? t('reopen') : t('markDone')}
                        </button>

                        <button
                          onClick={() => deleteReminder(rem.id)}
                          className="p-1.5 text-[#668087] hover:text-[#C94E4E] rounded-md transition-colors cursor-pointer"
                          title="Supprimer"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}


        {/* ============================================================== */}
        {/* 5. EXPENSES TAB (Mes Dépenses / مصاريفي)                      */}
        {/* ============================================================== */}
        {activeTab === 'expenses' && (
          <div className="space-y-6">
            {/* Header & Controls */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2.5">
                  <div className="h-9 w-9 rounded-xl bg-[#16A6A0]/10 text-[#16A6A0] flex items-center justify-center">
                    <Wallet size={20} />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-[#102A35]">{t('expenses')}</h2>
                </div>
                <p className="text-xs text-[#668087] mt-1">{t('expensesSubtitle')}</p>
              </div>

              {/* Filters & Add Expense CTA */}
              <div className="flex flex-wrap items-center gap-2.5">
                {/* Vehicle filter */}
                <select
                  value={expenseVehicleFilter}
                  onChange={(e) => setExpenseVehicleFilter(e.target.value)}
                  className="bg-white border border-[#DCE7E3] rounded-xl px-3 py-2 text-xs font-semibold text-[#102A35] focus:outline-none focus:ring-2 focus:ring-[#16A6A0]/20 shadow-xs"
                >
                  <option value="all">{t('allCars')}</option>
                  {vehicles.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.brand} {v.model} {v.plate ? `(${v.plate})` : ''}
                    </option>
                  ))}
                </select>

                {/* Year filter */}
                <select
                  value={expenseYearFilter}
                  onChange={(e) => setExpenseYearFilter(Number(e.target.value))}
                  className="bg-white border border-[#DCE7E3] rounded-xl px-3 py-2 text-xs font-semibold text-[#102A35] focus:outline-none focus:ring-2 focus:ring-[#16A6A0]/20 shadow-xs"
                >
                  {[currentCalendarYear, currentCalendarYear - 1, currentCalendarYear - 2].map((yr) => (
                    <option key={yr} value={yr}>
                      {yr}
                    </option>
                  ))}
                </select>

                {/* Add Expense Button */}
                <button
                  onClick={() => {
                    setEditingRecord(null);
                    setAddRecordModalOpen(true);
                  }}
                  className="px-4 py-2 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
                >
                  <Plus size={16} />
                  <span>{t('addExpense')}</span>
                </button>
              </div>
            </div>

            {/* 4 Summary KPI Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#DCE7E3] shadow-xs">
                <span className="text-[11px] sm:text-xs font-semibold text-[#668087] block mb-1">
                  {t('expensesTotal')}
                </span>
                <span className="text-xl sm:text-2xl font-black text-[#102A35] block">
                  {formatMoney(totalExpenseAllTime)}
                </span>
                <span className="text-[10px] text-[#668087] mt-1 block">
                  {filteredExpenseRecords.length} {language === 'ar' ? 'عملية مسجلة' : 'dépenses au total'}
                </span>
              </div>

              <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#16A6A0]/40 shadow-xs relative overflow-hidden">
                <div className="absolute top-0 end-0 h-1.5 w-full bg-[#16A6A0]" />
                <span className="text-[11px] sm:text-xs font-semibold text-[#16A6A0] block mb-1">
                  {t('expensesYear')} ({expenseYearFilter})
                </span>
                <span className="text-xl sm:text-2xl font-black text-[#102A35] block">
                  {formatMoney(totalExpenseYear)}
                </span>
                <span className="text-[10px] text-[#668087] mt-1 block">
                  {yearExpenseRecords.length} {language === 'ar' ? 'عملية هذا العام' : 'dépenses en'} {expenseYearFilter}
                </span>
              </div>

              <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#DCE7E3] shadow-xs">
                <span className="text-[11px] sm:text-xs font-semibold text-[#668087] block mb-1">
                  {t('expensesMonth')}
                </span>
                <span className="text-xl sm:text-2xl font-black text-[#102A35] block">
                  {formatMoney(totalExpenseMonth)}
                </span>
                <span className="text-[10px] text-[#668087] mt-1 block">
                  {monthExpenseRecords.length} {language === 'ar' ? 'عملية خلال الشهر' : 'dépenses ce mois'}
                </span>
              </div>

              <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#DCE7E3] shadow-xs">
                <span className="text-[11px] sm:text-xs font-semibold text-[#668087] block mb-1">
                  {t('monthlyAverage')}
                </span>
                <span className="text-xl sm:text-2xl font-black text-[#102A35] block">
                  {formatMoney(monthlyAverageExpense)}
                </span>
                <span className="text-[10px] text-[#668087] mt-1 block">
                  {language === 'ar' ? 'المعدل الشهري للعام' : 'Budget moyen / mois'}
                </span>
              </div>
            </div>

            {/* Monthly Chart Visualizer (12 months) */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#DCE7E3] shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
                <div className="flex items-center gap-2">
                  <TrendingUp size={18} className="text-[#16A6A0]" />
                  <h3 className="font-extrabold text-sm sm:text-base text-[#102A35]">
                    {t('monthlyExpensesChart')} ({expenseYearFilter})
                  </h3>
                </div>
                <span className="text-xs text-[#668087]">
                  {language === 'ar' ? 'توزيع المصاريف على مدار 12 شهراً' : '12 mois d\'historique'}
                </span>
              </div>

              {/* Monthly Bar Columns */}
              <div className="pt-4 pb-2">
                <div className="grid grid-cols-12 gap-1 sm:gap-2 items-end h-40 border-b border-[#EDF2F0] pb-2">
                  {monthlyDistribution.map((m) => {
                    const heightPercent = m.amount > 0 ? Math.max(12, Math.round((m.amount / m.maxAmount) * 100)) : 4;
                    const isCurrentMonth = expenseYearFilter === currentCalendarYear && m.month === currentMonthIndex;
                    return (
                      <div key={m.month} className="flex flex-col items-center h-full justify-end group relative">
                        {/* Hover Tooltip */}
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 bg-[#102A35] text-white text-[10px] py-1 px-1.5 rounded pointer-events-none whitespace-nowrap z-20 shadow-md">
                          {formatMoney(m.amount)}
                        </div>

                        {/* Bar */}
                        <div
                          style={{ height: `${heightPercent}%` }}
                          className={`w-full max-w-[28px] rounded-t-md transition-all ${
                            m.amount > 0
                              ? isCurrentMonth
                                ? 'bg-gradient-to-t from-[#08B7AD] to-[#42D9D0] shadow-xs'
                                : 'bg-[#16A6A0] hover:bg-[#138e89]'
                              : 'bg-[#EDF2F0]'
                          }`}
                        />
                        <span className="text-[9px] sm:text-[11px] font-bold text-[#668087] mt-2 truncate w-full text-center">
                          {m.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Category Breakdown & Resale Tip Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              {/* Category Breakdown (2 Cols) */}
              <div className="lg:col-span-2 bg-white rounded-2xl p-5 sm:p-6 border border-[#DCE7E3] shadow-xs space-y-4">
                <div className="flex items-center gap-2 border-b border-[#EDF2F0] pb-3">
                  <PieChart size={18} className="text-[#16A6A0]" />
                  <h3 className="font-extrabold text-sm sm:text-base text-[#102A35]">
                    {t('expensesByCategory')} ({expenseYearFilter})
                  </h3>
                </div>

                <div className="space-y-3">
                  {expensesByType.map((cat) => {
                    const CatIcon = cat.icon;
                    return (
                      <div key={cat.key} className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <div className="h-6 w-6 rounded-lg bg-[#F4F7F5] flex items-center justify-center text-[#16A6A0]">
                              <CatIcon size={14} />
                            </div>
                            <span className="font-bold text-[#102A35]">{t(cat.key)}</span>
                            <span className="text-[10px] text-[#668087]">({cat.count} {language === 'ar' ? 'تدخل' : 'interventions'})</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-black text-[#102A35]">{formatMoney(cat.cost)}</span>
                            <span className="text-[10px] text-[#668087] w-8 text-end font-semibold">{cat.pct}%</span>
                          </div>
                        </div>
                        {/* Progress Bar */}
                        <div className="h-2 w-full bg-[#EDF2F0] rounded-full overflow-hidden">
                          <div
                            style={{ width: `${cat.pct}%` }}
                            className="h-full bg-[#16A6A0] rounded-full transition-all"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Private Owner Resale Preservation Card (1 Col) */}
              <div className="bg-gradient-to-br from-[#062B36] to-[#0B3945] text-white rounded-2xl p-5 sm:p-6 shadow-md border border-white/10 flex flex-col justify-between">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#16A6A0]/20 text-[#42D9D0] text-[11px] font-bold border border-[#16A6A0]/30 mb-3">
                    <Shield size={13} />
                    <span>{language === 'ar' ? 'نصيحة لإعادة البيع' : 'Conseil Revente'}</span>
                  </div>
                  <h4 className="font-extrabold text-base text-white mb-2 leading-snug">
                    {t('resaleTipTitle')}
                  </h4>
                  <p className="text-xs text-white/80 leading-relaxed">
                    {t('resaleTipBody')}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between">
                  <span className="text-[11px] text-white/70">
                    {language === 'ar' ? 'جاهز للتصدير كتقرير معتمد' : 'Exportable en rapport certifié'}
                  </span>
                  <button
                    onClick={() => setActiveTab('reports')}
                    className="px-3 py-1.5 rounded-lg bg-[#16A6A0] hover:bg-[#138e89] text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                  >
                    <span>{t('reports')}</span>
                    <ArrowRight size={13} className="rtl:rotate-180" />
                  </button>
                </div>
              </div>
            </div>

            {/* Recent Expenses Records List */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#DCE7E3] shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
                <h3 className="font-extrabold text-sm sm:text-base text-[#102A35]">
                  {language === 'ar' ? 'سجل المصاريف المفصل' : 'Détail des dépenses enregistrées'}
                </h3>
                <span className="text-xs text-[#668087]">
                  {yearExpenseRecords.length} {language === 'ar' ? 'عنصر' : 'opérations'}
                </span>
              </div>

              {yearExpenseRecords.length === 0 ? (
                <div className="text-center py-8 space-y-3">
                  <div className="h-12 w-12 rounded-full bg-[#F4F7F5] text-[#668087] flex items-center justify-center mx-auto">
                    <Wallet size={22} />
                  </div>
                  <p className="text-xs text-[#668087] font-medium">{t('noExpensesRecorded')}</p>
                  <button
                    onClick={() => {
                      setEditingRecord(null);
                      setAddRecordModalOpen(true);
                    }}
                    className="px-4 py-2 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Plus size={14} />
                    <span>{t('addExpense')}</span>
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-[#EDF2F0]">
                  {yearExpenseRecords.map((rec) => {
                    const tp = TYPES.find((t) => t.key === rec.type) || TYPES[5];
                    const TypeIcon = tp.icon;
                    const veh = vehicles.find((v) => v.id === rec.vehicleId);
                    return (
                      <div key={rec.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-start gap-3">
                          <div className="h-9 w-9 rounded-xl bg-[#F4F7F5] text-[#16A6A0] flex items-center justify-center shrink-0 mt-0.5">
                            <TypeIcon size={18} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-[#102A35]">{t(rec.type)}</span>
                              {veh && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] bg-[#EDF2F0] text-[#668087] font-semibold">
                                  {veh.brand} {veh.model}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-[#668087] mt-0.5">
                              {dateLabel(rec.date, language)} • {formatLocalizedNumber(rec.mileage, language)} km
                              {rec.workshop ? ` • ${rec.workshop}` : ''}
                            </p>
                            {rec.notes && <p className="text-[11px] text-[#102A35] mt-1 bg-[#F8FAF9] px-2 py-1 rounded-md">{rec.notes}</p>}
                          </div>
                        </div>

                        <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                          <span className="text-sm sm:text-base font-black text-[#102A35]">
                            {formatMoney(rec.cost)}
                          </span>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                setEditingRecord(rec);
                                setAddRecordModalOpen(true);
                              }}
                              className="p-1.5 text-[#668087] hover:text-[#16A6A0] rounded-md transition-colors cursor-pointer"
                              title={t('editRecord')}
                            >
                              <Edit2 size={14} />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(t('confirmDeleteRecord'))) {
                                  deleteRecord(rec.id);
                                }
                              }}
                              className="p-1.5 text-[#668087] hover:text-[#C94E4E] rounded-md transition-colors cursor-pointer"
                              title={t('deleteRecord')}
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* REPORTS & PDF TAB                                              */}
        {/* ============================================================== */}
        {activeTab === 'reports' && (
          <div className="space-y-6 max-w-3xl mx-auto">
            <div className="bg-white rounded-2xl p-6 border border-[#DCE7E3] shadow-xs space-y-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-xl bg-[#E7EFEC] text-[#16A6A0] flex items-center justify-center shrink-0">
                  <FileText size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-[#102A35]">{t('reports')}</h2>
                  <p className="text-xs text-[#668087]">{t('exportPdfSummary')}</p>
                </div>
              </div>

              {activeVehicle ? (
                <div className="bg-[#F8FAF9] p-4 rounded-xl border border-[#EDF2F0] space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#668087]">{t('yourCar')}:</span>
                    <strong className="text-[#102A35]">{activeVehicle.brand} {activeVehicle.model} ({activeVehicle.plate || 'TN-REG'})</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#668087]">{t('recordCount')}:</span>
                    <strong className="text-[#102A35]">{records.length} {t('service')}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#668087]">{t('totalSpent')}:</span>
                    <strong className="text-[#102A35]">{formatMoney(totalCost)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#668087]">{t('spareParts')}:</span>
                    <strong className="text-[#102A35]">{totalPartsCount} {language === 'ar' ? 'قطعة مسجلة' : 'pièces'}</strong>
                  </div>
                </div>
              ) : null}

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={handleGeneratePDF}
                  className="flex-1 py-3 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                >
                  <Download size={16} />
                  <span>{t('downloadPdf')}</span>
                </button>

                <button
                  onClick={exportDataAsCSV}
                  className="flex-1 py-3 bg-[#EDF2F0] hover:bg-[#DCE7E3] text-[#102A35] rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-[#DCE7E3] cursor-pointer"
                >
                  <FileSpreadsheet size={16} className="text-[#2B9A70]" />
                  <span>{t('exportCSV')}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* SETTINGS TAB (Paramètres / الإعدادات)                            */}
        {/* ============================================================== */}
        {activeTab === 'settings' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            <div className="text-center sm:text-start space-y-1">
              <h2 className="text-2xl font-black text-[#102A35]">{t('settings')}</h2>
              <p className="text-xs text-[#607D89]">
                {language === 'ar'
                  ? 'إدارة حسابك، تفضيلات التطبيق، باقات الاشتراك، والنسخ الاحتياطي للبيانات.'
                  : 'Gérez votre compte, vos préférences, formules d’abonnement et sauvegardes.'}
              </p>
            </div>

            {/* Plan Action Feedback Banner */}
            {planFeedback && (
              <div
                className={`p-4 rounded-2xl text-xs font-semibold flex items-center justify-between border shadow-xs transition-all ${
                  planFeedback.type === 'error'
                    ? 'bg-[#FEF2F2] text-[#991B1B] border-[#FCA5A5]'
                    : 'bg-[#F0FDF4] text-[#166534] border-[#86EFAC]'
                }`}
              >
                <span>{planFeedback.message}</span>
                <button
                  onClick={() => setPlanFeedback(null)}
                  className="px-2 py-1 rounded-lg text-xs font-bold hover:bg-black/5 cursor-pointer ms-3 shrink-0"
                >
                  ✕
                </button>
              </div>
            )}

            {/* 1. Account & Profile Card */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#DCE7E3] shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
                <div className="flex items-center gap-2.5">
                  <User size={18} className="text-[#16A6A0]" />
                  <h3 className="font-extrabold text-base text-[#102A35]">{t('account')}</h3>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#16A6A0]/10 text-[#16A6A0] uppercase border border-[#16A6A0]/20">
                  {user?.tier ? `Siyantek ${user.tier.toUpperCase()}` : 'Free'}
                </span>
              </div>

              {isLoggedIn ? (
                <div className="space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#F8FAF9] p-3.5 rounded-xl border border-[#EDF2F0]">
                    <div>
                      <p className="font-bold text-sm text-[#102A35]">{user?.name || 'Utilisateur Siyantek'}</p>
                      <p className="text-xs text-[#668087]">{user?.email}</p>
                      <p className="text-[11px] text-[#16A6A0] font-semibold mt-1">
                        {vehicles.length} / {tierLimits.maxVehicles} {language === 'ar' ? 'سيارات مسجلة' : 'véhicules enregistrés'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={logout}
                        className="min-h-[40px] px-4 py-2 bg-white hover:bg-[#EDF2F0] text-[#102A35] border border-[#DCE7E3] rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <LogOut size={14} />
                        <span>{t('logout')}</span>
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#F8FAF9] p-3.5 rounded-xl border border-[#EDF2F0]">
                  <div>
                    <p className="font-bold text-sm text-[#102A35]">{language === 'ar' ? 'جلسة تجريبية / وضع الزائر' : 'Mode invité actif'}</p>
                    <p className="text-xs text-[#668087]">
                      {language === 'ar' ? 'سجل دخولك لحفظ بياناتك في السحابة ومزامنتها بين أجهزتك.' : 'Connectez-vous pour synchroniser vos véhicules et historiques en toute sécurité.'}
                    </p>
                  </div>
                  <button
                    onClick={() => setAuthModalOpen(true)}
                    className="min-h-[40px] px-5 py-2 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <User size={14} />
                    <span>{t('login')}</span>
                  </button>
                </div>
              )}
            </div>

            {/* 2. Preferences Card (Language & Currency) */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#DCE7E3] shadow-xs space-y-4">
              <div className="flex items-center gap-2.5 border-b border-[#EDF2F0] pb-3">
                <Settings size={18} className="text-[#16A6A0]" />
                <h3 className="font-extrabold text-base text-[#102A35]">
                  {language === 'ar' ? 'تفضيلات التطبيق' : 'Préférences d’affichage'}
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Language Picker */}
                <div className="p-3.5 rounded-xl bg-[#F8FAF9] border border-[#EDF2F0] space-y-2">
                  <label className="block text-xs font-bold text-[#102A35]">
                    {language === 'ar' ? 'لغة الواجهة' : 'Langue'}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setLanguage('fr')}
                      className={`min-h-[42px] py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        language === 'fr'
                          ? 'bg-[#16A6A0] text-white shadow-xs'
                          : 'bg-white text-[#102A35] border border-[#DCE7E3] hover:bg-[#EDF2F0]'
                      }`}
                    >
                      Français (FR)
                    </button>
                    <button
                      onClick={() => setLanguage('ar')}
                      className={`min-h-[42px] py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        language === 'ar'
                          ? 'bg-[#16A6A0] text-white shadow-xs'
                          : 'bg-white text-[#102A35] border border-[#DCE7E3] hover:bg-[#EDF2F0]'
                      }`}
                    >
                      العربية (AR)
                    </button>
                  </div>
                </div>

                {/* Currency Picker */}
                <div className="p-3.5 rounded-xl bg-[#F8FAF9] border border-[#EDF2F0] space-y-2">
                  <label className="block text-xs font-bold text-[#102A35]">
                    {language === 'ar' ? 'عملة الحساب' : 'Devise'}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['TND', 'EUR', 'USD'] as Currency[]).map((c) => (
                      <button
                        key={c}
                        onClick={() => setCurrency(c)}
                        className={`min-h-[42px] py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          currency === c
                            ? 'bg-[#16A6A0] text-white shadow-xs'
                            : 'bg-white text-[#102A35] border border-[#DCE7E3] hover:bg-[#EDF2F0]'
                        }`}
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* 3. Free plan — no subscriptions or feature locks */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#DCE7E3] shadow-xs space-y-3">
              <div className="flex items-center gap-2.5 border-b border-[#EDF2F0] pb-3">
                <CheckCircle2 size={18} className="text-[#16A6A0]" />
                <h3 className="font-extrabold text-base text-[#102A35]">{language === 'ar' ? 'صيانتك مجاني بالكامل' : 'Siyantek est 100 % gratuit'}</h3>
              </div>
              <p className="text-sm text-[#668087]">
                {language === 'ar'
                  ? 'جميع الميزات متاحة دون اشتراك أو دفع: سيارات غير محدودة، سجل الصيانة، التذكيرات، تقارير PDF والتصدير.'
                  : 'Toutes les fonctionnalités sont accessibles sans abonnement ni paiement : véhicules illimités, carnet d’entretien, rappels, rapports PDF et exports.'}
              </p>
              <div className="inline-flex items-center gap-2 rounded-xl bg-[#E9F8F5] px-3 py-2 text-xs font-bold text-[#16796F]">
                <Check size={14} />
                {language === 'ar' ? 'لا توجد اشتراكات أو ميزات مدفوعة' : 'Aucun abonnement ni fonctionnalité payante'}
              </div>
            </div>

            {/* 4. Data Management & Backup */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#DCE7E3] shadow-xs space-y-4">
              <div className="flex items-center gap-2.5 border-b border-[#EDF2F0] pb-3">
                <FileSpreadsheet size={18} className="text-[#16A6A0]" />
                <h3 className="font-extrabold text-base text-[#102A35]">
                  {language === 'ar' ? 'النسخ الاحتياطي وإدارة البيانات' : 'Sauvegarde et gestion des données'}
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  onClick={exportDataAsCSV}
                  className="min-h-[44px] py-2.5 px-3 bg-[#F8FAF9] hover:bg-[#EDF2F0] text-[#102A35] border border-[#DCE7E3] rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <FileSpreadsheet size={16} className="text-[#2B9A70]" />
                  <span>{t('exportCSV')}</span>
                </button>

                <button
                  onClick={exportData}
                  className="min-h-[44px] py-2.5 px-3 bg-[#F8FAF9] hover:bg-[#EDF2F0] text-[#102A35] border border-[#DCE7E3] rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Download size={16} className="text-[#16A6A0]" />
                  <span>{t('exportData')}</span>
                </button>

                <button
                  onClick={() => {
                    if (confirm(t('confirmResetData'))) {
                      resetAllData();
                    }
                  }}
                  className="min-h-[44px] py-2.5 px-3 bg-[#FEF2F2] hover:bg-[#FEE2E2] text-[#C94E4E] border border-[#FCA5A5]/60 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <RefreshCw size={16} />
                  <span>{t('resetData')}</span>
                </button>
              </div>

              <div className="pt-2 flex flex-wrap items-center justify-center gap-3 sm:gap-6 border-t border-[#EDF2F0]">
                <button
                  onClick={() => setSupportModalOpen(true)}
                  className="text-xs font-bold text-[#16A6A0] hover:underline flex items-center gap-1.5 cursor-pointer py-1"
                >
                  <HelpCircle size={14} />
                  <span>{t('contactSupport')}</span>
                </button>
                <button
                  onClick={() => {
                    setLegalTab('terms');
                    setPrivacyModalOpen(true);
                  }}
                  className="text-xs text-[#668087] hover:text-[#102A35] hover:underline cursor-pointer py-1"
                >
                  {t('termsTitle')}
                </button>
                <button
                  onClick={() => {
                    setLegalTab('privacy');
                    setPrivacyModalOpen(true);
                  }}
                  className="text-xs text-[#668087] hover:text-[#102A35] hover:underline cursor-pointer py-1"
                >
                  {t('privacyTitle')}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ============================================================== */}
      {/* 4. MOBILE BOTTOM NAVIGATION (6 Simplified Sections)            */}
      {/* ============================================================== */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#DCE7E3] px-1 py-1 grid grid-cols-6 items-center shadow-lg safe-bottom">
        {[
          { id: 'overview', label: t('overview'), icon: Gauge },
          { id: 'vehicles', label: t('vehicles'), icon: Car, count: vehicles.length },
          { id: 'history', label: t('history'), icon: Wrench },
          { id: 'reminders', label: t('reminders'), icon: Clock, count: overdueCount, alert: overdueCount > 0 },
          { id: 'expenses', label: t('expenses'), icon: Wallet },
          { id: 'reports', label: t('reports'), icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`min-h-[46px] flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all relative cursor-pointer ${
                isActive ? 'text-[#16A6A0] font-bold' : 'text-[#668087] hover:text-[#102A35]'
              }`}
            >
              <Icon size={20} strokeWidth={isActive ? 2.5 : 2} className="shrink-0" />
              <span className="text-[9.5px] leading-tight truncate max-w-full mt-0.5">
                {tab.label}
              </span>
              {tab.count !== undefined && tab.count > 0 && tab.alert && (
                <span className="absolute top-1 right-1 sm:right-2 h-2 w-2 rounded-full bg-[#C94E4E] ring-2 ring-white animate-pulse" />
              )}
            </button>
          );
        })}
      </nav>

      {/* ============================================================== */}
      {/* 5. ADD / EDIT RECORD MODAL (With Spare Parts & Severity)       */}
      {/* ============================================================== */}
      {addRecordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl my-8 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
              <h3 className="font-extrabold text-base text-[#102A35]">
                {editingRecord ? t('editRecord') : t('addServiceTitle')}
              </h3>
              <button onClick={() => setAddRecordModalOpen(false)} className="text-[#668087] hover:text-[#102A35] cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <AddRecordForm
              record={editingRecord}
              onClose={() => setAddRecordModalOpen(false)}
            />
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 6. ADD / EDIT VEHICLE MODAL                                    */}
      {/* ============================================================== */}
      {vehicleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
              <h3 className="font-extrabold text-base text-[#102A35]">
                {vehicleToEdit ? t('editVehicle') : t('addVehicle')}
              </h3>
              <button onClick={() => setVehicleModalOpen(false)} className="text-[#668087] hover:text-[#102A35] cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <VehicleForm
              vehicle={vehicleToEdit}
              onClose={() => setVehicleModalOpen(false)}
            />
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 7. ADD REMINDER MODAL                                          */}
      {/* ============================================================== */}
      {reminderModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
              <h3 className="font-extrabold text-base text-[#102A35]">{t('addReminder')}</h3>
              <button onClick={() => setReminderModalOpen(false)} className="text-[#668087] hover:text-[#102A35] cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <ReminderForm onClose={() => setReminderModalOpen(false)} />
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 8. AUTHENTICATION & ACCOUNT MODAL                              */}
      {/* ============================================================== */}
      {authModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
              <h3 className="font-extrabold text-base text-[#102A35]">
                {isLoggedIn ? t('account') : t('login')}
              </h3>
              <button onClick={() => setAuthModalOpen(false)} className="text-[#668087] hover:text-[#102A35] cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <AccountModalContent onClose={() => setAuthModalOpen(false)} />
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 9. LEGAL & PRIVACY MODAL                                       */}
      {/* ============================================================== */}
      {privacyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
              <div className="flex items-center gap-2">
                <Shield size={18} className="text-[#16A6A0]" />
                <h3 className="font-extrabold text-base text-[#102A35]">
                  {legalTab === 'privacy' ? t('privacyTitle') : t('termsTitle')}
                </h3>
              </div>
              <button
                onClick={() => setPrivacyModalOpen(false)}
                className="text-[#668087] hover:text-[#102A35] cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Tab switch between Privacy & Terms */}
            <div className="flex rounded-xl bg-[#F8FAF9] p-1 border border-[#EDF2F0] gap-1">
              <button
                onClick={() => setLegalTab('privacy')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  legalTab === 'privacy' ? 'bg-white text-[#16A6A0] shadow-xs' : 'text-[#668087] hover:text-[#102A35]'
                }`}
              >
                {t('privacyTitle')}
              </button>
              <button
                onClick={() => setLegalTab('terms')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  legalTab === 'terms' ? 'bg-white text-[#16A6A0] shadow-xs' : 'text-[#668087] hover:text-[#102A35]'
                }`}
              >
                {t('termsTitle')}
              </button>
            </div>

            <div className="flex-1 overflow-y-auto text-xs text-[#526E77] space-y-3 pr-1 rtl:pr-0 rtl:pl-1">
              {legalTab === 'privacy' ? (
                <>
                  <div className="p-3 bg-[#E7EFEC] rounded-xl text-[#102A35] font-medium leading-relaxed">
                    {t('privacyBody')}
                  </div>
                  <div>
                    <h4 className="font-bold text-[#102A35] mb-1">
                      {language === 'ar' ? '1. البيانات التي نجمعها' : '1. Données collectées'}
                    </h4>
                    <p>
                      {language === 'ar'
                        ? 'نجمع فقط المعلومات الضرورية لإدارة سجلات مركبتك: اسم الحساب، البريد، تفاصيل السيارة، قراءات العداد وتكاليف وتواريخ الصيانة.'
                        : 'Nous collectons uniquement les informations nécessaires au suivi de votre véhicule : nom, email, caractéristiques du véhicule, kilométrage et historique des entretiens.'}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#102A35] mb-1">
                      {language === 'ar' ? '2. التشفير والأمان' : '2. Sécurité & Chiffrement'}
                    </h4>
                    <p>
                      {language === 'ar'
                        ? 'تُحفظ كلمات المرور بتجزئة مشفرة عبر Bcrypt، وتُدار الجلسات عبر رموز SHA-256 مشفرة وكوكيز HttpOnly محمية تمنع الوصول غير المصرح به.'
                        : 'Vos mots de passe sont hachés avec Bcrypt et les sessions sécurisées via des jetons SHA-256 avec cookies HttpOnly protégés.'}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#102A35] mb-1">
                      {language === 'ar' ? '3. حق التصدير والحذف الكامل' : '3. Droit d\'export et de suppression'}
                    </h4>
                    <p>
                      {language === 'ar'
                        ? 'يمكنك في أي وقت تصدير كافة بياناتك بصيغة CSV أو JSON أو PDF، أو حذف حسابك وسجلاتك نهائياً دون رجعة من خوادمنا.'
                        : 'Vous pouvez exporter l’intégralité de vos données en CSV, JSON ou PDF, ou supprimer définitivement votre compte et vos données à tout moment.'}
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <div className="p-3 bg-[#F8FAF9] rounded-xl text-[#102A35] font-medium leading-relaxed border border-[#EDF2F0]">
                    {language === 'ar'
                      ? 'الشروط العامة لاستخدام منصة صيانتك لإدارة ومتابعة صيانة السيارات في تونس والعالم العربي.'
                      : 'Conditions générales régissant l\'accès et l\'utilisation du service SaaS Siyantek.'}
                  </div>
                  <div>
                    <h4 className="font-bold text-[#102A35] mb-1">
                      {language === 'ar' ? '1. طبيعة الخدمة' : '1. Objet du service'}
                    </h4>
                    <p>
                      {language === 'ar'
                        ? 'صيانتك هي أداة مساعدة لتوثيق ومتابعة صيانة المركبات. يتحمل صاحب السيارة المسؤولية الكاملة عن صحة ودقة البيانات المدخلة ومتابعة التوصيات الفنية للشركة المصنعة لمركبته.'
                        : 'Siyantek est un outil numérique de suivi et d\'aide à la gestion de la maintenance automobile. L\'utilisateur reste responsable de l\'exactitude des données saisies et de l\'entretien réel de son véhicule.'}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#102A35] mb-1">
                      {language === 'ar' ? '2. مجانية التطبيق' : '2. Gratuité de l’application'}
                    </h4>
                    <p>
                      {language === 'ar'
                        ? 'جميع ميزات التطبيق مجانية بالكامل، دون اشتراكات أو مدفوعات أو حدود على عدد السيارات.'
                        : 'Toutes les fonctionnalités sont gratuites, sans abonnement, paiement ni limite sur le nombre de véhicules.'}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#102A35] mb-1">
                      {language === 'ar' ? '3. القانون الواجب التطبيق' : '3. Droit applicable'}
                    </h4>
                    <p>
                      {language === 'ar'
                        ? 'تخضع هذه الشروط للقوانين والتشريعات التونسية المعمول بها في مجال حماية البيانات الرقمية والتجارة الإلكترونية.'
                        : 'Les présentes conditions sont soumises à la législation tunisienne en vigueur relative à la protection des données et au commerce électronique.'}
                    </p>
                  </div>
                </>
              )}
            </div>

            <div className="pt-3 border-t border-[#EDF2F0] flex justify-end">
              <button
                onClick={() => setPrivacyModalOpen(false)}
                className="px-5 py-2 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                {t('close')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 10. SUPPORT & WHATSAPP CONTACT MODAL                           */}
      {/* ============================================================== */}
      {supportModalOpen && (
        <SupportModalContent onClose={() => setSupportModalOpen(false)} />
      )}

      {/* ============================================================== */}
      {/* 11. MANUAL PAYMENT MODAL (Virement / Mandat / D17)              */}
      {/* ============================================================== */}
      {manualPaymentModalOpen && (
        <ManualPaymentModal
          initialPlan={selectedTierForOrder}
          onClose={() => setManualPaymentModalOpen(false)}
        />
      )}

      {/* ============================================================== */}
      {/* 12. ADMIN BACK-OFFICE MODAL                                    */}
      {/* ============================================================== */}
      {adminModalOpen && isAdmin && (
        <AdminBackOfficeModal onClose={() => setAdminModalOpen(false)} />
      )}
    </div>
  );
}

// -------------------------------------------------------------
// Form: Add/Edit Maintenance Record with Spare Parts
// -------------------------------------------------------------
function AddRecordForm({
  record,
  onClose,
}: {
  record: MaintenanceRecord | null;
  onClose: () => void;
  language?: Language;
}) {
  const { t, currency, language, activeVehicle, addRecord, updateRecord } = useSiyantek();
  const [type, setType] = useState<MaintenanceType>(record?.type || 'oil');
  const [status, setStatus] = useState<MaintenanceStatus>(record?.status || 'completed');
  const [severity, setSeverity] = useState<MaintenanceSeverity>(record?.severity || 'routine');
  const [date, setDate] = useState(record?.date || new Date().toISOString().slice(0, 10));
  const [mileage, setMileage] = useState(record?.mileage?.toString() || `${activeVehicle?.mileage || ''}`);
  const [cost, setCost] = useState(record?.cost?.toString() || '');
  const [workshop, setWorkshop] = useState(record?.workshop || '');
  const [notes, setNotes] = useState(record?.notes || '');
  const [nextMileage, setNextMileage] = useState(record?.nextMileage?.toString() || '');
  const [parts, setParts] = useState<SparePart[]>(record?.parts || []);
  const [error, setError] = useState('');

  // Spare part sub-form state
  const [partNameDraft, setPartNameDraft] = useState('');
  const [partRefDraft, setPartRefDraft] = useState('');
  const [partQtyDraft, setPartQtyDraft] = useState('1');
  const [partCostDraft, setPartCostDraft] = useState('');

  const handleAddPart = () => {
    if (!partNameDraft.trim()) return;
    const newPart: SparePart = {
      name: partNameDraft.trim(),
      reference: partRefDraft.trim() || undefined,
      quantity: Math.max(1, Number(partQtyDraft) || 1),
      unitCost: Math.max(0, Number(partCostDraft) || 0),
    };
    setParts([...parts, newPart]);

    if (!cost) {
      setCost(String(newPart.quantity * newPart.unitCost));
    } else {
      setCost(String(Number(cost) + newPart.quantity * newPart.unitCost));
    }

    setPartNameDraft('');
    setPartRefDraft('');
    setPartQtyDraft('1');
    setPartCostDraft('');
  };

  const handleRemovePart = (idx: number) => {
    setParts(parts.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numMileage = Number(mileage);
    if (isNaN(numMileage) || numMileage <= 0) {
      setError(t('requiredMileage'));
      return;
    }

    const payload = {
      vehicleId: record?.vehicleId || activeVehicle?.id || 'veh_default_1',
      type,
      status,
      severity,
      date,
      mileage: numMileage,
      cost: Number(cost) || 0,
      workshop,
      notes,
      nextMileage: nextMileage ? Number(nextMileage) : undefined,
      parts,
    };

    if (record && record.id) {
      await updateRecord({ ...record, ...payload });
    } else {
      await addRecord(payload);
    }
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 text-xs">
      {/* Category Picker */}
      <div>
        <label className="block font-bold text-[#102A35] mb-1.5">{t('serviceType')}</label>
        <div className="grid grid-cols-3 gap-2">
          {TYPES.map((tp) => (
            <button
              type="button"
              key={tp.key}
              onClick={() => setType(tp.key)}
              className={`p-2.5 rounded-lg border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                type === tp.key
                  ? 'bg-[#16A6A0]/10 border-[#16A6A0] text-[#16A6A0] font-bold'
                  : 'border-[#DCE7E3] text-[#668087] hover:bg-[#F4F7F5]'
              }`}
            >
              <tp.icon size={18} />
              <span>{t(tp.key)}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Status & Severity */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{language === 'ar' ? 'حالة الصيانة' : 'Statut'}</label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as any)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 font-medium"
          >
            <option value="completed">{t('statusCompleted')}</option>
            <option value="in_progress">{t('statusInProgress')}</option>
            <option value="scheduled">{t('statusScheduled')}</option>
          </select>
        </div>
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{language === 'ar' ? 'طبيعة التدخل' : 'Gravité'}</label>
          <select
            value={severity}
            onChange={(e) => setSeverity(e.target.value as any)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 font-medium"
          >
            <option value="routine">{t('severityRoutine')}</option>
            <option value="minor">{t('severityMinor')}</option>
            <option value="major">{t('severityMajor')}</option>
            <option value="critical">{t('severityCritical')}</option>
          </select>
        </div>
      </div>

      {/* Date & Mileage */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('date')}</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
            required
          />
        </div>
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('mileage')} (km)</label>
          <input
            type="number"
            value={mileage}
            onChange={(e) => setMileage(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 font-bold"
            required
          />
        </div>
      </div>

      {/* Cost & Workshop */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('cost')} ({currency})</label>
          <input
            type="number"
            step="0.1"
            placeholder="0"
            value={cost}
            onChange={(e) => setCost(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 font-bold"
          />
        </div>
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('workshop')}</label>
          <input
            type="text"
            placeholder="Ex: Station Tunis, Garage Ariana..."
            value={workshop}
            onChange={(e) => setWorkshop(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
          />
        </div>
      </div>

      {/* Next Mileage Target */}
      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('nextMileage')}</label>
        <input
          type="number"
          placeholder={mileage ? `${Number(mileage) + 10000}` : '100000'}
          value={nextMileage}
          onChange={(e) => setNextMileage(e.target.value)}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
        />
      </div>

      {/* Spare Parts Builder */}
      <div className="bg-[#F8FAF9] p-3 rounded-xl border border-[#EDF2F0] space-y-2.5">
        <label className="block font-bold text-[#102A35] flex items-center justify-between">
          <span>{t('spareParts')}</span>
          <span className="text-[10px] text-[#668087] font-normal">{language === 'ar' ? 'سجل القطع المستبدلة' : 'Catalogue des pièces'}</span>
        </label>

        {parts.length > 0 && (
          <div className="space-y-1 mb-2">
            {parts.map((p, idx) => (
              <div key={idx} className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded-lg border border-[#DCE7E3]">
                <div>
                  <strong>{p.name}</strong> {p.reference && <span className="text-[#668087]">({p.reference})</span>}
                  <span className="text-[#16A6A0] ms-2">x{p.quantity}</span>
                  {p.unitCost > 0 && <span className="ms-2 text-[#102A35] font-bold">({p.unitCost * p.quantity} {currency})</span>}
                </div>
                <button
                  type="button"
                  onClick={() => handleRemovePart(idx)}
                  className="text-[#C94E4E] hover:text-red-700 cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <input
            type="text"
            placeholder={t('partName')}
            value={partNameDraft}
            onChange={(e) => setPartNameDraft(e.target.value)}
            className="bg-white border border-[#DCE7E3] rounded-lg p-1.5 text-xs col-span-2 sm:col-span-1"
          />
          <input
            type="text"
            placeholder={t('partRef')}
            value={partRefDraft}
            onChange={(e) => setPartRefDraft(e.target.value)}
            className="bg-white border border-[#DCE7E3] rounded-lg p-1.5 text-xs"
          />
          <input
            type="number"
            placeholder={t('partQty')}
            value={partQtyDraft}
            onChange={(e) => setPartQtyDraft(e.target.value)}
            className="bg-white border border-[#DCE7E3] rounded-lg p-1.5 text-xs"
          />
          <div className="flex gap-1">
            <input
              type="number"
              placeholder={t('partCost')}
              value={partCostDraft}
              onChange={(e) => setPartCostDraft(e.target.value)}
              className="w-full bg-white border border-[#DCE7E3] rounded-lg p-1.5 text-xs"
            />
            <button
              type="button"
              onClick={handleAddPart}
              className="px-2 py-1 bg-[#16A6A0] text-white rounded-lg font-bold cursor-pointer"
            >
              <Plus size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Notes */}
      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('notes')}</label>
        <textarea
          rows={2}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder={t('addNotes')}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
        />
      </div>

      {error && <p className="text-xs text-[#C94E4E] font-medium">{error}</p>}

      <div className="flex justify-end gap-2.5 pt-3 border-t border-[#EDF2F0]">
        <button
          type="button"
          onClick={onClose}
          className="min-h-[44px] px-5 py-2.5 bg-[#F4F7F5] hover:bg-[#EDF2F0] text-[#102A35] rounded-xl font-bold transition-all cursor-pointer"
        >
          {t('cancel')}
        </button>
        <button
          type="submit"
          className="min-h-[44px] px-6 py-2.5 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-xl font-bold shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Check size={16} />
          <span>{t('saveMaintenance')}</span>
        </button>
      </div>
    </form>
  );
}

// -------------------------------------------------------------
// Form: Add/Edit Vehicle
// -------------------------------------------------------------
function VehicleForm({
  vehicle,
  onClose,
}: {
  vehicle: Vehicle | null;
  onClose: () => void;
}) {
  const { t, language, addVehicle, updateVehicle } = useSiyantek();
  const [brand, setBrand] = useState(vehicle?.brand || '');
  const [model, setModel] = useState(vehicle?.model || '');
  const [year, setYear] = useState(vehicle?.year || '');
  const [plate, setPlate] = useState(vehicle?.plate || '');
  const [mileage, setMileage] = useState(vehicle?.mileage?.toString() || '');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brand.trim() || !model.trim()) {
      setError(language === 'ar' ? 'الماركة والموديل مطلوبان.' : 'Marque et modèle obligatoires.');
      return;
    }

    const payload = {
      brand: brand.trim(),
      model: model.trim(),
      year: year.trim(),
      plate: plate.trim(),
      mileage: Math.max(0, Number(mileage) || 0),
    };

    if (vehicle) {
      await updateVehicle({ ...vehicle, ...payload });
    } else {
      const res = await addVehicle(payload);
      if (res && res.error) {
        setError(res.error);
        return;
      }
    }
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('brand')}</label>
        <input
          type="text"
          placeholder="Ex: Volkswagen, Peugeot, Toyota..."
          value={brand}
          onChange={(e) => setBrand(e.target.value)}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
          required
        />
      </div>
      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('model')}</label>
        <input
          type="text"
          placeholder="Ex: Golf 7, Clio 4, Hilux..."
          value={model}
          onChange={(e) => setModel(e.target.value)}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
          required
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('year')}</label>
          <input
            type="text"
            placeholder="Ex: 2019"
            value={year}
            onChange={(e) => setYear(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
          />
        </div>
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('plate')}</label>
          <input
            type="text"
            placeholder="Ex: 215 TN 4820"
            value={plate}
            onChange={(e) => setPlate(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 font-mono"
          />
        </div>
      </div>
      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('currentMileage')} (km)</label>
        <input
          type="number"
          placeholder="Ex: 85000"
          value={mileage}
          onChange={(e) => setMileage(e.target.value)}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 font-bold"
        />
      </div>

      {error && <p className="text-xs text-[#C94E4E] font-medium">{error}</p>}

      <div className="flex justify-end gap-2.5 pt-3 border-t border-[#EDF2F0]">
        <button
          type="button"
          onClick={onClose}
          className="min-h-[44px] px-5 py-2.5 bg-[#F4F7F5] hover:bg-[#EDF2F0] text-[#102A35] rounded-xl font-bold transition-all cursor-pointer"
        >
          {t('cancel')}
        </button>
        <button
          type="submit"
          className="min-h-[44px] px-6 py-2.5 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-xl font-bold shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Check size={16} />
          <span>{t('saveChanges')}</span>
        </button>
      </div>
    </form>
  );
}

// -------------------------------------------------------------
// Form: Add Reminder
// -------------------------------------------------------------
function ReminderForm({ onClose }: { onClose: () => void }) {
  const { t, language, activeVehicle, addReminder } = useSiyantek();
  const [title, setTitle] = useState('');
  const [type, setType] = useState<any>('oil');
  const [dueDate, setDueDate] = useState('');
  const [dueMileage, setDueMileage] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError(language === 'ar' ? 'عنوان التنبيه مطلوب.' : t('reminderTitle') + ' obligatoire');
      return;
    }

    const res = await addReminder({
      vehicleId: activeVehicle?.id || 'veh_default_1',
      title: title.trim(),
      type,
      dueDate: dueDate || undefined,
      dueMileage: dueMileage ? Number(dueMileage) : undefined,
      notes: notes.trim() || undefined,
      completed: false,
    });

    if (res && res.error) {
      setError(res.error);
      return;
    }
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('reminderTitle')}</label>
        <input
          type="text"
          placeholder="Ex: Vidange moteur 90,000 km, Visite technique..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
          required
        />
      </div>

      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('reminderType')}</label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
        >
          <option value="oil">{t('typeOil')}</option>
          <option value="inspection">{t('typeInspection')}</option>
          <option value="insurance">{t('typeInsurance')}</option>
          <option value="vignette">{t('typeVignette')}</option>
          <option value="brakes">{t('typeBrakes')}</option>
          <option value="belt">{t('typeBelt')}</option>
          <option value="custom">{t('typeCustom')}</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('dueDate')}</label>
          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
          />
        </div>
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('dueMileage')}</label>
          <input
            type="number"
            placeholder="Ex: 90000"
            value={dueMileage}
            onChange={(e) => setDueMileage(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
          />
        </div>
      </div>

      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('notes')}</label>
        <textarea
          rows={2}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder={t('addNotes')}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2"
        />
      </div>

      {error && <p className="text-xs text-[#C94E4E] font-medium">{error}</p>}

      <div className="flex justify-end gap-2.5 pt-3 border-t border-[#EDF2F0]">
        <button
          type="button"
          onClick={onClose}
          className="min-h-[44px] px-5 py-2.5 bg-[#F4F7F5] hover:bg-[#EDF2F0] text-[#102A35] rounded-xl font-bold transition-all cursor-pointer"
        >
          {t('cancel')}
        </button>
        <button
          type="submit"
          className="min-h-[44px] px-6 py-2.5 bg-[#16A6A0] hover:bg-[#138e89] text-white rounded-xl font-bold shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Check size={16} />
          <span>{t('addReminder')}</span>
        </button>
      </div>
    </form>
  );
}

// -------------------------------------------------------------
// Account / Login Modal Content
// -------------------------------------------------------------
function AccountModalContent({ onClose }: { onClose: () => void }) {
  const { t, language, user, isLoggedIn, login, register, logout, deleteAccount, vehicles } = useSiyantek();
  const [isRegistering, setIsRegistering] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (isRegistering) {
      if (!name.trim()) {
        setError(language === 'ar' ? 'الاسم الكامل مطلوب.' : 'Nom complet obligatoire.');
        setLoading(false);
        return;
      }
      const res = await register(name, email, password);
      setLoading(false);
      if (!res.success) {
        setError(res.error || (language === 'ar' ? 'فشل إنشاء الحساب' : "Erreur d'inscription"));
      } else {
        onClose();
      }
    } else {
      const res = await login(email, password);
      setLoading(false);
      if (!res.success) {
        setError(res.error || (language === 'ar' ? 'فشل تسجيل الدخول' : 'Erreur de connexion'));
      } else {
        onClose();
      }
    }
  };

  if (isLoggedIn && user) {
    return (
      <div className="space-y-4 text-xs">
        <div className="bg-[#F8FAF9] p-4 rounded-xl border border-[#EDF2F0] space-y-2">
          <div className="flex justify-between">
            <span className="text-[#668087]">{t('fullName')}:</span>
            <strong className="text-[#102A35]">{user.name}</strong>
          </div>
          <div className="flex justify-between">
            <span className="text-[#668087]">{t('email')}:</span>
            <strong className="text-[#102A35]">{user.email}</strong>
          </div>
          <div className="flex justify-between">
            <span className="text-[#668087]">{language === 'ar' ? 'الباقة' : 'Formule'}:</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#16A6A0]/15 text-[#16A6A0] uppercase">
              {user.tier}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#668087]">{language === 'ar' ? 'السيارات المسجلة' : 'Véhicules enregistrés'}:</span>
            <strong className="text-[#102A35]">{vehicles.length}</strong>
          </div>
        </div>

        <div className="space-y-2 pt-2">
          <button
            onClick={() => {
              logout();
              onClose();
            }}
            className="w-full py-2.5 bg-[#EDF2F0] hover:bg-[#DCE7E3] text-[#102A35] rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut size={16} />
            <span>{t('logout')}</span>
          </button>

          <button
            onClick={() => {
              if (confirm(language === 'ar' ? 'هل تريد حذف حسابك وسجلاتك نهائياً؟' : 'Voulez-vous supprimer définitivement votre compte et toutes vos données associées ?')) {
                deleteAccount();
                onClose();
              }
            }}
            className="w-full py-2 text-[#C94E4E] hover:underline text-center text-xs font-medium cursor-pointer"
          >
            {language === 'ar' ? 'حذف الحساب نهائياً' : 'Supprimer mon compte définitivement'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleAuth} className="space-y-3.5 text-xs">
      {isRegistering && (
        <div>
          <label className="block font-bold text-[#102A35] mb-1">{t('fullName')}</label>
          <input
            type="text"
            placeholder="Mohamed Ben Salem"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 text-xs"
            required
          />
        </div>
      )}

      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('email')}</label>
        <input
          type="email"
          placeholder="votre.email@exemple.tn"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 text-xs"
          required
        />
      </div>

      <div>
        <label className="block font-bold text-[#102A35] mb-1">{t('password')}</label>
        <input
          type="password"
          placeholder={language === 'ar' ? '8 أحرف على الأقل' : 'Min. 8 caractères'}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 text-xs"
          required
        />
      </div>

      {error && <p className="text-xs text-[#C94E4E] font-medium">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full py-2.5 bg-[#16A6A0] hover:bg-[#138e89] disabled:bg-gray-300 text-white rounded-xl font-bold shadow-xs flex items-center justify-center gap-2 cursor-pointer"
      >
        {loading && <RefreshCw size={14} className="animate-spin" />}
        <span>{isRegistering ? t('register') : t('login')}</span>
      </button>

      <div className="text-center pt-2 border-t border-[#EDF2F0]">
        <button
          type="button"
          onClick={() => {
            setIsRegistering(!isRegistering);
            setError('');
          }}
          className="text-xs text-[#16A6A0] font-bold hover:underline cursor-pointer"
        >
          {isRegistering ? t('alreadyAccount') : t('noAccount')}
        </button>
      </div>
    </form>
  );
}

// -------------------------------------------------------------
// Component: Contact & WhatsApp Support Modal
// -------------------------------------------------------------
function SupportModalContent({ onClose }: { onClose: () => void }) {
  const { t, language } = useSiyantek();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ message: string; isError: boolean } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setFeedback(null);

    try {
      const res = await fetch(apiUrl('/api/support/contact'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, subject, message }),
      });
      const data = await res.json();
      setLoading(false);

      if (!res.ok) {
        setFeedback({ message: data.error || (language === 'ar' ? 'تعذر إرسال الرسالة' : 'Échec de l\'envoi'), isError: true });
      } else {
        setFeedback({
          message: language === 'ar' ? data.messageAr || t('supportSent') : data.message || t('supportSent'),
          isError: false,
        });
        setName('');
        setEmail('');
        setSubject('');
        setMessage('');
      }
    } catch {
      setLoading(false);
      setFeedback({
        message: language === 'ar' ? 'حدث خطأ في الاتصال بالخادم.' : 'Erreur de connexion au serveur.',
        isError: true,
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
          <div className="flex items-center gap-2">
            <HelpCircle size={18} className="text-[#16A6A0]" />
            <h3 className="font-extrabold text-base text-[#102A35]">{t('contactSupport')}</h3>
          </div>
          <button onClick={onClose} className="text-[#668087] hover:text-[#102A35] cursor-pointer">
            <X size={18} />
          </button>
        </div>

        {/* Direct WhatsApp Callout */}
        <div className="bg-[#F0FDF4] p-3.5 rounded-xl border border-[#BBF7D0] flex items-center justify-between gap-3">
          <div>
            <h4 className="font-bold text-xs text-[#166534]">{t('whatsappSupport')}</h4>
            <p className="text-[11px] text-[#15803D]">
              {language === 'ar' ? 'استفسارات، باقات Pro ودعم فني سريع' : 'Questions, formules et assistance rapide'}
            </p>
          </div>
          <a
            href="https://wa.me/21629000000?text=Bonjour%20Siyantek%2C%20je%20souhaite%20des%20informations%20sur%20l'application"
            target="_blank"
            rel="noopener noreferrer"
            className="min-h-[38px] px-3.5 py-1.5 bg-[#22C55E] hover:bg-[#16A34A] text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1.5 shrink-0"
          >
            WhatsApp
          </a>
        </div>

        {feedback && (
          <div
            className={`p-3 rounded-xl text-xs font-semibold ${
              feedback.isError ? 'bg-[#FEF2F2] text-[#991B1B] border border-[#FCA5A5]' : 'bg-[#F0FDF4] text-[#166534] border border-[#86EFAC]'
            }`}
          >
            {feedback.message}
          </div>
        )}

        {/* Contact Form */}
        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-bold text-[#102A35] mb-1">{t('fullName')}</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Ahmed Ben Ali"
              className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 text-xs"
            />
          </div>

          <div>
            <label className="block font-bold text-[#102A35] mb-1">{t('email')}</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="contact@exemple.tn"
              className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 text-xs"
            />
          </div>

          <div>
            <label className="block font-bold text-[#102A35] mb-1">{t('supportSubject')}</label>
            <input
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder={language === 'ar' ? 'استفسار عن اشتراك أو صيانة' : 'Demande d\'information ou assistance'}
              className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 text-xs"
            />
          </div>

          <div>
            <label className="block font-bold text-[#102A35] mb-1">{t('supportMessage')}</label>
            <textarea
              required
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={language === 'ar' ? 'اكتب رسالتك بالتفصيل هنا...' : 'Détaillez votre message ou question ici...'}
              className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg p-2 text-xs"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2 border-t border-[#EDF2F0]">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] px-4 py-2 bg-[#F4F7F5] hover:bg-[#EDF2F0] text-[#102A35] rounded-xl font-bold cursor-pointer"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="min-h-[40px] px-5 py-2 bg-[#16A6A0] hover:bg-[#138e89] disabled:bg-gray-300 text-white rounded-xl font-bold shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {loading && <RefreshCw size={14} className="animate-spin" />}
              <span>{t('sendSupportMessage')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// Component: Manual Tunisian Bank / Postal Payment & Receipt Upload Modal
// -------------------------------------------------------------
function ManualPaymentModal({
  initialPlan,
  onClose,
}: {
  initialPlan: 'plus' | 'pro';
  onClose: () => void;
}) {
  const {
    t,
    language,
    myPayments,
    fetchMyPayments,
    createManualOrder,
    uploadReceipt,
  } = useSiyantek();

  const [selectedPlan, setSelectedPlan] = useState<'plus' | 'pro'>(initialPlan);
  const [method, setMethod] = useState<'bank_transfer' | 'postal_order' | 'd17'>('bank_transfer');
  const [activeOrder, setActiveOrder] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadFeedback, setUploadFeedback] = useState<{ message: string; isError: boolean } | null>(null);

  // If user already has an active pending/submitted order for this plan, preselect it
  useEffect(() => {
    fetchMyPayments();
  }, []);

  useEffect(() => {
    if (myPayments && myPayments.length > 0 && !activeOrder) {
      const pending = myPayments.find((p) => p.status === 'pending' || p.status === 'submitted');
      if (pending) {
        setActiveOrder(pending);
        setSelectedPlan(pending.planId as any);
      }
    }
  }, [myPayments, activeOrder]);

  const handleCreateOrder = async () => {
    setLoading(true);
    setUploadFeedback(null);
    const res = await createManualOrder(selectedPlan, method);
    setLoading(false);
    if (!res.success) {
      setUploadFeedback({ message: res.error || 'Erreur lors de la création de la commande.', isError: true });
    } else {
      setActiveOrder(res.order);
      setUploadFeedback({
        message: language === 'ar' ? 'تم إنشاء أمر الدفع بنجاح. يرجى إتمام التحويل ورفع الوصل.' : 'Ordre de paiement créé. Veuillez effectuer le virement puis déposer votre justificatif.',
        isError: false,
      });
    }
  };

  const handleCopyRef = (refText: string) => {
    try {
      navigator.clipboard.writeText(refText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {}
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError('');
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) {
      setFileError(language === 'ar' ? 'حجم الملف يتجاوز الحد الأقصى (5 ميغابايت).' : 'Le fichier dépasse la taille maximale autorisée de 5 Mo.');
      return;
    }
    setFile(f);
  };

  const handleUploadReceipt = async () => {
    if (!file || !activeOrder) return;
    setUploading(true);
    setUploadFeedback(null);
    setFileError('');

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      const res = await uploadReceipt(activeOrder.id, base64Data, file.type, file.name);
      setUploading(false);
      if (!res.success) {
        setUploadFeedback({ message: res.error || 'Échec du téléversement.', isError: true });
      } else {
        setUploadFeedback({
          message: res.message || (language === 'ar' ? 'تم استلام الوصل بنجاح وجارٍ التحقق منه.' : 'Reçu téléversé avec succès. Vérification en cours.'),
          isError: false,
        });
        if (res.order) {
          setActiveOrder(res.order);
        }
        setFile(null);
      }
    };
    reader.onerror = () => {
      setUploading(false);
      setFileError('Impossible de lire le fichier.');
    };
    reader.readAsDataURL(file);
  };

  const amountDT = selectedPlan === 'plus' ? 9.9 : 19.9;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full p-5 sm:p-6 shadow-2xl space-y-4 my-6 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-xl bg-[#16A6A0]/15 text-[#16A6A0] flex items-center justify-center">
              <CreditCard size={20} />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-[#102A35]">{t('manualPaymentTitle')}</h3>
              <p className="text-[11px] text-[#607D89]">{t('manualPaymentSubtitle')}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#668087] hover:text-[#102A35] cursor-pointer">
            <X size={18} />
          </button>
        </div>

        {uploadFeedback && (
          <div
            className={`p-3 rounded-xl text-xs font-semibold flex items-center justify-between border ${
              uploadFeedback.isError
                ? 'bg-[#FEF2F2] text-[#991B1B] border-[#FCA5A5]'
                : 'bg-[#F0FDF4] text-[#166534] border-[#86EFAC]'
            }`}
          >
            <span>{uploadFeedback.message}</span>
            <button
              onClick={() => setUploadFeedback(null)}
              className="px-2 py-0.5 text-xs font-bold hover:bg-black/5 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* 1. Plan Selector if no active order */}
        {!activeOrder && (
          <div className="space-y-3">
            <label className="block text-xs font-bold text-[#102A35]">
              {language === 'ar' ? '1. اختر باقة الاشتراك المطلوبة' : '1. Choisissez votre formule'}
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setSelectedPlan('plus')}
                className={`p-3.5 rounded-xl border text-start transition-all cursor-pointer ${
                  selectedPlan === 'plus'
                    ? 'border-[#16A6A0] bg-[#16A6A0]/5 ring-2 ring-[#16A6A0]/20'
                    : 'border-[#DCE7E3] hover:border-[#16A6A0]/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-sm text-[#102A35]">Siyantek Plus</span>
                  <span className="font-black text-sm text-[#16A6A0]">9.9 DT</span>
                </div>
                <p className="text-[11px] text-[#607D89] mt-1">
                  {language === 'ar' ? 'حتى 3 سيارات + تقارير PDF' : 'Jusqu\'à 3 véhicules + rapports PDF'}
                </p>
              </button>

              <button
                type="button"
                onClick={() => setSelectedPlan('pro')}
                className={`p-3.5 rounded-xl border text-start transition-all cursor-pointer ${
                  selectedPlan === 'pro'
                    ? 'border-[#16A6A0] bg-[#16A6A0]/5 ring-2 ring-[#16A6A0]/20'
                    : 'border-[#DCE7E3] hover:border-[#16A6A0]/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-sm text-[#102A35]">Siyantek Pro</span>
                  <span className="font-black text-sm text-[#16A6A0]">19.9 DT</span>
                </div>
                <p className="text-[11px] text-[#607D89] mt-1">
                  {language === 'ar' ? 'حتى 5 سيارات + دعم VIP' : 'Jusqu\'à 5 véhicules + support VIP'}
                </p>
              </button>
            </div>

            {/* Method choice */}
            <label className="block text-xs font-bold text-[#102A35] pt-1">
              {language === 'ar' ? '2. وسيلة الدفع المفضلة في تونس' : '2. Méthode de versement en Tunisie'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setMethod('bank_transfer')}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer ${
                  method === 'bank_transfer'
                    ? 'border-[#16A6A0] bg-[#16A6A0]/10 text-[#16A6A0]'
                    : 'border-[#DCE7E3] text-[#607D89] hover:bg-[#F8FAF9]'
                }`}
              >
                {t('bankTransfer')}
              </button>
              <button
                type="button"
                onClick={() => setMethod('postal_order')}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer ${
                  method === 'postal_order'
                    ? 'border-[#16A6A0] bg-[#16A6A0]/10 text-[#16A6A0]'
                    : 'border-[#DCE7E3] text-[#607D89] hover:bg-[#F8FAF9]'
                }`}
              >
                {t('postalTransfer')}
              </button>
              <button
                type="button"
                onClick={() => setMethod('d17')}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer ${
                  method === 'd17'
                    ? 'border-[#16A6A0] bg-[#16A6A0]/10 text-[#16A6A0]'
                    : 'border-[#DCE7E3] text-[#607D89] hover:bg-[#F8FAF9]'
                }`}
              >
                D17 Mobile
              </button>
            </div>

            <button
              type="button"
              onClick={handleCreateOrder}
              disabled={loading}
              className="w-full mt-2 min-h-[44px] py-2.5 bg-[#16A6A0] hover:bg-[#138e89] disabled:bg-gray-300 text-white rounded-xl text-xs font-extrabold shadow-sm flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              {loading && <RefreshCw size={14} className="animate-spin" />}
              <span>
                {language === 'ar'
                  ? `إنشاء أمر الدفع (${amountDT} د.ت)`
                  : `Générer mon ordre de paiement (${amountDT} DT)`}
              </span>
            </button>
          </div>
        )}

        {/* 2. Order Active / Instructions Box */}
        {activeOrder && (
          <div className="space-y-4">
            {/* Status Ribbon */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-[#F8FAF9] border border-[#DCE7E3]">
              <div>
                <span className="text-[10px] text-[#607D89] font-bold uppercase tracking-wider block">
                  {language === 'ar' ? 'حالة الطلب' : 'Statut de la commande'}
                </span>
                <span
                  className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold mt-0.5 ${
                    activeOrder.status === 'approved' || activeOrder.status === 'completed'
                      ? 'bg-[#DEF7EC] text-[#03543F]'
                      : activeOrder.status === 'submitted'
                      ? 'bg-[#E1EFFE] text-[#1E429F]'
                      : activeOrder.status === 'rejected'
                      ? 'bg-[#FDE8E8] text-[#9B1C1C]'
                      : 'bg-[#FEF08A] text-[#854D0E]'
                  }`}
                >
                  {activeOrder.status === 'approved' || activeOrder.status === 'completed'
                    ? t('orderStatusApproved')
                    : activeOrder.status === 'submitted'
                    ? t('orderStatusSubmitted')
                    : activeOrder.status === 'rejected'
                    ? t('orderStatusRejected')
                    : t('orderStatusPending')}
                </span>
              </div>
              <div className="text-end">
                <span className="text-[10px] text-[#607D89] font-bold uppercase tracking-wider block">
                  {language === 'ar' ? 'المبلغ المطلوب' : 'Montant à payer'}
                </span>
                <span className="font-black text-lg text-[#102A35]">
                  {activeOrder.amountDT} DT
                </span>
              </div>
            </div>

            {/* Reference to Copy */}
            <div className="p-3.5 bg-[#16A6A0]/10 border-2 border-dashed border-[#16A6A0] rounded-xl flex items-center justify-between gap-2">
              <div>
                <span className="text-[10px] font-bold text-[#16A6A0] uppercase tracking-wide block">
                  {t('paymentReference')}
                </span>
                <span className="font-mono font-black text-base text-[#102A35] tracking-wider select-all">
                  {activeOrder.transferReference || activeOrder.id}
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleCopyRef(activeOrder.transferReference || activeOrder.id)}
                className="px-3 py-1.5 bg-white hover:bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg text-xs font-bold text-[#102A35] shadow-xs flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check size={14} className="text-[#2B9A70]" /> : <Copy size={14} />}
                <span>{copied ? (language === 'ar' ? 'تم النسخ' : 'Copié !') : (language === 'ar' ? 'نسخ' : 'Copier')}</span>
              </button>
            </div>

            {/* Configurable Tunisian Transfer Instructions */}
            <div className="bg-[#F8FAF9] p-3.5 rounded-xl border border-[#DCE7E3] space-y-2 text-xs">
              <div className="flex justify-between border-b border-[#EDF2F0] pb-1.5">
                <span className="text-[#607D89]">{t('bankBeneficiary')}:</span>
                <strong className="text-[#102A35]">
                  {activeOrder.bankInstructions?.accountName || 'Siyantek Auto Tech SARL'}
                </strong>
              </div>
              <div className="flex justify-between border-b border-[#EDF2F0] pb-1.5">
                <span className="text-[#607D89]">{t('bankNameLabel')}:</span>
                <strong className="text-[#102A35]">
                  {activeOrder.bankInstructions?.bankName || 'BIAT'}
                </strong>
              </div>
              <div className="flex justify-between border-b border-[#EDF2F0] pb-1.5">
                <span className="text-[#607D89]">{t('ribLabel')}:</span>
                <strong className="font-mono text-[#102A35]">
                  {activeOrder.bankInstructions?.rib || '08001000123456789012'}
                </strong>
              </div>
              <div className="flex justify-between border-b border-[#EDF2F0] pb-1.5">
                <span className="text-[#607D89]">{t('postalRipLabel')}:</span>
                <strong className="font-mono text-[#102A35]">
                  {activeOrder.bankInstructions?.postalRip || '17001000001234567890'}
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-[#607D89]">{t('d17PhoneLabel')}:</span>
                <strong className="font-mono text-[#102A35]">
                  {activeOrder.bankInstructions?.d17Phone || '+216 28 000 000'}
                </strong>
              </div>
            </div>

            {/* Admin Notes if rejected */}
            {activeOrder.adminNotes && (
              <div className="p-3 bg-[#FEF2F2] border border-[#FCA5A5] rounded-xl text-xs text-[#991B1B]">
                <strong className="block mb-0.5">{language === 'ar' ? 'ملاحظة الإدارة:' : 'Note de l\'administration :'}</strong>
                <span>{activeOrder.adminNotes}</span>
              </div>
            )}

            {/* 3. Receipt Upload Section */}
            {activeOrder.status !== 'approved' && activeOrder.status !== 'completed' && (
              <div className="space-y-2.5 pt-1">
                <label className="block text-xs font-bold text-[#102A35]">
                  {t('uploadReceiptTitle')}
                </label>
                <p className="text-[11px] text-[#607D89]">
                  {t('uploadReceiptDesc')}
                </p>

                <div className="flex items-center gap-3">
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,application/pdf"
                    onChange={handleFileChange}
                    className="text-xs file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-[#16A6A0]/10 file:text-[#16A6A0] hover:file:bg-[#16A6A0]/20 cursor-pointer"
                  />
                  {file && (
                    <button
                      type="button"
                      onClick={handleUploadReceipt}
                      disabled={uploading}
                      className="min-h-[38px] px-4 py-2 bg-[#16A6A0] hover:bg-[#138e89] disabled:bg-gray-300 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      {uploading ? <RefreshCw size={14} className="animate-spin" /> : <Upload size={14} />}
                      <span>{t('submitReceiptBtn')}</span>
                    </button>
                  )}
                </div>

                {fileError && <p className="text-xs text-[#C94E4E] font-medium">{fileError}</p>}

                {activeOrder.receiptFilename && (
                  <div className="p-2.5 bg-[#EDF2F0] rounded-xl flex items-center justify-between text-xs">
                    <span className="text-[#102A35] font-semibold truncate">
                      📎 {activeOrder.receiptFilename}
                    </span>
                    <a
                      href={`${API_BASE_URL}/api/subscription/manual-order/${activeOrder.id}/receipt`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#16A6A0] font-bold hover:underline shrink-0 ms-2"
                    >
                      {language === 'ar' ? 'عرض الوصل المرفوع' : 'Voir le reçu déposé'}
                    </a>
                  </div>
                )}
              </div>
            )}

            {/* Option to create a new order */}
            <div className="pt-2 border-t border-[#EDF2F0] flex justify-between items-center text-xs">
              <button
                type="button"
                onClick={() => setActiveOrder(null)}
                className="text-[#607D89] hover:text-[#102A35] font-semibold underline cursor-pointer"
              >
                {language === 'ar' ? 'إنشاء أمر دفع جديد' : 'Créer une autre commande'}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-[#F4F7F5] hover:bg-[#EDF2F0] text-[#102A35] rounded-xl font-bold cursor-pointer"
              >
                {t('close')}
              </button>
            </div>
          </div>
        )}

        {/* 4. Past Orders List */}
        {myPayments && myPayments.length > 0 && (
          <div className="pt-3 border-t border-[#EDF2F0] space-y-2">
            <h4 className="font-bold text-xs text-[#102A35]">
              {language === 'ar' ? 'سجل طلبات الدفع الخاصة بك' : 'Historique de vos commandes'}
            </h4>
            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {myPayments.map((p) => (
                <div
                  key={p.id}
                  onClick={() => setActiveOrder(p)}
                  className={`p-2 rounded-xl border text-xs flex items-center justify-between cursor-pointer transition-all ${
                    activeOrder?.id === p.id
                      ? 'border-[#16A6A0] bg-[#16A6A0]/5'
                      : 'border-[#EDF2F0] hover:bg-[#F8FAF9]'
                  }`}
                >
                  <div>
                    <span className="font-bold text-[#102A35] uppercase">{p.planId} ({p.amountDT} DT)</span>
                    <span className="text-[11px] text-[#607D89] block font-mono">{p.transferReference || p.id}</span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      p.status === 'approved' || p.status === 'completed'
                        ? 'bg-[#DEF7EC] text-[#03543F]'
                        : p.status === 'submitted'
                        ? 'bg-[#E1EFFE] text-[#1E429F]'
                        : p.status === 'rejected'
                        ? 'bg-[#FDE8E8] text-[#9B1C1C]'
                        : 'bg-[#FEF08A] text-[#854D0E]'
                    }`}
                  >
                    {p.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// Component: Admin Back-Office Modal (Priority 2)
// -------------------------------------------------------------
function AdminBackOfficeModal({ onClose }: { onClose: () => void }) {
  const {
    t,
    language,
    fetchAdminStats,
    fetchAdminUsers,
    fetchAdminPayments,
    approvePayment,
    rejectPayment,
    updateUserTier,
    fetchAuditLogs,
  } = useSiyantek();

  const [activeTab, setActiveTab] = useState<'stats' | 'payments' | 'users' | 'audit'>('stats');
  const [stats, setStats] = useState<any>(null);
  const [payments, setPayments] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter & Search states
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [userSearch, setUserSearch] = useState('');
  const [previewReceiptId, setPreviewReceiptId] = useState<string | null>(null);

  // Action states
  const [actionLoading, setActionLoading] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [rejectDialog, setRejectDialog] = useState<{ id: string; notes: string } | null>(null);

  const loadData = async () => {
    setLoading(true);
    const [s, p, u, a] = await Promise.all([
      fetchAdminStats(),
      fetchAdminPayments(),
      fetchAdminUsers(),
      fetchAuditLogs(),
    ]);
    setStats(s);
    setPayments(p);
    setUsers(u);
    setAuditLogs(a);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleApprove = async (id: string) => {
    setActionLoading(true);
    setActionFeedback(null);
    const res = await approvePayment(id);
    setActionLoading(false);
    if (!res.success) {
      setActionFeedback(`Erreur : ${res.error}`);
    } else {
      setActionFeedback(res.message || 'Paiement approuvé avec succès.');
      loadData();
    }
  };

  const handleRejectConfirm = async () => {
    if (!rejectDialog) return;
    setActionLoading(true);
    const res = await rejectPayment(rejectDialog.id, rejectDialog.notes);
    setActionLoading(false);
    setRejectDialog(null);
    if (!res.success) {
      setActionFeedback(`Erreur : ${res.error}`);
    } else {
      setActionFeedback(res.message || 'Paiement rejeté.');
      loadData();
    }
  };

  const handleTierChange = async (userId: string, newTier: 'free' | 'plus' | 'pro') => {
    setActionLoading(true);
    const res = await updateUserTier(userId, newTier, 30);
    setActionLoading(false);
    if (res.success) {
      setActionFeedback(`Abonnement utilisateur mis à jour vers ${newTier.toUpperCase()}.`);
      loadData();
    }
  };

  const filteredPayments = useMemo(() => {
    if (paymentFilter === 'all') return payments;
    return payments.filter((p) => p.status === paymentFilter);
  }, [payments, paymentFilter]);

  const filteredUsers = useMemo(() => {
    if (!userSearch.trim()) return users;
    const q = userSearch.toLowerCase();
    return users.filter(
      (u) =>
        (u.name && u.name.toLowerCase().includes(q)) ||
        (u.email && u.email.toLowerCase().includes(q))
    );
  }, [users, userSearch]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-2 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-5xl w-full p-4 sm:p-6 shadow-2xl space-y-4 my-4 max-h-[94vh] flex flex-col">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="h-10 w-10 rounded-xl bg-[#16A6A0] text-white flex items-center justify-center shadow-xs">
              <Shield size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-[#102A35]">
                  {t('adminDashboard')}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#16A6A0]/15 text-[#16A6A0] uppercase">
                  {t('adminBadge')}
                </span>
              </div>
              <p className="text-[11px] text-[#607D89]">
                {language === 'ar'
                  ? 'إدارة الاشتراكات، مطابقة وصولات الدفع، الحسابات، وسجل الأمان'
                  : 'Gestion des abonnements, validation des virements, utilisateurs et audit'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#668087] hover:text-[#102A35] cursor-pointer">
            <X size={20} />
          </button>
        </div>

        {/* Action feedback */}
        {actionFeedback && (
          <div className="p-3 bg-[#F0FDF4] border border-[#86EFAC] text-[#166534] rounded-xl text-xs font-semibold flex items-center justify-between">
            <span>{actionFeedback}</span>
            <button onClick={() => setActionFeedback(null)} className="font-bold px-2 cursor-pointer">✕</button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 border-b border-[#EDF2F0] pb-2 overflow-x-auto text-xs font-bold">
          <button
            onClick={() => setActiveTab('stats')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'stats'
                ? 'bg-[#16A6A0] text-white shadow-xs'
                : 'text-[#607D89] hover:bg-[#F4F7F5]'
            }`}
          >
            <Activity size={14} />
            <span>{t('adminStatsTab')}</span>
          </button>
          <button
            onClick={() => setActiveTab('payments')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'payments'
                ? 'bg-[#16A6A0] text-white shadow-xs'
                : 'text-[#607D89] hover:bg-[#F4F7F5]'
            }`}
          >
            <CreditCard size={14} />
            <span>{t('adminPaymentsTab')}</span>
            {payments.filter((p) => p.status === 'submitted').length > 0 && (
              <span className="bg-[#C94E4E] text-white rounded-full px-1.5 py-0.2 text-[10px]">
                {payments.filter((p) => p.status === 'submitted').length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'users'
                ? 'bg-[#16A6A0] text-white shadow-xs'
                : 'text-[#607D89] hover:bg-[#F4F7F5]'
            }`}
          >
            <Users size={14} />
            <span>{t('adminUsersTab')} ({users.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'audit'
                ? 'bg-[#16A6A0] text-white shadow-xs'
                : 'text-[#607D89] hover:bg-[#F4F7F5]'
            }`}
          >
            <FileText size={14} />
            <span>{t('adminAuditTab')}</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {loading ? (
            <div className="py-16 text-center text-xs text-[#607D89] flex flex-col items-center justify-center gap-2">
              <RefreshCw size={24} className="animate-spin text-[#16A6A0]" />
              <span>Chargement des données administratives...</span>
            </div>
          ) : (
            <>
              {/* TAB 1: STATS */}
              {activeTab === 'stats' && stats && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-[#F8FAF9] p-3.5 rounded-xl border border-[#DCE7E3]">
                      <span className="text-[11px] text-[#607D89] font-bold block">Total Utilisateurs</span>
                      <strong className="text-2xl font-black text-[#102A35]">{stats.users.total}</strong>
                      <div className="text-[10px] text-[#607D89] mt-1 space-x-1">
                        <span>Free: {stats.users.free}</span>
                        <span>• Plus: {stats.users.plus}</span>
                        <span>• Pro: {stats.users.pro}</span>
                      </div>
                    </div>

                    <div className="bg-[#F8FAF9] p-3.5 rounded-xl border border-[#DCE7E3]">
                      <span className="text-[11px] text-[#607D89] font-bold block">Reçus à Valider</span>
                      <strong className="text-2xl font-black text-[#1E429F]">{stats.payments.submitted}</strong>
                      <p className="text-[10px] text-[#607D89] mt-1">En attente: {stats.payments.pending}</p>
                    </div>

                    <div className="bg-[#F8FAF9] p-3.5 rounded-xl border border-[#DCE7E3]">
                      <span className="text-[11px] text-[#607D89] font-bold block">Paiements Approuvés</span>
                      <strong className="text-2xl font-black text-[#03543F]">{stats.payments.approved}</strong>
                      <p className="text-[10px] text-[#607D89] mt-1">Rejetés: {stats.payments.rejected}</p>
                    </div>

                    <div className="bg-[#F8FAF9] p-3.5 rounded-xl border border-[#DCE7E3]">
                      <span className="text-[11px] text-[#607D89] font-bold block">Chiffre d'Affaires</span>
                      <strong className="text-2xl font-black text-[#16A6A0]">{stats.payments.totalApprovedRevenueDT} DT</strong>
                      <p className="text-[10px] text-[#607D89] mt-1">Volume validé</p>
                    </div>
                  </div>

                  <div className="bg-[#F8FAF9] p-4 rounded-xl border border-[#DCE7E3] space-y-2 text-xs">
                    <h4 className="font-extrabold text-[#102A35]">Données globales de la plateforme</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1 text-center">
                      <div className="bg-white p-2.5 rounded-lg border border-[#EDF2F0]">
                        <span className="text-[10px] text-[#607D89] block">Véhicules</span>
                        <strong className="text-base text-[#102A35]">{stats.database.vehiclesCount}</strong>
                      </div>
                      <div className="bg-white p-2.5 rounded-lg border border-[#EDF2F0]">
                        <span className="text-[10px] text-[#607D89] block">Entretiens</span>
                        <strong className="text-base text-[#102A35]">{stats.database.recordsCount}</strong>
                      </div>
                      <div className="bg-white p-2.5 rounded-lg border border-[#EDF2F0]">
                        <span className="text-[10px] text-[#607D89] block">Rappels</span>
                        <strong className="text-base text-[#102A35]">{stats.database.remindersCount}</strong>
                      </div>
                      <div className="bg-white p-2.5 rounded-lg border border-[#EDF2F0]">
                        <span className="text-[10px] text-[#607D89] block">Logs d'audit</span>
                        <strong className="text-base text-[#102A35]">{stats.database.auditLogsCount}</strong>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: PAYMENTS & VALIDATION */}
              {activeTab === 'payments' && (
                <div className="space-y-3">
                  {/* Status filter bar */}
                  <div className="flex items-center gap-1.5 text-xs">
                    {(['all', 'submitted', 'pending', 'approved', 'rejected'] as const).map((st) => (
                      <button
                        key={st}
                        onClick={() => setPaymentFilter(st)}
                        className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                          paymentFilter === st
                            ? 'bg-[#102A35] text-white'
                            : 'bg-[#F4F7F5] text-[#607D89] hover:bg-[#EDF2F0]'
                        }`}
                      >
                        {st === 'all'
                          ? 'Tous'
                          : st === 'submitted'
                          ? 'À valider'
                          : st === 'pending'
                          ? 'En attente'
                          : st === 'approved'
                          ? 'Approuvés'
                          : 'Rejetés'}
                      </button>
                    ))}
                  </div>

                  {filteredPayments.length === 0 ? (
                    <p className="py-12 text-center text-xs text-[#607D89]">{t('noPaymentsFound')}</p>
                  ) : (
                    <div className="border border-[#DCE7E3] rounded-xl overflow-x-auto">
                      <table className="w-full text-start text-xs border-collapse">
                        <thead>
                          <tr className="bg-[#F8FAF9] border-b border-[#DCE7E3] text-[#607D89]">
                            <th className="p-2.5 text-start font-bold">Date</th>
                            <th className="p-2.5 text-start font-bold">Client</th>
                            <th className="p-2.5 text-start font-bold">Formule</th>
                            <th className="p-2.5 text-start font-bold">Référence</th>
                            <th className="p-2.5 text-start font-bold">Statut</th>
                            <th className="p-2.5 text-start font-bold">Reçu</th>
                            <th className="p-2.5 text-end font-bold">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#EDF2F0]">
                          {filteredPayments.map((p) => (
                            <tr key={p.id} className="hover:bg-[#F8FAF9]/60">
                              <td className="p-2.5 text-[11px] text-[#607D89] whitespace-nowrap">
                                {p.createdAt ? p.createdAt.slice(0, 10) : '-'}
                              </td>
                              <td className="p-2.5 whitespace-nowrap">
                                <strong className="text-[#102A35] block">{p.userName || 'Client'}</strong>
                                <span className="text-[10px] text-[#607D89]">{p.userEmail}</span>
                              </td>
                              <td className="p-2.5 whitespace-nowrap">
                                <span className="font-extrabold text-[#102A35] uppercase">{p.planId}</span>
                                <span className="text-[11px] text-[#16A6A0] font-bold block">{p.amountDT} DT</span>
                              </td>
                              <td className="p-2.5 font-mono text-[11px] text-[#102A35] select-all whitespace-nowrap">
                                {p.transferReference || p.id}
                              </td>
                              <td className="p-2.5 whitespace-nowrap">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    p.status === 'approved' || p.status === 'completed'
                                      ? 'bg-[#DEF7EC] text-[#03543F]'
                                      : p.status === 'submitted'
                                      ? 'bg-[#E1EFFE] text-[#1E429F]'
                                      : p.status === 'rejected'
                                      ? 'bg-[#FDE8E8] text-[#9B1C1C]'
                                      : 'bg-[#FEF08A] text-[#854D0E]'
                                  }`}
                                >
                                  {p.status}
                                </span>
                              </td>
                              <td className="p-2.5 whitespace-nowrap">
                                {p.receiptFilename ? (
                                  <button
                                    onClick={() => setPreviewReceiptId(p.id)}
                                    className="px-2 py-1 bg-[#16A6A0]/10 hover:bg-[#16A6A0]/20 text-[#16A6A0] font-bold rounded text-[11px] flex items-center gap-1 cursor-pointer"
                                  >
                                    <Eye size={12} />
                                    <span>Reçu</span>
                                  </button>
                                ) : (
                                  <span className="text-[10px] text-[#607D89] italic">Non fourni</span>
                                )}
                              </td>
                              <td className="p-2.5 text-end whitespace-nowrap">
                                {p.status !== 'approved' && p.status !== 'completed' ? (
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      onClick={() => handleApprove(p.id)}
                                      disabled={actionLoading}
                                      className="px-2.5 py-1 bg-[#22C55E] hover:bg-[#16A34A] text-white font-bold rounded text-[11px] cursor-pointer shadow-xs disabled:opacity-50"
                                      title="Approuver le virement et activer 30 jours"
                                    >
                                      Approuver
                                    </button>
                                    <button
                                      onClick={() => setRejectDialog({ id: p.id, notes: '' })}
                                      disabled={actionLoading}
                                      className="px-2 py-1 bg-[#EF4444] hover:bg-[#DC2626] text-white font-bold rounded text-[11px] cursor-pointer shadow-xs disabled:opacity-50"
                                    >
                                      Rejeter
                                    </button>
                                  </div>
                                ) : (
                                  <span className="text-[11px] text-[#03543F] font-bold">✓ Validé</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: USERS MANAGEMENT */}
              {activeTab === 'users' && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Search size={14} className="absolute start-3 top-2.5 text-[#607D89]" />
                      <input
                        type="text"
                        placeholder="Rechercher par nom ou email..."
                        value={userSearch}
                        onChange={(e) => setUserSearch(e.target.value)}
                        className="w-full bg-[#F4F7F5] border border-[#DCE7E3] rounded-xl py-2 ps-9 pe-3 text-xs"
                      />
                    </div>
                  </div>

                  <div className="border border-[#DCE7E3] rounded-xl overflow-x-auto">
                    <table className="w-full text-start text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#F8FAF9] border-b border-[#DCE7E3] text-[#607D89]">
                          <th className="p-2.5 text-start font-bold">Nom & Email</th>
                          <th className="p-2.5 text-start font-bold">Rôle</th>
                          <th className="p-2.5 text-start font-bold">Formule</th>
                          <th className="p-2.5 text-start font-bold">Expiration</th>
                          <th className="p-2.5 text-start font-bold">Véhicules</th>
                          <th className="p-2.5 text-end font-bold">Changer formule</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#EDF2F0]">
                        {filteredUsers.map((u) => (
                          <tr key={u.id} className="hover:bg-[#F8FAF9]/60">
                            <td className="p-2.5 whitespace-nowrap">
                              <strong className="text-[#102A35] block">{u.name}</strong>
                              <span className="text-[11px] text-[#607D89]">{u.email}</span>
                            </td>
                            <td className="p-2.5 whitespace-nowrap">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                                  u.role === 'admin'
                                    ? 'bg-[#16A6A0] text-white'
                                    : 'bg-[#EDF2F0] text-[#607D89]'
                                }`}
                              >
                                {u.role || 'user'}
                              </span>
                            </td>
                            <td className="p-2.5 whitespace-nowrap">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#16A6A0]/10 text-[#16A6A0] uppercase border border-[#16A6A0]/20">
                                {u.tier}
                              </span>
                            </td>
                            <td className="p-2.5 text-[11px] text-[#607D89] whitespace-nowrap">
                              {u.subscriptionExpiresAt ? u.subscriptionExpiresAt.slice(0, 10) : 'Permanent / N/A'}
                            </td>
                            <td className="p-2.5 text-[#102A35] font-bold whitespace-nowrap">
                              {u.vehiclesCount || 0} voiture(s)
                            </td>
                            <td className="p-2.5 text-end whitespace-nowrap">
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => handleTierChange(u.id, 'free')}
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold border cursor-pointer ${
                                    u.tier === 'free' ? 'bg-[#102A35] text-white' : 'bg-white hover:bg-gray-100 text-[#607D89]'
                                  }`}
                                >
                                  Free
                                </button>
                                <button
                                  onClick={() => handleTierChange(u.id, 'plus')}
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold border cursor-pointer ${
                                    u.tier === 'plus' ? 'bg-[#16A6A0] text-white' : 'bg-white hover:bg-gray-100 text-[#16A6A0]'
                                  }`}
                                >
                                  Plus
                                </button>
                                <button
                                  onClick={() => handleTierChange(u.id, 'pro')}
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold border cursor-pointer ${
                                    u.tier === 'pro' ? 'bg-[#102A35] text-white' : 'bg-white hover:bg-gray-100 text-[#102A35]'
                                  }`}
                                >
                                  Pro
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 4: AUDIT LOGS */}
              {activeTab === 'audit' && (
                <div className="space-y-3">
                  {auditLogs.length === 0 ? (
                    <p className="py-12 text-center text-xs text-[#607D89]">Aucun événement d'audit enregistré.</p>
                  ) : (
                    <div className="border border-[#DCE7E3] rounded-xl overflow-x-auto">
                      <table className="w-full text-start text-xs border-collapse">
                        <thead>
                          <tr className="bg-[#F8FAF9] border-b border-[#DCE7E3] text-[#607D89]">
                            <th className="p-2.5 text-start font-bold">Date</th>
                            <th className="p-2.5 text-start font-bold">Administrateur</th>
                            <th className="p-2.5 text-start font-bold">Action</th>
                            <th className="p-2.5 text-start font-bold">Cible</th>
                            <th className="p-2.5 text-start font-bold">Détails</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#EDF2F0]">
                          {auditLogs.map((a) => (
                            <tr key={a.id} className="hover:bg-[#F8FAF9]/60">
                              <td className="p-2.5 text-[11px] text-[#607D89] whitespace-nowrap">
                                {a.createdAt ? a.createdAt.replace('T', ' ').slice(0, 19) : '-'}
                              </td>
                              <td className="p-2.5 text-[11px] text-[#102A35] font-semibold whitespace-nowrap">
                                {a.adminEmail}
                              </td>
                              <td className="p-2.5 whitespace-nowrap">
                                <span className="px-2 py-0.5 rounded bg-[#EDF2F0] font-mono text-[10px] text-[#102A35] font-bold">
                                  {a.action}
                                </span>
                              </td>
                              <td className="p-2.5 font-mono text-[10px] text-[#607D89] whitespace-nowrap">
                                {a.targetType}: {a.targetId}
                              </td>
                              <td className="p-2.5 text-[11px] text-[#607D89] max-w-xs truncate">
                                {JSON.stringify(a.details || {})}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Close */}
        <div className="pt-3 border-t border-[#EDF2F0] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#F4F7F5] hover:bg-[#EDF2F0] text-[#102A35] rounded-xl text-xs font-bold cursor-pointer"
          >
            {t('close')}
          </button>
        </div>

        {/* Receipt Preview Sub-Modal */}
        {previewReceiptId && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/70 p-4">
            <div className="bg-white rounded-2xl max-w-2xl w-full p-5 space-y-3">
              <div className="flex items-center justify-between border-b border-[#EDF2F0] pb-2">
                <h4 className="font-extrabold text-sm text-[#102A35]">Visualisation sécurisée du justificatif</h4>
                <button onClick={() => setPreviewReceiptId(null)} className="text-[#607D89] hover:text-[#102A35]">✕</button>
              </div>
              <div className="h-96 w-full rounded-xl border border-[#DCE7E3] overflow-hidden flex items-center justify-center bg-[#F8FAF9]">
                <iframe
                  src={`${API_BASE_URL}/api/admin/payments/${previewReceiptId}/receipt`}
                  className="w-full h-full border-0"
                  title="Justificatif de paiement"
                />
              </div>
              <div className="flex justify-between items-center pt-2">
                <a
                  href={`${API_BASE_URL}/api/admin/payments/${previewReceiptId}/receipt`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-bold text-[#16A6A0] hover:underline"
                >
                  Ouvrir dans un nouvel onglet
                </a>
                <button
                  onClick={() => setPreviewReceiptId(null)}
                  className="px-4 py-1.5 bg-[#102A35] text-white rounded-lg text-xs font-bold"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Reject Dialog */}
        {rejectDialog && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/70 p-4">
            <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-3">
              <h4 className="font-extrabold text-sm text-[#991B1B]">Rejeter l'ordre de paiement</h4>
              <p className="text-xs text-[#607D89]">
                Veuillez indiquer le motif du rejet (reçu illisible, virement non reçu sur le compte bancaire, montant erroné).
              </p>
              <textarea
                rows={3}
                value={rejectDialog.notes}
                onChange={(e) => setRejectDialog({ ...rejectDialog, notes: e.target.value })}
                placeholder="Ex: Virement non constaté sur le relevé BIAT / Référence manquante."
                className="w-full p-2 bg-[#F4F7F5] border border-[#DCE7E3] rounded-lg text-xs"
              />
              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setRejectDialog(null)}
                  className="px-3 py-1.5 bg-[#EDF2F0] text-[#102A35] rounded-lg text-xs font-bold"
                >
                  Annuler
                </button>
                <button
                  onClick={handleRejectConfirm}
                  disabled={actionLoading}
                  className="px-4 py-1.5 bg-[#EF4444] text-white rounded-lg text-xs font-bold"
                >
                  Confirmer le rejet
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <SiyantekProvider>
      <SiyantekDashboard />
    </SiyantekProvider>
  );
}
