import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

// Native Android builds must point to the deployed Siyantek API server.
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const apiUrl = (path: string) => `${API_BASE_URL}${path}`;


export type Language = 'fr' | 'ar' | 'en';
export type Currency = 'TND' | 'EUR' | 'USD';
export type MaintenanceType = 'oil' | 'brakes' | 'tires' | 'inspection' | 'battery' | 'other';
export type MaintenanceStatus = 'completed' | 'in_progress' | 'scheduled';
export type MaintenanceSeverity = 'routine' | 'minor' | 'major' | 'critical';
export type SubscriptionTier = 'free' | 'plus' | 'pro';

export interface SparePart {
  name: string;
  reference?: string;
  quantity: number;
  unitCost: number;
}

export interface Vehicle {
  id: string;
  brand: string;
  model: string;
  year: string;
  plate: string;
  mileage: number;
  motorization?: string;
  fuelType?: 'diesel' | 'essence' | 'hybride' | 'electrique' | string;
}

export interface MaintenanceRecord {
  id: string;
  vehicleId?: string;
  type: MaintenanceType;
  date: string;
  mileage: number;
  cost: number;
  notes: string;
  nextMileage?: number;
  workshop?: string;
  status?: MaintenanceStatus;
  severity?: MaintenanceSeverity;
  parts?: SparePart[];
}

export interface Reminder {
  id: string;
  vehicleId: string;
  title: string;
  type: 'oil' | 'insurance' | 'inspection' | 'vignette' | 'brakes' | 'belt' | 'custom';
  dueDate?: string;
  dueMileage?: number;
  notes?: string;
  completed: boolean;
  completedDate?: string;
  createdAt?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  tier: SubscriptionTier;
  subscriptionStatus: 'active' | 'canceled' | 'none' | 'expired';
  renewalDate: string;
  subscriptionExpiresAt?: string | null;
}

export interface TierLimits {
  maxVehicles: number;
  advancedReports: boolean;
  priceTND: number;
}

export interface ManualPaymentOrder {
  id: string;
  userId: string;
  planId: 'plus' | 'pro';
  amountDT: number;
  currency: 'TND';
  provider: string;
  method?: string;
  status: 'pending' | 'submitted' | 'completed' | 'approved' | 'rejected' | 'expired' | 'failed' | 'canceled';
  transferReference?: string;
  bankInstructions?: {
    accountName: string;
    bankName: string;
    rib: string;
    iban?: string;
    postalRip?: string;
    d17Phone?: string;
  };
  receiptFilename?: string;
  receiptMimeType?: string;
  receiptFileSize?: number;
  receiptUploadedAt?: string;
  adminNotes?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
  completedAt?: string;
}

export interface SiyantekContextValue {
  language: Language;
  isRTL: boolean;
  setLanguage: (lang: Language) => void;
  currency: Currency;
  setCurrency: (curr: Currency) => void;
  formatMoney: (amount: number) => string;
  t: (key: string) => string;

  // Auth & Cloud User
  user: UserProfile | null;
  token: string | null;
  isLoggedIn: boolean;
  isAdmin: boolean;
  tierLimits: TierLimits;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  deleteAccount: () => Promise<void>;
  exportData: () => Promise<any>;
  exportDataAsCSV: () => void;

  // Vehicles
  vehicles: Vehicle[];
  activeVehicle: Vehicle | null;
  activeVehicleId: string;
  setActiveVehicleId: (id: string) => void;
  addVehicle: (v: Omit<Vehicle, 'id'>) => Promise<{ success: boolean; error?: string }>;
  updateVehicle: (v: Vehicle) => Promise<{ success: boolean; error?: string }>;
  deleteVehicle: (id: string) => Promise<void>;

  // Maintenance Records & Parts
  records: MaintenanceRecord[];
  addRecord: (rec: Omit<MaintenanceRecord, 'id'>) => Promise<void>;
  updateRecord: (rec: MaintenanceRecord) => Promise<{ success: boolean; error?: string }>;
  deleteRecord: (id: string) => Promise<void>;

  // Reminders & Scheduling
  reminders: Reminder[];
  addReminder: (rem: Omit<Reminder, 'id'>) => Promise<{ success: boolean; error?: string }>;
  toggleReminder: (id: string) => Promise<void>;
  deleteReminder: (id: string) => Promise<void>;

  // Subscription & Manual Payments
  upgradeSubscription: (tier: SubscriptionTier) => Promise<{ success: boolean; error?: string; message?: string }>;
  cancelSubscription: () => Promise<void>;
  resetAllData: () => Promise<void>;
  myPayments: ManualPaymentOrder[];
  fetchMyPayments: () => Promise<void>;
  createManualOrder: (planId: 'plus' | 'pro', method?: string) => Promise<{ success: boolean; order?: ManualPaymentOrder; error?: string; instructions?: any }>;
  uploadReceipt: (orderId: string, base64Data: string, mimeType: string, filename?: string) => Promise<{ success: boolean; message?: string; error?: string; order?: ManualPaymentOrder }>;

  // Admin APIs
  fetchAdminStats: () => Promise<any>;
  fetchAdminUsers: () => Promise<any[]>;
  fetchAdminPayments: () => Promise<any[]>;
  approvePayment: (id: string, notes?: string, durationDays?: number) => Promise<{ success: boolean; error?: string; message?: string }>;
  rejectPayment: (id: string, reason?: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  updateUserTier: (userId: string, tier: SubscriptionTier, durationDays?: number, notes?: string) => Promise<{ success: boolean; error?: string }>;
  fetchAuditLogs: () => Promise<any[]>;
}

const STORAGE_KEY = '@siyantek/commercial-v2';
const TOKEN_KEY = '@siyantek/token';
const LANG_STORAGE_KEY = '@siyantek/language';

const DEFAULT_TIER_LIMITS: Record<SubscriptionTier, TierLimits> = {
  // Siyantek is free: all tiers (including legacy accounts) receive full access.
  free: { maxVehicles: Number.MAX_SAFE_INTEGER, advancedReports: true, priceTND: 0 },
  plus: { maxVehicles: Number.MAX_SAFE_INTEGER, advancedReports: true, priceTND: 0 },
  pro: { maxVehicles: Number.MAX_SAFE_INTEGER, advancedReports: true, priceTND: 0 },
};

const initialVehicles: Vehicle[] = [];
const initialRecords: MaintenanceRecord[] = [];
const initialReminders: Reminder[] = [];

const translations: Record<Language, Record<string, string>> = {
  fr: {
    appName: 'Siyantek',
    tagline: 'Votre voiture, votre entretien, tout simplement.',
    commercialBadge: 'Pour Particuliers',
    overview: 'Aperçu',
    overviewWelcome: 'Bonjour,',
    overviewSubtitle: 'Voici un aperçu de votre véhicule',
    nextRevision: 'Prochaine révision',
    serviceUpcomingAlert: 'Entretien à prévoir bientôt',
    history: 'Historique',
    vehicles: 'Mes Véhicules',
    reminders: 'Rappels',
    expenses: 'Mes Dépenses',
    expensesSubtitle: 'Suivez et maîtrisez le budget de votre voiture : vidanges, pièces et réparations.',
    expensesTotal: 'Dépenses totales',
    expensesYear: 'Dépenses cette année',
    expensesMonth: 'Dépenses ce mois-ci',
    monthlyAverage: 'Moyenne mensuelle',
    addExpense: 'Ajouter une dépense',
    expensesByCategory: 'Répartition par catégorie',
    monthlyExpensesChart: 'Évolution des dépenses mensuelles',
    resaleTipTitle: 'Valorisez votre véhicule à la revente',
    resaleTipBody: 'Les automobilistes qui conservent l’historique chiffré de leurs entretiens revendent leur véhicule jusqu’à 20% plus cher.',
    allCars: 'Toutes mes voitures',
    invoices: 'Factures',
    reports: 'Rapports',
    pricing: 'Abonnements',
    settings: 'Paramètres',
    account: 'Compte',
    goodMorning: 'Bonjour',
    goodAfternoon: 'Bon après-midi',
    goodEvening: 'Bonsoir',
    yourCar: 'Votre véhicule actif',
    selectVehicle: 'Choisir ce véhicule',
    allVehicles: 'Tous les véhicules',
    addVehicle: 'Ajouter un véhicule',
    vehicleLimitReached: 'Limite de véhicules atteinte pour votre formule.',
    currentMileage: 'Kilométrage actuel',
    updateMileage: 'Mettre à jour',
    kilometers: 'km',
    lastService: 'Dernier entretien',
    ago: 'il y a',
    nextService: 'Prochain entretien',
    dueIn: 'Dans',
    allCaughtUp: 'À jour',
    addMaintenance: 'Ajouter un entretien',
    recentActivity: 'Activité récente',
    noRecords: 'Aucun entretien enregistré.',
    noRecordsHint: 'Ajoutez votre première intervention pour tenir un carnet rigoureux et préserver la valeur de votre véhicule.',
    maintenanceHistory: 'Carnet d\'entretien complet',
    recordCount: 'interventions enregistrées',
    totalSpent: 'Dépenses totales',
    vehicleHealth: 'Santé mécanique',
    onTrack: 'En ordre',
    service: 'Intervention',
    date: 'Date',
    mileage: 'Kilométrage',
    cost: 'Montant',
    notes: 'Notes & observations',
    workshop: 'Atelier / Garage',
    nextMileage: 'Prochain kilométrage prévu',
    saveMaintenance: 'Enregistrer l\'intervention',
    cancel: 'Annuler',
    addServiceTitle: 'Enregistrer un entretien ou réparation',
    serviceType: 'Catégorie d\'intervention',
    oil: 'Vidange & filtres',
    brakes: 'Freins & plaquettes',
    tires: 'Pneumatiques',
    inspection: 'Visite & contrôle',
    battery: 'Batterie & électricité',
    other: 'Autre intervention',
    statusCompleted: 'Terminé',
    statusInProgress: 'En cours',
    statusScheduled: 'Planifié',
    severityRoutine: 'Entretien courant',
    severityMinor: 'Panne mineure',
    severityMajor: 'Réparation majeure',
    severityCritical: 'Panne critique',
    spareParts: 'Pièces de rechange',
    addPart: 'Ajouter une pièce',
    partName: 'Nom de la pièce',
    partRef: 'Référence / OEM',
    partQty: 'Qté',
    partCost: 'Prix unitaire',
    searchPlaceholder: 'Rechercher entretien, garage, pièces...',
    filterCategory: 'Toutes catégories',
    filterStatus: 'Tous statuts',
    filterDate: 'Toutes dates',
    dateLast30: '30 derniers jours',
    dateLast90: '3 derniers mois',
    dateThisYear: 'Cette année',
    clearFilters: 'Réinitialiser les filtres',
    enterMileage: 'Kilométrage (km)',
    enterCost: 'Montant',
    addNotes: 'Précisions, pièces ou réparations (facultatif)',
    enterNextMileage: 'Prochain kilométrage prévu (km)',
    requiredMileage: 'Veuillez renseigner un kilométrage valide.',
    invalidMileage: 'Le kilométrage doit être un nombre strictement positif.',
    mileageDecreasingWarning: 'Le nouveau kilométrage ne peut pas être inférieur au kilométrage actuel du véhicule.',
    invalidNextMileage: 'Le prochain entretien doit être supérieur au kilométrage actuel.',
    language: 'Langue',
    currency: 'Devise',
    offline: 'Données locales synchronisées',
    today: 'Aujourd’hui',
    editVehicle: 'Modifier le véhicule',
    vehicleDetails: 'Fiche du véhicule',
    deleteVehicle: 'Supprimer ce véhicule',
    confirmDeleteVehicle: 'Voulez-vous vraiment supprimer ce véhicule et toutes ses interventions ?',
    saveChanges: 'Enregistrer les modifications',
    brand: 'Marque',
    model: 'Modèle',
    year: 'Année',
    plate: 'Immatriculation',
    close: 'Fermer',
    privacy: 'Politique de confidentialité',
    privacyTitle: 'Confidentialité & Données',
    privacyBody: 'Siyantek protège rigoureusement vos données automobiles. Vos informations restent votre propriété exclusive et peuvent être exportées ou supprimées en un clic.',
    termsTitle: 'Conditions Générales d\'Utilisation',
    contactSupport: 'Support & Contact',
    whatsappSupport: 'Support WhatsApp direct',
    sendSupportMessage: 'Envoyer un message au support',
    supportSubject: 'Sujet',
    supportMessage: 'Votre message',
    supportSent: 'Votre message a été transmis avec succès. Notre équipe vous répondra rapidement.',
    clearData: 'Réinitialiser les données',
    clearDataConfirm: 'Cette action effacera vos véhicules et données locales sur cet appareil. Continuer ?',
    clearDataDone: 'Vos données locales ont été réinitialisées.',
    appVersion: 'Siyantek 2.4 Web Commercial',
    login: 'Se connecter',
    register: 'Créer un compte',
    logout: 'Déconnexion',
    email: 'Adresse email',
    password: 'Mot de passe',
    fullName: 'Nom complet',
    noAccount: 'Pas encore de compte ?',
    alreadyAccount: 'Déjà un compte ?',
    forgotPassword: 'Mot de passe oublié ?',
    guestMode: 'Mode invité / Déconnecté',
    freePlan: 'Forfait Gratuit',
    plusPlan: 'Siyantek Plus',
    proPlan: 'Siyantek Pro',
    upgradePlan: 'Changer de formule',
    downloadPdf: 'Générer le rapport PDF',
    exportPdfSummary: 'Télécharger le carnet d\'entretien officiel et la liste des pièces au format PDF.',
    exportCSV: 'Exporter en CSV (Excel)',
    addReminder: 'Nouveau rappel',
    reminderTitle: 'Intitulé du rappel',
    reminderType: 'Catégorie de rappel',
    typeOil: 'Vidange moteur',
    typeInsurance: 'Assurance automobile',
    typeInspection: 'Visite technique',
    typeVignette: 'Taxe de circulation (Vignette)',
    typeBrakes: 'Contrôle freinage',
    typeBelt: 'Courroie de distribution',
    typeCustom: 'Rappel personnalisé',
    dueDate: 'Date limite',
    dueMileage: 'Kilométrage cible (km)',
    markDone: 'Marquer comme fait',
    reopen: 'Rouvrir',
    overdue: 'En retard / Échu',
    upcoming: 'Échéance proche',
    valid: 'À jour',
    noReminders: 'Aucun rappel actif. Planifiez vos vidanges, assurance et visite technique !',
    viewAll: 'Voir tout',
    editRecord: 'Modifier l\'intervention',
    deleteRecord: 'Supprimer l\'intervention',
    confirmDeleteRecord: 'Voulez-vous supprimer cette intervention de l\'historique ?',
    filterByVehicle: 'Filtrer par véhicule',
    recordsMatching: 'interventions correspondantes',
    downloadingPDF: 'Génération du PDF...',
    motorization: 'Motorisation',
    fuel: 'Carburant',
    diesel: 'Diesel',
    petrol: 'Essence',
    hybrid: 'Hybride',
    electric: 'Électrique',
    target: 'Objectif',
    targetMaintenance: 'Objectif de maintenance',
    overdueBy: 'Échéance dépassée de',
    dueInDistance: 'Dans',
    serviceNeededNow: 'Entretien requis immédiatement',
    serviceUpcoming: 'Échéance proche',
    serviceOnTrack: 'Entretien à jour',
    noMaintenanceScheduled: 'Aucune échéance programmée',
    planMaintenance: 'Planifier un entretien',
    mileageUpdatedSuccess: 'Kilométrage mis à jour avec succès',
    updatingMileage: 'Mise à jour en cours...',
    viewHistoryDetails: 'Consulter le carnet',
    viewReminders: 'Gérer les rappels',
    scoreExcellent: 'Excellent état',
    scoreGood: 'Bon état',
    scoreWarning: 'Attention requise',
    noExpensesRecorded: 'Aucune dépense enregistrée',
    allLightsGreen: 'Tous les voyants sont au vert',
    deadlinesOverdue: 'échéance(s) en retard',
    plateNumber: 'Immatriculation',
    yearOfManufacture: 'Année',
    manualPaymentTitle: 'Paiement sécurisé par virement bancaire ou postal',
    manualPaymentSubtitle: 'Activez votre formule en Tunisie par virement bancaire BIAT, mandat postal ou D17.',
    bankTransfer: 'Virement bancaire (RIB BIAT)',
    postalTransfer: 'Mandat postal / D17',
    paymentReference: 'Référence de paiement unique',
    bankBeneficiary: 'Bénéficiaire',
    bankNameLabel: 'Banque',
    ribLabel: 'RIB (Relevé d\'Identité Bancaire)',
    postalRipLabel: 'RIP Postal',
    d17PhoneLabel: 'Numéro D17 / Mandat',
    uploadReceiptTitle: 'Téléverser le justificatif de paiement',
    uploadReceiptDesc: 'Prenez en photo le reçu de versement ou joignez le PDF du virement bancaire (max 5 Mo).',
    receiptFileSelect: 'Choisir le reçu (JPG, PNG, PDF)',
    submitReceiptBtn: 'Soumettre pour validation',
    orderStatusPending: 'En attente de paiement',
    orderStatusSubmitted: 'Reçu envoyé (En cours de vérification)',
    orderStatusApproved: 'Validé & Activé',
    orderStatusRejected: 'Rejeté',
    adminDashboard: 'Administration Siyantek',
    adminBadge: 'Admin Back-Office',
    adminUsersTab: 'Utilisateurs',
    adminPaymentsTab: 'Paiements & Reçus',
    adminAuditTab: 'Journal d\'audit',
    adminStatsTab: 'Statistiques',
    approvePaymentBtn: 'Valider le paiement',
    rejectPaymentBtn: 'Rejeter',
    viewReceiptBtn: 'Voir le justificatif',
    noPaymentsFound: 'Aucune commande de paiement enregistrée.',
    activeUntil: 'Actif jusqu\'au',
    subscriptionExpired: 'Abonnement expiré',
    renewSubscription: 'Renouveler mon abonnement',
  },
  ar: {
    appName: 'صيانتك',
    tagline: 'دفتر صيانة سيارتك في جيبك',
    commercialBadge: 'للسيارات الخاصة',
    overview: 'الرئيسية',
    overviewWelcome: 'مرحباً،',
    overviewSubtitle: 'إليك نظرة عامة على سيارتك',
    nextRevision: 'الصيانة القادمة',
    serviceUpcomingAlert: 'صيانة مقبلة قريباً',
    history: 'سجل الصيانة',
    vehicles: 'سياراتي',
    reminders: 'التذكيرات',
    expenses: 'مصاريفي',
    expensesSubtitle: 'تتبع وتحكم في ميزانية ومصاريف سيارتك بكل دقة: زيوت، قطع غيار، فحص، وتصليحات.',
    expensesTotal: 'إجمالي المصاريف',
    expensesYear: 'مصاريف العام الحالي',
    expensesMonth: 'مصاريف هذا الشهر',
    monthlyAverage: 'المعدل الشهري',
    addExpense: 'تسجيل مصروف جديد',
    expensesByCategory: 'توزيع المصاريف حسب الصنف',
    monthlyExpensesChart: 'تطور المصاريف الشهرية',
    resaleTipTitle: 'حافظ على قيمة سيارتك عند إعادة البيع',
    resaleTipBody: 'الاحتفاظ بسجل كامل وموثق لجميع مصاريف وصيانة السيارة يمنح المشتري ثقة تامة ويرفع سعر سيارتك عند إعادة البيع.',
    allCars: 'جميع سياراتي',
    invoices: 'الفواتير',
    reports: 'التقارير',
    pricing: 'الاشتراكات',
    settings: 'الإعدادات',
    account: 'الحساب',
    goodMorning: 'صباح الخير',
    goodAfternoon: 'مساء الخير',
    goodEvening: 'مساء الخير',
    yourCar: 'السيارة النشطة',
    selectVehicle: 'تحديد هذه السيارة',
    allVehicles: 'جميع السيارات',
    addVehicle: 'إضافة سيارة جديدة',
    vehicleLimitReached: 'بلغت الحد الأقصى للسيارات المسموح به في باقتك.',
    currentMileage: 'المسافة الحالية بالعداد',
    updateMileage: 'تحديث العداد',
    kilometers: 'كم',
    lastService: 'آخر صيانة',
    ago: 'منذ',
    nextService: 'الصيانة القادمة',
    dueIn: 'بعد',
    allCaughtUp: 'ساري ومحدث',
    addMaintenance: 'تسجيل عملية صيانة',
    recentActivity: 'النشاط الأخير',
    noRecords: 'لم يتم تسجيل أي صيانة بعد.',
    noRecordsHint: 'أضف أول صيانة للحفاظ على سيارتك في أفضل أداء وحفظ قيمتها السوقية.',
    maintenanceHistory: 'سجل الصيانة والمصاريف الكامل',
    recordCount: 'عمليات صيانة مسجلة',
    totalSpent: 'إجمالي المصاريف',
    vehicleHealth: 'الحالة الميكانيكية',
    onTrack: 'في الموعد',
    service: 'الصيانة',
    date: 'التاريخ',
    mileage: 'المسافة (كم)',
    cost: 'المبلغ',
    notes: 'ملاحظات وتفاصيل',
    workshop: 'الورشة أو مركز الصيانة',
    nextMileage: 'الصيانة القادمة عند (كم)',
    saveMaintenance: 'حفظ عملية الصيانة',
    cancel: 'إلغاء',
    addServiceTitle: 'تسجيل عملية صيانة أو إصلاح عطل',
    serviceType: 'نوع الصيانة أو العطل',
    oil: 'تغيير الزيت والفلاتر',
    brakes: 'الفرامل والأقمشة',
    tires: 'الإطارات وضغط الهواء',
    inspection: 'الفحص الدوري والميكانيك',
    battery: 'البطارية والكهرباء',
    other: 'صيانة أخرى',
    statusCompleted: 'مكتملة',
    statusInProgress: 'قيد الإنجاز',
    statusScheduled: 'مجدولة',
    severityRoutine: 'صيانة دورية عادية',
    severityMinor: 'عطل بسيط',
    severityMajor: 'إصلاح رئيسي',
    severityCritical: 'عطل جسيم / توقف',
    spareParts: 'قطع الغيار المستبدلة',
    addPart: 'إضافة قطعة غيار',
    partName: 'اسم القطعة',
    partRef: 'رقم القطعة / المرجع OEM',
    partQty: 'الكمية',
    partCost: 'سعر الوحدة',
    searchPlaceholder: 'بحث في الصيانة، الورشة، قطع الغيار...',
    filterCategory: 'جميع الأصناف',
    filterStatus: 'جميع الحالات',
    filterDate: 'كل الفترات',
    dateLast30: 'آخر 30 يوماً',
    dateLast90: 'آخر 3 أشهر',
    dateThisYear: 'هذا العام',
    clearFilters: 'إعادة ضبط التصفية',
    enterMileage: 'المسافة الحالية (كم)',
    enterCost: 'المبلغ الإجمالي',
    addNotes: 'ملاحظات وتفاصيل العمل المنجز (اختياري)',
    enterNextMileage: 'مسافة الصيانة القادمة (اختياري)',
    requiredMileage: 'يرجى إدخال مسافة صحيحة بالعداد.',
    invalidMileage: 'يجب أن تكون المسافة رقماً موجباً أكبر من الصفر.',
    mileageDecreasingWarning: 'لا يمكن أن تكون المسافة الجديدة أقل من المسافة المسجلة حالياً للسيارة.',
    invalidNextMileage: 'يجب أن تكون مسافة الصيانة القادمة أكبر من المسافة الحالية.',
    language: 'اللغة',
    currency: 'العملة',
    offline: 'محفوظ ومُزامن سحابياً',
    today: 'اليوم',
    editVehicle: 'تعديل بيانات السيارة',
    vehicleDetails: 'بطاقة السيارة',
    deleteVehicle: 'حذف السيارة',
    confirmDeleteVehicle: 'هل أنت متأكد من رغبتك في حذف هذه السيارة وسجل صيانتها بالكامل؟',
    saveChanges: 'حفظ التغييرات',
    brand: 'العلامة التجارية (الماركة)',
    model: 'الطراز (الموديل)',
    year: 'سنة الصنع',
    plate: 'رقم اللوحة (مثال: 215 تونس 4820)',
    close: 'إغلاق',
    privacy: 'سياسة الخصوصية',
    privacyTitle: 'الخصوصية وحماية البيانات',
    privacyBody: 'يلتزم تطبيق صيانتك بحماية بياناتك وسجلاتك. بياناتك ملكك وحدك ويمكنك تصديرها أو حذف حسابك نهائياً بضغطة زر.',
    termsTitle: 'الشروط والأحكام العامة',
    contactSupport: 'الدعم والمساعدة الفنية',
    whatsappSupport: 'الدعم المباشر عبر واتساب',
    sendSupportMessage: 'إرسال رسالة إلى فريق الدعم',
    supportSubject: 'موضوع الرسالة',
    supportMessage: 'نص الرسالة أو الاستفسار',
    supportSent: 'تم إرسال رسالتك بنجاح، سيتواصل معك فريق الدعم قريباً.',
    clearData: 'حذف البيانات المحلية',
    clearDataConfirm: 'سيؤدي هذا إلى مسح السيارات وسجل الصيانة من هذا الجهاز. هل تريد المتابعة؟',
    clearDataDone: 'تم مسح البيانات المحلية بنجاح.',
    appVersion: 'صيانتك 2.4 - النسخة التجارية للويب',
    login: 'تسجيل الدخول',
    register: 'إنشاء حساب جديد',
    logout: 'تسجيل الخروج',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    fullName: 'الاسم الكامل',
    noAccount: 'ليس لديك حساب بعد؟',
    alreadyAccount: 'لديك حساب بالفعل؟',
    forgotPassword: 'نسيت كلمة المرور؟',
    guestMode: 'الوضع التجريبي / دون اتصال',
    freePlan: 'الباقة المجانية (Free)',
    plusPlan: 'باقة صيانتك بلس',
    proPlan: 'باقة صيانتك برو',
    upgradePlan: 'ترقية الباقة',
    downloadPdf: 'تحميل تقرير PDF',
    exportPdfSummary: 'استخراج تقرير رسمي شامل لسجل صيانة السيارة ومصاريفها وقطع الغيار لتقديمه للمشتري أو للمتابعة الفنية.',
    exportCSV: 'تصدير بصيغة CSV (ملف إكسل)',
    addReminder: 'إضافة تذكير جديد',
    reminderTitle: 'عنوان التذكير',
    reminderType: 'نوع التذكير',
    typeOil: 'تغيير زيت المحرك',
    typeInsurance: 'تأمين السيارة',
    typeInspection: 'الفحص الفني الدوري',
    typeVignette: 'المعلوم الجبائي (معلوم الجولان)',
    typeBrakes: 'فحص الفرامل',
    typeBelt: 'حزام التوقيت (الكروا)',
    typeCustom: 'تذكير مخصص',
    dueDate: 'تاريخ الاستحقاق',
    dueMileage: 'المسافة المستهدفة (كم)',
    markDone: 'تحديد كمكتمل',
    reopen: 'إعادة فتح',
    overdue: 'مستحق / متأخر',
    upcoming: 'يقترب الموعد',
    valid: 'ساري',
    noReminders: 'لا توجد تذكيرات حالية. أضف تذكيرات لمواعيد تغيير الزيت والتأمين والفحص الفني!',
    viewAll: 'عرض الكل',
    editRecord: 'تعديل السجل',
    deleteRecord: 'حذف السجل',
    confirmDeleteRecord: 'هل تريد حذف هذه العملية من سجل الصيانة؟',
    filterByVehicle: 'تصفية حسب السيارة',
    recordsMatching: 'عمليات مطابقة',
    downloadingPDF: 'جاري إعداد تقرير PDF...',
    motorization: 'المحرك',
    fuel: 'الوقود',
    diesel: 'ديزل',
    petrol: 'بنزين',
    hybrid: 'هجين',
    electric: 'كهربائي',
    target: 'الهدف',
    targetMaintenance: 'المسافة المستهدفة للصيانة',
    overdueBy: 'متأخر بـ',
    dueInDistance: 'بعد',
    serviceNeededNow: 'صيانة مطلوبة فوراً',
    serviceUpcoming: 'اقتراب موعد الصيانة',
    serviceOnTrack: 'الصيانة في موعدها',
    noMaintenanceScheduled: 'لا توجد صيانة مجدولة',
    planMaintenance: 'جدولة صيانة جديدة',
    mileageUpdatedSuccess: 'تم تحديث العداد بنجاح',
    updatingMileage: 'جاري تحديث العداد...',
    viewHistoryDetails: 'عرض سجل الصيانة',
    viewReminders: 'عرض التنبيهات',
    scoreExcellent: 'حالة ممتازة',
    scoreGood: 'حالة جيدة',
    scoreWarning: 'تتطلب الانتباه',
    noExpensesRecorded: 'لا توجد مصاريف مسجلة بعد',
    allLightsGreen: 'كافة المؤشرات في وضع سليم',
    deadlinesOverdue: 'تنبيه(ات) متأخرة',
    plateNumber: 'رقم اللوحة',
    yearOfManufacture: 'سنة الصنع',
    manualPaymentTitle: 'الدفع بالتحويل البنكي أو البريدي في تونس',
    manualPaymentSubtitle: 'قم بتفعيل اشتراكك بكل سهولة عبر تحويل بنكي (BIAT) أو حوالة بريدية أو D17.',
    bankTransfer: 'تحويل بنكي (BIAT)',
    postalTransfer: 'حوالة بريدية / D17',
    paymentReference: 'الرمز المرجعي الفريد للطلب',
    bankBeneficiary: 'المستفيد',
    bankNameLabel: 'البنك',
    ribLabel: 'رقم الحساب البنكي (RIB)',
    postalRipLabel: 'رقم الحساب البريدي (RIP)',
    d17PhoneLabel: 'رقم الهاتف لخدمة D17',
    uploadReceiptTitle: 'رفع وصل التحويل أو الإيداع',
    uploadReceiptDesc: 'التقط صورة واضحة لوصل الإيداع أو أرفق ملف PDF للتحويل البنكي (الحد الأقصى 5 ميغابايت).',
    receiptFileSelect: 'اختيار ملف الوصل (JPG, PNG, PDF)',
    submitReceiptBtn: 'إرسال الوصل للمراجعة والتفعيل',
    orderStatusPending: 'بانتظار إجراء التحويل',
    orderStatusSubmitted: 'تم رفع الوصل (قيد المراجعة)',
    orderStatusApproved: 'تم التحقق والتفعيل بنجاح',
    orderStatusRejected: 'مرفوض',
    adminDashboard: 'لوحة تحكم إدارة صيانتك',
    adminBadge: 'إدارة المنصة',
    adminUsersTab: 'المستخدمين',
    adminPaymentsTab: 'طلبات الدفع والوصولات',
    adminAuditTab: 'سجل العمليات الإدارية',
    adminStatsTab: 'الإحصائيات',
    approvePaymentBtn: 'تفعيل الاشتراك ومطابقة الوصل',
    rejectPaymentBtn: 'رفض الطلب',
    viewReceiptBtn: 'معاينة الوصل',
    noPaymentsFound: 'لا توجد طلبات دفع مسجلة.',
    activeUntil: 'سارٍ حتى',
    subscriptionExpired: 'انتهت صلاحية الاشتراك',
    renewSubscription: 'تجديد الاشتراك',
  },
  en: {
    appName: 'Siyantek',
    tagline: 'Care for every kilometre.',
    commercialBadge: 'Commercial Web Edition',
    overview: 'Overview',
    history: 'Log & History',
    vehicles: 'My Vehicles',
    reminders: 'Reminders & Schedule',
    invoices: 'Invoice Scan',
    reports: 'PDF Reports',
    pricing: 'Plans & Pricing',
    settings: 'Settings',
    account: 'Account',
    goodMorning: 'Good morning',
    goodAfternoon: 'Good afternoon',
    goodEvening: 'Good evening',
    yourCar: 'Active vehicle',
    selectVehicle: 'Select this vehicle',
    allVehicles: 'All vehicles',
    addVehicle: 'Add a vehicle',
    vehicleLimitReached: 'Vehicle limit reached for your plan.',
    currentMileage: 'Current odometer',
    updateMileage: 'Update',
    kilometers: 'km',
    lastService: 'Last service',
    ago: 'ago',
    nextService: 'Next service',
    dueIn: 'Due in',
    allCaughtUp: 'All caught up',
    addMaintenance: 'Log maintenance',
    recentActivity: 'Recent activity',
    noRecords: 'No maintenance recorded yet.',
    noRecordsHint: 'Log your first service to keep your vehicle in prime health.',
    maintenanceHistory: 'Full maintenance log',
    recordCount: 'services logged',
    totalSpent: 'Total expenses',
    vehicleHealth: 'Mechanical health',
    onTrack: 'On track',
    service: 'Service',
    date: 'Date',
    mileage: 'Mileage',
    cost: 'Cost',
    notes: 'Notes',
    workshop: 'Garage / Workshop',
    nextMileage: 'Next service mileage',
    saveMaintenance: 'Save record',
    cancel: 'Cancel',
    addServiceTitle: 'Log maintenance or repair',
    serviceType: 'Service category',
    oil: 'Oil & filter',
    brakes: 'Brakes',
    tires: 'Tires',
    inspection: 'Inspection',
    battery: 'Battery',
    other: 'Other intervention',
    statusCompleted: 'Completed',
    statusInProgress: 'In progress',
    statusScheduled: 'Scheduled',
    severityRoutine: 'Routine maintenance',
    severityMinor: 'Minor breakdown',
    severityMajor: 'Major repair',
    severityCritical: 'Critical failure',
    spareParts: 'Spare parts used',
    addPart: 'Add spare part',
    partName: 'Part name',
    partRef: 'Reference / OEM',
    partQty: 'Qty',
    partCost: 'Unit cost',
    searchPlaceholder: 'Search records, workshops, parts...',
    filterCategory: 'All categories',
    filterStatus: 'All statuses',
    filterDate: 'All dates',
    dateLast30: 'Last 30 days',
    dateLast90: 'Last 90 days',
    dateThisYear: 'This year',
    clearFilters: 'Reset filters',
    enterMileage: 'Odometer (km)',
    enterCost: 'Cost',
    addNotes: 'Notes & details (optional)',
    enterNextMileage: 'Next service at (km)',
    requiredMileage: 'Please enter a valid mileage.',
    invalidMileage: 'Mileage must be a positive number.',
    mileageDecreasingWarning: 'New mileage cannot be less than the vehicle\'s current mileage.',
    invalidNextMileage: 'Next service must be greater than current mileage.',
    language: 'Language',
    currency: 'Currency',
    offline: 'Saved locally & sync ready',
    today: 'Today',
    editVehicle: 'Edit vehicle',
    vehicleDetails: 'Vehicle details',
    deleteVehicle: 'Delete vehicle',
    confirmDeleteVehicle: 'Are you sure you want to delete this vehicle and all its history?',
    saveChanges: 'Save changes',
    brand: 'Make / Brand',
    model: 'Model',
    year: 'Year',
    plate: 'Registration plate',
    close: 'Close',
    privacy: 'Privacy policy',
    privacyTitle: 'Privacy & Data Protection',
    privacyBody: 'Siyantek keeps your vehicle records protected. Your data belongs strictly to you.',
    clearData: 'Clear all data',
    clearDataConfirm: 'This will remove stored vehicle data from this device. Continue?',
    clearDataDone: 'Your local data has been cleared.',
    appVersion: 'Siyantek 2.4 Web Commercial',
    login: 'Sign in',
    register: 'Create account',
    logout: 'Log out',
    email: 'Email address',
    password: 'Password',
    fullName: 'Full name',
    noAccount: 'Don\'t have an account?',
    alreadyAccount: 'Already have an account?',
    forgotPassword: 'Forgot password?',
    guestMode: 'Guest Mode (Offline)',
    freePlan: 'Free Plan',
    plusPlan: 'Siyantek Plus',
    proPlan: 'Siyantek Pro',
    upgradePlan: 'Upgrade plan',
    downloadPdf: 'Download PDF Report',
    exportPdfSummary: 'Export full vehicle service history and spare parts catalog as official PDF.',
    exportCSV: 'Export to CSV (Excel)',
    addReminder: 'Add reminder',
    reminderTitle: 'Reminder title',
    reminderType: 'Reminder type',
    typeOil: 'Oil change',
    typeInsurance: 'Car insurance',
    typeInspection: 'Technical inspection',
    typeVignette: 'Road tax (Vignette)',
    typeBrakes: 'Brakes check',
    typeBelt: 'Timing belt',
    typeCustom: 'Custom reminder',
    dueDate: 'Due date',
    dueMileage: 'Due mileage (km)',
    markDone: 'Mark as completed',
    reopen: 'Reopen',
    overdue: 'Overdue',
    upcoming: 'Due soon',
    valid: 'Valid',
    noReminders: 'No active reminders. Add one to stay ahead of upcoming checks!',
    viewAll: 'View all',
    editRecord: 'Edit record',
    deleteRecord: 'Delete record',
    confirmDeleteRecord: 'Do you want to delete this record?',
    filterByVehicle: 'Filter by vehicle',
    recordsMatching: 'matching records',
    downloadingPDF: 'Generating PDF...',
    motorization: 'Engine / Powertrain',
    fuel: 'Fuel',
    diesel: 'Diesel',
    petrol: 'Petrol / Gasoline',
    hybrid: 'Hybrid',
    electric: 'Electric',
    target: 'Target',
    targetMaintenance: 'Target maintenance mileage',
    overdueBy: 'Overdue by',
    dueInDistance: 'Due in',
    serviceNeededNow: 'Maintenance required now',
    serviceUpcoming: 'Due soon',
    serviceOnTrack: 'On track',
    noMaintenanceScheduled: 'No maintenance scheduled',
    planMaintenance: 'Schedule maintenance',
    mileageUpdatedSuccess: 'Odometer updated successfully',
    updatingMileage: 'Updating odometer...',
    viewHistoryDetails: 'View logbook',
    viewReminders: 'Manage reminders',
    scoreExcellent: 'Excellent condition',
    scoreGood: 'Good condition',
    scoreWarning: 'Attention required',
    noExpensesRecorded: 'No expenses recorded yet',
    allLightsGreen: 'All indicators green',
    deadlinesOverdue: 'overdue deadline(s)',
    plateNumber: 'Registration plate',
    yearOfManufacture: 'Year',
  },
};

const SiyantekContext = createContext<SiyantekContextValue | null>(null);

export function SiyantekProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(LANG_STORAGE_KEY);
      if (saved === 'ar' || saved === 'fr' || saved === 'en') return saved;
      const storedObj = localStorage.getItem(STORAGE_KEY);
      if (storedObj) {
        const parsed = JSON.parse(storedObj);
        if (parsed.language === 'ar' || parsed.language === 'fr' || parsed.language === 'en') {
          return parsed.language;
        }
      }
    } catch {}
    return 'fr';
  });

  const [currency, setCurrencyState] = useState<Currency>('TND');
  const [vehicles, setVehicles] = useState<Vehicle[]>(initialVehicles);
  const [activeVehicleId, setActiveVehicleId] = useState<string>('veh_default_1');
  const [records, setRecords] = useState<MaintenanceRecord[]>(initialRecords);
  const [reminders, setReminders] = useState<Reminder[]>(initialReminders);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [myPayments, setMyPayments] = useState<ManualPaymentOrder[]>([]);

  // Synchronize HTML attributes (dir & lang) when language updates
  useEffect(() => {
    const isArabic = language === 'ar';
    document.documentElement.setAttribute('dir', isArabic ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', language);
    try {
      localStorage.setItem(LANG_STORAGE_KEY, language);
    } catch {}
  }, [language]);

  // Load local state & check session
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.currency) setCurrencyState(parsed.currency);
        if (Array.isArray(parsed.vehicles) && parsed.vehicles.length > 0) {
          setVehicles(parsed.vehicles);
          setActiveVehicleId(parsed.vehicles[0].id);
        }
        if (Array.isArray(parsed.records)) setRecords(parsed.records);
        if (Array.isArray(parsed.reminders)) setReminders(parsed.reminders);
      }

      const savedToken = localStorage.getItem(TOKEN_KEY);
      if (savedToken) {
        setToken(savedToken);
        fetch(apiUrl('/api/auth/me'), {
          headers: { Authorization: `Bearer ${savedToken}` },
          credentials: 'include',
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((data) => {
            if (data && data.user) {
              setUser(data.user);
              syncFromCloud(savedToken);
            } else {
              localStorage.removeItem(TOKEN_KEY);
              setToken(null);
            }
          })
          .catch(() => {});
      }
    } catch {}
  }, []);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ language, currency, vehicles, records, reminders })
      );
    } catch {}
  }, [language, currency, vehicles, records, reminders]);

  const syncFromCloud = async (authToken: string) => {
    try {
      const [vRes, mRes, rRes] = await Promise.all([
        fetch(apiUrl('/api/vehicles'), { headers: { Authorization: `Bearer ${authToken}` }, credentials: 'include' }),
        fetch(apiUrl('/api/maintenance'), { headers: { Authorization: `Bearer ${authToken}` }, credentials: 'include' }),
        fetch(apiUrl('/api/reminders'), { headers: { Authorization: `Bearer ${authToken}` }, credentials: 'include' }),
      ]);
      if (vRes.ok) {
        const vData = await vRes.json();
        if (Array.isArray(vData)) {
          setVehicles(vData);
          if (vData.length > 0) {
            setActiveVehicleId((curr) => vData.find((v: Vehicle) => v.id === curr)?.id || vData[0].id);
          } else {
            setActiveVehicleId('');
          }
        }
      }
      if (mRes.ok) {
        const mData = await mRes.json();
        if (Array.isArray(mData)) {
          setRecords(mData);
        }
      }
      if (rRes.ok) {
        const rData = await rRes.json();
        if (Array.isArray(rData)) {
          setReminders(rData);
        }
      }
    } catch (e) {
      console.warn('Could not sync from cloud:', e);
    }
  };

  const activeVehicle = useMemo(() => {
    return vehicles.find((v) => v.id === activeVehicleId) || vehicles[0] || null;
  }, [vehicles, activeVehicleId]);

  const activeRecords = useMemo(() => {
    if (!activeVehicle) return records;
    return records.filter((r) => !r.vehicleId || r.vehicleId === activeVehicle.id);
  }, [records, activeVehicle]);

  const activeReminders = useMemo(() => {
    if (!activeVehicle) return reminders;
    return reminders.filter((r) => !r.vehicleId || r.vehicleId === activeVehicle.id);
  }, [reminders, activeVehicle]);

  const tierLimits = useMemo(() => {
    const tier = user?.tier || 'free';
    return DEFAULT_TIER_LIMITS[tier];
  }, [user]);

  const formatMoney = (amount: number) => {
    const formatted = new Intl.NumberFormat(
      language === 'ar' ? 'ar-TN' : language === 'fr' ? 'fr-FR' : 'en-US',
      { maximumFractionDigits: 1 }
    ).format(amount);

    if (currency === 'EUR') return `${formatted} €`;
    if (currency === 'USD') return `$${formatted}`;
    return language === 'ar' ? `${formatted} د.ت` : `${formatted} DT`;
  };

  const login = async (email: string, pass: string) => {
    try {
      const res = await fetch(apiUrl('/api/auth/login'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password: pass }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || (language === 'ar' ? 'خطأ في تسجيل الدخول' : 'Erreur de connexion') };
      }

      // Purge prior session state to guarantee cross-user data isolation on same device (Priority 5)
      setVehicles([]);
      setRecords([]);
      setReminders([]);
      setActiveVehicleId('');
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {}

      setToken(data.token);
      setUser(data.user);
      localStorage.setItem(TOKEN_KEY, data.token);
      await syncFromCloud(data.token);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || (language === 'ar' ? 'الخادم غير متاح حالياً' : 'Serveur indisponible') };
    }
  };

  const register = async (name: string, email: string, pass: string) => {
    try {
      const res = await fetch(apiUrl('/api/auth/register'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ name, email, password: pass }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || (language === 'ar' ? 'خطأ أثناء إنشاء الحساب' : 'Erreur d\'inscription') };
      }

      // Clean isolation for newly registered user
      setVehicles([]);
      setRecords([]);
      setReminders([]);
      setActiveVehicleId('');
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {}

      setToken(data.token);
      setUser(data.user);
      localStorage.setItem(TOKEN_KEY, data.token);

      await syncFromCloud(data.token);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || (language === 'ar' ? 'الخادم غير متاح حالياً' : 'Serveur indisponible') };
    }
  };

  const logout = async () => {
    if (token) {
      try {
        await fetch(apiUrl('/api/auth/logout'), {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          credentials: 'include',
        });
      } catch (e) {
        console.warn('Logout session revocation request error:', e);
      }
    }
    setToken(null);
    setUser(null);
    try {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(STORAGE_KEY);
    } catch {}

    // Complete purge of in-memory data to prevent previous user data leakage on shared browser
    setVehicles([]);
    setRecords([]);
    setReminders([]);
    setActiveVehicleId('');
  };

  const deleteAccount = async () => {
    if (token) {
      await fetch(apiUrl('/api/auth/delete-account'), {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
    }
    logout();
    setVehicles(initialVehicles);
    setRecords([]);
    setReminders([]);
    setActiveVehicleId('veh_default_1');
  };

  const exportData = async () => {
    if (token) {
      const res = await fetch(apiUrl('/api/auth/export-data'), {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) return await res.json();
    }
    return {
      exportDate: new Date().toISOString(),
      user: user || { status: 'guest' },
      vehicles,
      records,
      reminders,
    };
  };

  const exportDataAsCSV = () => {
    const headers = ['ID', 'Date', 'Type', 'Kilometrage', 'Cout', 'Atelier', 'Statut', 'Gravite', 'Pieces', 'Notes'];
    const rows = records.map((r) => [
      r.id,
      r.date,
      r.type,
      r.mileage,
      r.cost,
      `"${(r.workshop || '').replace(/"/g, '""')}"`,
      r.status || 'completed',
      r.severity || 'routine',
      `"${(r.parts || []).map((p) => `${p.name} (x${p.quantity})`).join(', ').replace(/"/g, '""')}"`,
      `"${(r.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Siyantek_Maintenance_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const addVehicle = async (v: Omit<Vehicle, 'id'>) => {
    const limits = user ? DEFAULT_TIER_LIMITS[user.tier] : DEFAULT_TIER_LIMITS.free;
    if (vehicles.length >= limits.maxVehicles) {
      return {
        success: false,
        error:
          language === 'ar'
            ? 'تعذر إضافة السيارة. يرجى المحاولة مرة أخرى.'
            : 'Impossible d’ajouter le véhicule. Veuillez réessayer.',
      };
    }

    if (token) {
      try {
        const res = await fetch(apiUrl('/api/vehicles'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify(v),
        });
        const data = await res.json();
        if (!res.ok) return { success: false, error: data.error };
        setVehicles((prev) => [...prev, data]);
        setActiveVehicleId(data.id);
        return { success: true };
      } catch (err: any) {
        return { success: false, error: err?.message };
      }
    }

    const newV: Vehicle = { ...v, id: `veh_${Date.now()}` };
    setVehicles((prev) => [...prev, newV]);
    setActiveVehicleId(newV.id);
    return { success: true };
  };

  const updateVehicle = async (v: Vehicle) => {
    if (token) {
      try {
        const res = await fetch(apiUrl(`/api/vehicles/${v.id}`), {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify(v),
        });
        if (!res.ok) {
          const data = await res.json();
          return { success: false, error: data.error };
        }
      } catch (err: any) {
        return { success: false, error: err?.message };
      }
    }
    setVehicles((prev) => prev.map((item) => (item.id === v.id ? v : item)));
    return { success: true };
  };

  const deleteVehicle = async (id: string) => {
    if (vehicles.length <= 1) return;
    if (token) {
      try {
        await fetch(apiUrl(`/api/vehicles/${id}`), {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch {}
    }
    const remaining = vehicles.filter((v) => v.id !== id);
    setVehicles(remaining);
    setRecords((prev) => prev.filter((r) => r.vehicleId !== id));
    setReminders((prev) => prev.filter((rem) => rem.vehicleId !== id));
    setActiveVehicleId(remaining[0]?.id || '');
  };

  const addRecord = async (rec: Omit<MaintenanceRecord, 'id'>) => {
    const recWithVehicle = {
      ...rec,
      vehicleId: rec.vehicleId || activeVehicle?.id || 'veh_default_1',
      status: rec.status || 'completed',
      severity: rec.severity || 'routine',
      parts: rec.parts || [],
    };

    if (token) {
      try {
        const res = await fetch(apiUrl('/api/maintenance'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify(recWithVehicle),
        });
        if (res.ok) {
          const saved = await res.json();
          setRecords((prev) => [saved, ...prev]);
          if (activeVehicle && saved.mileage > activeVehicle.mileage) {
            updateVehicle({ ...activeVehicle, mileage: saved.mileage });
          }
          return;
        }
      } catch {}
    }

    const localRec: MaintenanceRecord = {
      ...recWithVehicle,
      id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    };
    setRecords((prev) => [localRec, ...prev]);
    if (activeVehicle && localRec.mileage > activeVehicle.mileage) {
      updateVehicle({ ...activeVehicle, mileage: localRec.mileage });
    }
  };

  const updateRecord = async (rec: MaintenanceRecord) => {
    if (token) {
      try {
        const res = await fetch(apiUrl(`/api/maintenance/${rec.id}`), {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify(rec),
        });
        if (!res.ok) {
          const data = await res.json();
          return { success: false, error: data.error };
        }
      } catch (err: any) {
        return { success: false, error: err?.message };
      }
    }
    setRecords((prev) => prev.map((r) => (r.id === rec.id ? rec : r)));
    return { success: true };
  };

  const deleteRecord = async (id: string) => {
    if (token) {
      try {
        await fetch(apiUrl(`/api/maintenance/${id}`), {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch {}
    }
    setRecords((prev) => prev.filter((r) => r.id !== id));
  };

  const addReminder = async (rem: Omit<Reminder, 'id'>) => {
    const remWithVehicle = {
      ...rem,
      vehicleId: rem.vehicleId || activeVehicle?.id || 'veh_default_1',
      completed: false,
    };

    if (token) {
      try {
        const res = await fetch(apiUrl('/api/reminders'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify(remWithVehicle),
        });
        const data = await res.json();
        if (!res.ok) return { success: false, error: data.error };
        setReminders((prev) => [data, ...prev]);
        return { success: true };
      } catch (err: any) {
        return { success: false, error: err?.message };
      }
    }

    const localRem: Reminder = {
      ...remWithVehicle,
      id: `rem_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    setReminders((prev) => [localRem, ...prev]);
    return { success: true };
  };

  const toggleReminder = async (id: string) => {
    const target = reminders.find((r) => r.id === id);
    if (!target) return;
    const updated = {
      ...target,
      completed: !target.completed,
      completedDate: !target.completed ? new Date().toISOString().slice(0, 10) : undefined,
    };

    if (token) {
      try {
        await fetch(apiUrl(`/api/reminders/${id}`), {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({ completed: updated.completed }),
        });
      } catch {}
    }

    setReminders((prev) => prev.map((r) => (r.id === id ? updated : r)));
  };

  const deleteReminder = async (id: string) => {
    if (token) {
      try {
        await fetch(apiUrl(`/api/reminders/${id}`), {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch {}
    }
    setReminders((prev) => prev.filter((r) => r.id !== id));
  };

  const upgradeSubscription = async (tier: SubscriptionTier) => {
    if (!token) {
      return {
        success: false,
        error:
          language === 'ar'
            ? 'يرجى تسجيل الدخول أولاً لإدارة باقتك واشتراكك.'
            : 'Veuillez vous connecter pour gérer votre abonnement.',
      };
    }

    try {
      const res = await fetch(apiUrl('/api/subscription/checkout'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ planId: tier }),
      });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: (language === 'ar' && data.messageAr) ? data.messageAr : (data.error || (language === 'ar' ? 'فشل إتمام طلب الترقية' : 'Échec de la demande d\'abonnement')),
        };
      }

      // Strictly DO NOT update user.tier to Plus or Pro locally while payment is pending
      // Only update local tier when server explicitly confirms paymentRequired is false (Free tier) or tier is verified
      if (data.userTier) {
        setUser((u) => (u ? { ...u, tier: data.userTier, subscriptionStatus: data.userTier === 'free' ? 'none' : 'active' } : null));
      }

      return {
        success: true,
        message: (language === 'ar' && data.messageAr) ? data.messageAr : (data.message || (language === 'ar' ? 'تم استلام طلبك بنجاح.' : 'Demande enregistrée.')),
      };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  };

  const cancelSubscription = async () => {
    if (token) {
      await fetch(apiUrl('/api/subscription/cancel'), {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
    }
    if (user) {
      setUser((u) => (u ? { ...u, subscriptionStatus: 'canceled' } : null));
    }
  };

  const fetchMyPayments = async () => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) return;
    try {
      const res = await fetch(apiUrl('/api/subscription/my-payments'), {
        headers: { Authorization: `Bearer ${activeTok}` },
      });
      if (res.ok) {
        const data = await res.json();
        setMyPayments(data);
      }
    } catch {}
  };

  const createManualOrder = async (planId: 'plus' | 'pro', method = 'bank_transfer') => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) {
      return {
        success: false,
        error: language === 'ar' ? 'يرجى تسجيل الدخول أولاً' : 'Veuillez vous connecter.',
      };
    }
    try {
      const res = await fetch(apiUrl('/api/subscription/manual-order'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${activeTok}` },
        body: JSON.stringify({ planId, method }),
      });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: (language === 'ar' && data.messageAr) ? data.messageAr : data.error,
        };
      }
      setMyPayments((prev) => [data.order, ...prev]);
      return {
        success: true,
        order: data.order,
        instructions: data.instructions,
      };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  };

  const uploadReceipt = async (orderId: string, base64Data: string, mimeType: string, filename?: string) => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) {
      return { success: false, error: language === 'ar' ? 'يرجى تسجيل الدخول' : 'Veuillez vous connecter' };
    }
    try {
      const res = await fetch(apiUrl(`/api/subscription/manual-order/${orderId}/upload-receipt`), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${activeTok}` },
        body: JSON.stringify({ base64Data, mimeType, filename }),
      });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: (language === 'ar' && data.messageAr) ? data.messageAr : data.error,
        };
      }
      setMyPayments((prev) => prev.map((p) => (p.id === orderId ? data.order : p)));
      return {
        success: true,
        message: (language === 'ar' && data.messageAr) ? data.messageAr : data.message,
        order: data.order,
      };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  };

  // Admin APIs
  const fetchAdminStats = async () => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) return null;
    try {
      const res = await fetch(apiUrl('/api/admin/stats'), {
        headers: { Authorization: `Bearer ${activeTok}` },
      });
      return res.ok ? res.json() : null;
    } catch {
      return null;
    }
  };

  const fetchAdminUsers = async () => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) return [];
    try {
      const res = await fetch(apiUrl('/api/admin/users'), {
        headers: { Authorization: `Bearer ${activeTok}` },
      });
      return res.ok ? res.json() : [];
    } catch {
      return [];
    }
  };

  const fetchAdminPayments = async () => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) return [];
    try {
      const res = await fetch(apiUrl('/api/admin/payments'), {
        headers: { Authorization: `Bearer ${activeTok}` },
      });
      return res.ok ? res.json() : [];
    } catch {
      return [];
    }
  };

  const approvePayment = async (id: string, notes?: string, durationDays?: number) => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) return { success: false, error: 'Non authentifié' };
    try {
      const res = await fetch(apiUrl(`/api/admin/payments/${id}/approve`), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${activeTok}` },
        body: JSON.stringify({ notes, durationDays }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      return { success: true, message: data.message };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  };

  const rejectPayment = async (id: string, reason?: string) => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) return { success: false, error: 'Non authentifié' };
    try {
      const res = await fetch(apiUrl(`/api/admin/payments/${id}/reject`), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${activeTok}` },
        body: JSON.stringify({ reason }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      return { success: true, message: data.message };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  };

  const updateUserTier = async (userId: string, tier: SubscriptionTier, durationDays = 30, notes?: string) => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) return { success: false, error: 'Non authentifié' };
    try {
      const res = await fetch(apiUrl(`/api/admin/users/${userId}/tier`), {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${activeTok}` },
        body: JSON.stringify({ tier, durationDays, notes }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  };

  const fetchAuditLogs = async () => {
    const activeTok = token || localStorage.getItem(TOKEN_KEY);
    if (!activeTok) return [];
    try {
      const res = await fetch(apiUrl('/api/admin/audit-logs'), {
        headers: { Authorization: `Bearer ${activeTok}` },
      });
      return res.ok ? res.json() : [];
    } catch {
      return [];
    }
  };

  const resetAllData = async () => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    setToken(null);
    setMyPayments([]);
    setVehicles(initialVehicles);
    setRecords([]);
    setReminders([]);
    setActiveVehicleId('veh_default_1');
  };

  const t = (key: string) => translations[language]?.[key] ?? translations.fr[key] ?? translations.en[key] ?? key;

  return (
    <SiyantekContext.Provider
      value={{
        language,
        isRTL: language === 'ar',
        setLanguage: setLanguageState,
        currency,
        setCurrency: setCurrencyState,
        formatMoney,
        t,
        user,
        token,
        isLoggedIn: Boolean(user && token),
        isAdmin: Boolean(user && user.role === 'admin'),
        tierLimits,
        login,
        register,
        logout,
        deleteAccount,
        exportData,
        exportDataAsCSV,
        vehicles,
        activeVehicle,
        activeVehicleId,
        setActiveVehicleId,
        addVehicle,
        updateVehicle,
        deleteVehicle,
        records: activeRecords,
        addRecord,
        updateRecord,
        deleteRecord,
        reminders: activeReminders,
        addReminder,
        toggleReminder,
        deleteReminder,
        upgradeSubscription,
        cancelSubscription,
        resetAllData,
        myPayments,
        fetchMyPayments,
        createManualOrder,
        uploadReceipt,
        fetchAdminStats,
        fetchAdminUsers,
        fetchAdminPayments,
        approvePayment,
        rejectPayment,
        updateUserTier,
        fetchAuditLogs,
      }}
    >
      {children}
    </SiyantekContext.Provider>
  );
}

export function useSiyantek() {
  const context = useContext(SiyantekContext);
  if (!context) throw new Error('useSiyantek must be used inside SiyantekProvider');
  return context;
}

export const formatLocalizedNumber = (val: number, lang: Language) => {
  return new Intl.NumberFormat(lang === 'ar' ? 'ar-TN' : lang === 'fr' ? 'fr-FR' : 'en-US').format(val);
};
