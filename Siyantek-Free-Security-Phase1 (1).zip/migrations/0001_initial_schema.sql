-- ===================================================================
-- Siyantek Commercial SaaS — Production PostgreSQL Database Schema
-- Version: 0001_initial_schema
-- Target Engines: PostgreSQL 14+, Cloud SQL for PostgreSQL, Supabase, Neon
-- ===================================================================

-- 1. Table: Users & Subscriptions
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(180) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    tier VARCHAR(20) NOT NULL DEFAULT 'free' CHECK (tier IN ('free', 'plus', 'pro')),
    subscription_status VARCHAR(20) NOT NULL DEFAULT 'none' CHECK (subscription_status IN ('active', 'canceled', 'expired', 'none')),
    renewal_date TIMESTAMP WITH TIME ZONE,
    subscription_expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. Table: Sessions (Token Hash SHA-256)
CREATE TABLE IF NOT EXISTS sessions (
    token_hash VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);

-- 3. Table: Password Resets (Token Hash SHA-256)
CREATE TABLE IF NOT EXISTS password_resets (
    token_hash VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    email VARCHAR(180) NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 4. Table: Vehicles
CREATE TABLE IF NOT EXISTS vehicles (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    brand VARCHAR(60) NOT NULL,
    model VARCHAR(60) NOT NULL,
    year VARCHAR(10),
    plate VARCHAR(40),
    mileage INTEGER NOT NULL DEFAULT 0 CHECK (mileage >= 0),
    motorization VARCHAR(60),
    fuel_type VARCHAR(30),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 5. Table: Maintenance Records & Spare Parts
CREATE TABLE IF NOT EXISTS maintenance_records (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    vehicle_id VARCHAR(64) NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    type VARCHAR(30) NOT NULL CHECK (type IN ('oil', 'brakes', 'tires', 'inspection', 'battery', 'other')),
    date VARCHAR(20) NOT NULL,
    mileage INTEGER NOT NULL CHECK (mileage >= 0),
    cost NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (cost >= 0),
    notes TEXT,
    next_mileage INTEGER,
    workshop VARCHAR(120),
    status VARCHAR(30) NOT NULL DEFAULT 'completed' CHECK (status IN ('completed', 'in_progress', 'scheduled')),
    severity VARCHAR(30) NOT NULL DEFAULT 'routine' CHECK (severity IN ('routine', 'minor', 'major', 'critical')),
    parts JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 6. Table: Reminders & Alerts
CREATE TABLE IF NOT EXISTS reminders (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    vehicle_id VARCHAR(64) NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    title VARCHAR(120) NOT NULL,
    type VARCHAR(30) NOT NULL,
    due_date VARCHAR(20),
    due_mileage INTEGER,
    notes TEXT,
    completed BOOLEAN NOT NULL DEFAULT FALSE,
    completed_date VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 7. Table: Payment Transactions (Manual Bank/Postal Orders & Gateways)
CREATE TABLE IF NOT EXISTS payment_transactions (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan_id VARCHAR(20) NOT NULL CHECK (plan_id IN ('plus', 'pro')),
    amount_dt NUMERIC(10, 2) NOT NULL CHECK (amount_dt > 0),
    currency VARCHAR(10) NOT NULL DEFAULT 'TND',
    provider VARCHAR(40) NOT NULL DEFAULT 'bank_transfer',
    method VARCHAR(40) NOT NULL DEFAULT 'virement_bancaire',
    status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'submitted', 'approved', 'rejected', 'expired', 'completed', 'failed', 'canceled')),
    idempotency_key VARCHAR(64) NOT NULL UNIQUE,
    transfer_reference VARCHAR(60) NOT NULL,
    bank_instructions JSONB,
    receipt_filename VARCHAR(255),
    receipt_mime_type VARCHAR(60),
    receipt_file_size INTEGER,
    receipt_uploaded_at TIMESTAMP WITH TIME ZONE,
    admin_notes TEXT,
    reviewed_by VARCHAR(64) REFERENCES users(id) ON DELETE SET NULL,
    reviewed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- 8. Table: Audit Logs (Administrative Security Journal)
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(64) PRIMARY KEY,
    admin_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE SET NULL,
    admin_email VARCHAR(180) NOT NULL,
    action VARCHAR(80) NOT NULL,
    target_type VARCHAR(40) NOT NULL,
    target_id VARCHAR(64) NOT NULL,
    details JSONB DEFAULT '{}'::jsonb,
    ip VARCHAR(60),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 9. Performance & Security Indexes
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_tier ON users(tier);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_password_resets_token ON password_resets(token_hash);
CREATE INDEX IF NOT EXISTS idx_vehicles_user_id ON vehicles(user_id);
CREATE INDEX IF NOT EXISTS idx_records_user_veh ON maintenance_records(user_id, vehicle_id);
CREATE INDEX IF NOT EXISTS idx_reminders_user_veh ON reminders(user_id, vehicle_id);
CREATE INDEX IF NOT EXISTS idx_payments_user_status ON payment_transactions(user_id, status);
CREATE INDEX IF NOT EXISTS idx_payments_transfer_ref ON payment_transactions(transfer_reference);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_logs_admin ON audit_logs(admin_id);
